# Baran Stüdyo — Kurumsal Web Sitesi

PHP 8.3+ · MySQL 8 · MVC · OOP · cPanel uyumlu · **npm / build / komut gerektirmez**

## Özellikler
- Ana sayfa, Hakkımızda, Hizmetler (+detay), Projeler (+detay, filtre), Blog (+detay), İletişim (AJAX form)
- Yönetim paneli (`/admin`): Dashboard, Hizmet / Proje / Blog / Referans CRUD, gelen mesajlar, site ayarları, kullanıcılar & roller (Yönetici / Editör), güvenlik & IP logları, profil / şifre değiştirme
- Güvenlik: PDO prepared statements, XSS çıktı kaçışı + HTML allow-list temizleyici, CSRF token, güvenli dosya yükleme (MIME + içerik doğrulama, GD ile yeniden kodlama, uploads klasöründe PHP çalıştırma kapalı), güvenli session (HttpOnly, SameSite, strict mode, ID yenileme, parmak izi), brute-force koruması (IP + e-posta kilidi), IP loglama, güvenli hata yönetimi, güvenlik başlıkları + CSP
- SEO: Dinamik title / description, canonical, Open Graph, Twitter Card, Schema.org (Organization, WebSite, Service, Article, Breadcrumb), dinamik `sitemap.xml` ve `robots.txt`, Türkçe karakter uyumlu temiz URL'ler
- WhatsApp butonu, Google Analytics, Cloudflare uyumu (gerçek ziyaretçi IP'si), dosya tabanlı sayfa/veri önbelleği, yüklenen görsellerin otomatik boyutlandırılıp WebP'ye çevrilmesi, gzip + tarayıcı önbelleği

## cPanel Kurulumu (5 adım)
1. **Dosyaları yükleyin:** Tüm proje dosyalarını (gizli `.htaccess` dosyaları dahil) `public_html` klasörüne yükleyin. (Zip yüklediyseniz Dosya Yöneticisi → Extract.)
2. **PHP sürümü:** cPanel → *Select PHP Version* (PHP Selector / MultiPHP Manager) → **8.3** seçin. Eklentiler: `pdo_mysql`, `mbstring`, `gd`, `fileinfo`, `openssl`, `dom` (genellikle varsayılan açıktır).
3. **Veritabanı:** cPanel → *MySQL Databases* → yeni veritabanı + kullanıcı oluşturun, kullanıcıya **ALL PRIVILEGES** verin. *phpMyAdmin* → veritabanını seçin → **İçe Aktar** → `database/schema.sql`.
4. **Ayar:** `config/config.php` dosyasını düzenleyin:
   - `app.url` → `https://baranstudyo.net.tr`
   - `db.name`, `db.user`, `db.pass` → 3. adımdaki bilgiler
   - `mail` → `from_email` (cPanel'de oluşturduğunuz e-posta). SMTP kullanmak isterseniz `driver => 'smtp'` ve SMTP bilgileri.
5. **SSL:** cPanel → *SSL/TLS Status* → AutoSSL. Ardından `config.php` içinde `force_https => true` yapın (veya `.htaccess` içindeki HTTPS satırlarını açın).

Hepsi bu — site çalışmaya hazır. `storage/` ve `uploads/` klasörleri yazılabilir olmalıdır (cPanel'de varsayılan olarak 755 yeterlidir).

## Yönetim Paneli
- Adres: `https://baranstudyo.net.tr/admin`
- Kurulumda hiçbir hesap yoktur. Kurulumdan hemen sonra `https://baranstudyo.net.tr/kayit` adresinden **baran@baranstudyo.net.tr** e-postası ile kayıt olun; bu hesap otomatik olarak **Owner** (en yüksek yetki) olur.
- Owner yalnızca bir kez atanır: Owner hesabı oluştuktan sonra kimse Owner yetkisi alamaz. Diğer tüm kayıtlar normal üye olur; yetkilerini Owner panelden değiştirebilir.
- Owner e-postası `config/config.php` içindeki `owner_email` ayarındadır.
- **İlk girişte Profilim → şifrenizi mutlaka değiştirin.**

| Rol | Yetkiler |
|---|---|
| Yönetici | Tüm modüller |
| Editör | Dashboard, hizmetler, projeler, blog, referanslar, mesajlar, profil |

## Canlıya Alma Kontrol Listesi
- [ ] `config.php` → `debug => false` (varsayılan)
- [ ] Owner hesabı (baran@baranstudyo.net.tr) kayıt edildi
- [ ] SSL aktif, `force_https => true`
- [ ] Site Ayarları → iletişim bilgileri, WhatsApp numarası, Google Analytics ölçüm kimliği (G-XXXX), Search Console doğrulama kodu
- [ ] Google Search Console'a `https://baranstudyo.net.tr/sitemap.xml` gönderildi
- [ ] Cloudflare kullanıyorsanız SSL modu **Full (strict)**

## Klasör Yapısı
```
/admin       Yönetim paneli giriş noktası (/admin)
/app         core (çekirdek), controllers, models, views, routes
/assets      CSS, JS, görseller
/config      config.php
/database    schema.sql (tablolar, boş içerik — sahte/örnek veri yoktur)
/public      Ön denetleyici (index.php)
/storage     cache, logs, sessions (web'den erişime kapalı)
/uploads     Yüklenen görseller (betik çalıştırma kapalı)
```

## Sunucu Notları
- **Apache / LiteSpeed:** Hazır `.htaccess` dosyaları ile çalışır (mod_rewrite).
- **Nginx:** `nginx.conf.example` dosyasını kullanın.
- **Alt klasör kurulumu:** `app.url` değerini `https://alanadi.com/klasor` olarak ayarlamanız yeterlidir.
- **Yerel geliştirme:** `config/config.local.php` oluşturarak `config.php` değerlerini ezebilirsiniz (git'e eklenmez).
- Hata logları: `storage/logs/` · Önbellek temizleme: Yönetim → Site Ayarları → Önbelleği Temizle.


## Domain sorgulama

Sorgular IANA RDAP bootstrap listesi üzerinden ilgili kayıt otoritesinin RDAP servisine, RDAP olmayan uzantılarda (ör. .com.tr) WHOIS sunucusuna (port 43) yapılır. Sunucu bu adreslere giden HTTPS ve 43 numaralı porta izin vermelidir (bazı paylaşımlı hostinglerde 43. port kapalıdır; bu durumda .tr sorguları "sonuç belirlenemedi" hatası döner, sahte sonuç gösterilmez). Uzantılar ve sorgu limiti: Yönetim Paneli → Domain Ayarları.
