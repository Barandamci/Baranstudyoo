<?php
/**
 * Baran Stüdyo - Yönetim paneli ön denetleyicisi
 */
declare(strict_types=1);

require dirname(__DIR__) . '/app/bootstrap.php';

use App\Core\Router;

$router = new Router('/admin', 'App\\Controllers\\Admin\\');
require APP_PATH . '/routes_admin.php';

$router->dispatch($_SERVER['REQUEST_METHOD'] ?? 'GET', $_SERVER['REQUEST_URI'] ?? '/admin', static function (): void {
    http_response_code(404);
    echo App\Core\View::render('admin/errors/404', ['title' => 'Sayfa Bulunamadı'], App\Core\Auth::check() ? 'admin/layouts/main' : null);
});
