<?php
declare(strict_types=1);

define('BASE_PATH', dirname(__DIR__));
define('APP_PATH', BASE_PATH . '/app');
define('STORAGE_PATH', BASE_PATH . '/storage');
define('UPLOAD_PATH', BASE_PATH . '/uploads');

if (PHP_VERSION_ID < 80300) {
    http_response_code(500);
    exit('Baran Stüdyo PHP 8.3 veya üzeri gerektirir. cPanel > PHP Selector üzerinden sürümü yükseltin.');
}

spl_autoload_register(static function (string $class): void {
    $map = [
        'App\\Core\\'        => APP_PATH . '/core/',
        'App\\Models\\'      => APP_PATH . '/models/',
        'App\\Controllers\\' => APP_PATH . '/controllers/',
    ];
    foreach ($map as $prefix => $dir) {
        if (str_starts_with($class, $prefix)) {
            $file = $dir . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';
            if (is_file($file)) {
                require $file;
            }
            return;
        }
    }
});

require APP_PATH . '/core/helpers.php';

$GLOBALS['__config'] = require BASE_PATH . '/config/config.php';
if (is_file(BASE_PATH . '/config/config.local.php')) {
    $GLOBALS['__config'] = array_replace_recursive($GLOBALS['__config'], require BASE_PATH . '/config/config.local.php');
}

date_default_timezone_set(config('app.timezone', 'Europe/Istanbul'));
mb_internal_encoding('UTF-8');
ini_set('default_charset', 'UTF-8');

App\Core\ErrorHandler::register((bool) config('app.debug', false));

if (config('app.force_https') && !is_https() && PHP_SAPI !== 'cli') {
    $host = preg_replace('/[^a-z0-9\.\-:]/i', '', $_SERVER['HTTP_HOST'] ?? '');
    header('Location: https://' . $host . ($_SERVER['REQUEST_URI'] ?? '/'), true, 301);
    exit;
}

App\Core\Security::sendHeaders();
App\Core\Session::start();
