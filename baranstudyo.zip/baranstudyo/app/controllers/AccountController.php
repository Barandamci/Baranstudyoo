<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\RateLimiter;
use App\Core\Request;
use App\Core\Seo;
use App\Core\Session;
use App\Core\Validator;
use App\Models\ActivityLog;
use App\Models\User;

final class AccountController extends Controller
{
    public function __construct()
    {
        header('Cache-Control: no-store');
    }

    public function loginForm(): void
    {
        if (Auth::check()) {
            $this->redirect(url('hesabim'));
        }
        $this->view('account/login', ['seo' => Seo::make('Giriş Yap', null, '/giris')->noindex()]);
    }

    public function login(): void
    {
        $email = Request::input('email');
        $result = Auth::attempt($email, (string) ($_POST['password'] ?? ''));
        if (!$result['ok']) {
            Session::flash('error', $result['message']);
            Session::withInput(['email' => $email]);
            $this->redirect(url('giris'));
        }
        $this->redirect(Auth::can('dashboard') ? admin_url() : url('hesabim'));
    }

    public function registerForm(): void
    {
        if (Auth::check()) {
            $this->redirect(url('hesabim'));
        }
        $this->view('account/register', ['seo' => Seo::make('Kayıt Ol', null, '/kayit')->noindex(), 'open' => $this->registrationOpen()]);
    }

    public function register(): void
    {
        $back = url('kayit');
        $data = ['name' => Request::input('name'), 'email' => mb_strtolower(Request::input('email'))];
        $password = (string) ($_POST['password'] ?? '');
        Session::withInput($data);

        if (Request::input('website') !== '') { // bot tuzağı
            $this->redirect($back);
        }
        if (!$this->registrationOpen($data['email'])) {
            Session::flash('error', 'Yeni üye kaydı şu anda kapalıdır.');
            $this->redirect($back);
        }
        if (RateLimiter::tooMany('register:' . client_ip(), 5, 3600)) {
            Session::flash('error', 'Çok fazla kayıt denemesi. Lütfen daha sonra tekrar deneyin.');
            $this->redirect($back);
        }
        $v = Validator::make($data, ['name' => 'required|min:3|max:100', 'email' => 'required|email|max:190'], ['name' => 'Ad Soyad', 'email' => 'E-posta']);
        $error = $v->fails() ? $v->firstError() : null;
        if (!$error && (mb_strlen($password) < 8 || !preg_match('/[A-Za-zÇĞİÖŞÜçğıöşü]/u', $password) || !preg_match('/\d/', $password))) {
            $error = 'Şifre en az 8 karakter olmalı, harf ve rakam içermelidir.';
        }
        if (!$error && $password !== (string) ($_POST['password_confirmation'] ?? '')) {
            $error = 'Şifreler eşleşmiyor.';
        }
        if (!$error && User::emailTaken($data['email'])) {
            $error = 'Bu e-posta adresiyle zaten bir hesap var.';
        }
        if ($error) {
            Session::flash('error', $error);
            $this->redirect($back);
        }

        $role = User::roleForNewAccount($data['email']);
        $id = User::create($data + ['password' => password_hash($password, PASSWORD_DEFAULT), 'role' => $role, 'is_active' => 1]);
        ActivityLog::log('register', ($role === 'owner' ? 'Owner hesabı oluşturuldu: ' : 'Yeni üye kaydı: ') . $data['email'], $id);
        Auth::attempt($data['email'], $password);
        Session::flash('success', $role === 'owner' ? 'Owner hesabınız oluşturuldu. Yönetim paneline erişebilirsiniz.' : 'Hesabınız oluşturuldu. Hoş geldiniz!');
        $this->redirect($role === 'owner' ? admin_url() : url('hesabim'));
    }

    public function logout(): void
    {
        Auth::logout();
        Session::flash('success', 'Çıkış yaptınız.');
        $this->redirect(url());
    }

    public function index(): void
    {
        if (!Auth::check()) {
            Session::flash('error', 'Lütfen giriş yapın.');
            $this->redirect(url('giris'));
        }
        $this->view('account/index', ['seo' => Seo::make('Hesabım', null, '/hesabim')->noindex(), 'user' => Auth::user()]);
    }

    private function registrationOpen(?string $email = null): bool
    {
        if (setting('registration_enabled', '1') === '1') {
            return true;
        }
        return $email !== null && User::roleForNewAccount($email) === 'owner';
    }
}
