<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Core\Session;
use App\Core\View;
use App\Models\ActivityLog;

final class AuthController extends Controller
{
    public function loginForm(): void
    {
        header('X-Robots-Tag: noindex, nofollow');
        header('Cache-Control: no-store');
        if (Auth::check()) {
            Response::redirect(admin_url());
        }
        echo View::render('admin/auth/login', [], null);
    }

    public function login(): void
    {
        $email = Request::input('email');
        $password = (string) ($_POST['password'] ?? '');
        if ($email === '' || $password === '') {
            Session::flash('error', 'E-posta ve şifre zorunludur.');
            Session::withInput(['email' => $email]);
            Response::redirect(admin_url('login'));
        }
        $result = Auth::attempt($email, $password);
        if (!$result['ok']) {
            Session::flash('error', $result['message']);
            Session::withInput(['email' => $email]);
            Response::redirect(admin_url('login'));
        }
        Response::redirect(admin_url());
    }

    public function logout(): void
    {
        if (Auth::check()) {
            ActivityLog::log('logout', 'Oturum kapatıldı');
        }
        Auth::logout();
        Session::flash('success', 'Güvenli şekilde çıkış yaptınız.');
        Response::redirect(admin_url('login'));
    }
}
