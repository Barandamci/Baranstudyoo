<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\AdminController;
use App\Models\ActivityLog;
use App\Models\Message;
use App\Models\Post;
use App\Models\Project;
use App\Models\Service;

final class DashboardController extends AdminController
{
    protected string $permission = 'dashboard';

    public function index(): void
    {
        $this->view('dashboard/index', [
            'title' => 'Dashboard',
            'stats' => [
                'services' => Service::count(),
                'projects' => Project::count(),
                'posts' => Post::count(),
                'messages' => Message::count(),
                'unread' => Message::unreadCount(),
                'today' => Message::count('created_at >= CURDATE()'),
            ],
            'messages' => Message::all(null, [], 'id DESC', 6),
            'logs' => ActivityLog::withUsers(1, 8)['items'],
        ]);
    }
}
