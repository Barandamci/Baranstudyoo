<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\AdminController;
use App\Core\Request;
use App\Models\ActivityLog;
use App\Models\LoginAttempt;

final class LogController extends AdminController
{
    protected string $permission = 'logs';

    public function index(): void
    {
        LoginAttempt::prune(90);
        $action = preg_replace('/[^a-z_]/', '', Request::input('action'));
        $this->view('logs/index', [
            'title' => 'Güvenlik & IP Logları',
            'result' => ActivityLog::withUsers(Request::page(), 30, $action),
            'action' => $action,
            'attempts' => LoginAttempt::all('success = 0', [], 'id DESC', 15),
        ]);
    }
}
