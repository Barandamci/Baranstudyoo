<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\AdminController;
use App\Core\Request;
use App\Models\Message;

final class MessageController extends AdminController
{
    protected string $permission = 'messages';

    public function index(): void
    {
        $filter = Request::input('filtre');
        $q = mb_substr(Request::input('q'), 0, 100);
        $conds = [];
        $params = [];
        if ($filter === 'okunmamis') {
            $conds[] = 'is_read = 0';
        }
        if ($q !== '') {
            $conds[] = '(name LIKE :q1 OR email LIKE :q2 OR subject LIKE :q3)';
            $like = '%' . addcslashes($q, '%_\\') . '%';
            $params += ['q1' => $like, 'q2' => $like, 'q3' => $like];
        }
        $result = Message::paginate(Request::page(), 20, $conds ? implode(' AND ', $conds) : null, $params);
        $this->view('messages/index', ['title' => 'Gelen Mesajlar', 'result' => $result, 'filter' => $filter, 'q' => $q]);
    }

    public function show(int $id): void
    {
        $message = Message::find($id);
        if (!$message) {
            $this->fail('Mesaj bulunamadı.', admin_url('messages'));
        }
        if (!(int) $message['is_read']) {
            Message::update($id, ['is_read' => 1]);
        }
        $this->view('messages/show', ['title' => 'Mesaj Detayı', 'message' => $message]);
    }

    public function toggle(int $id): void
    {
        $message = Message::find($id) ?? $this->fail('Mesaj bulunamadı.', admin_url('messages'));
        Message::update($id, ['is_read' => (int) $message['is_read'] ? 0 : 1]);
        $this->success('Mesaj durumu güncellendi.', admin_url('messages'));
    }

    public function destroy(int $id): void
    {
        $message = Message::find($id) ?? $this->fail('Mesaj bulunamadı.', admin_url('messages'));
        Message::delete($id);
        $this->log('delete', "Mesaj silindi (#$id): {$message['email']}");
        $this->success('Mesaj silindi.', admin_url('messages'));
    }
}
