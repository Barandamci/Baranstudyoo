<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Auth;
use App\Core\ResourceController;
use App\Models\Post;

final class PostController extends ResourceController
{
    protected string $permission = 'posts';
    protected string $model = Post::class;
    protected string $route = 'posts';
    protected string $singular = 'Blog Yazısı';
    protected string $plural = 'Blog Yazıları';
    protected string $uploadFolder = 'blog';

    protected function fields(): array
    {
        return [
            'title' => ['label' => 'Başlık', 'type' => 'text', 'rules' => 'required|max:200'],
            'slug' => ['label' => 'URL (slug)', 'type' => 'text', 'rules' => 'max:190', 'col' => 6, 'help' => 'Boş bırakılırsa otomatik oluşturulur.'],
            'status' => ['label' => 'Durum', 'type' => 'select', 'options' => ['draft' => 'Taslak', 'published' => 'Yayında'], 'col' => 3],
            'published_at' => ['label' => 'Yayın Tarihi', 'type' => 'datetime', 'col' => 3],
            'excerpt' => ['label' => 'Özet', 'type' => 'textarea', 'rules' => 'max:400'],
            'content' => ['label' => 'İçerik', 'type' => 'html', 'rules' => 'required'],
            'image' => ['label' => 'Kapak Görseli', 'type' => 'image'],
            'meta_title' => ['label' => 'SEO Başlık', 'type' => 'text', 'rules' => 'max:190', 'col' => 6],
            'meta_description' => ['label' => 'SEO Açıklama', 'type' => 'text', 'rules' => 'max:300', 'col' => 6],
        ];
    }

    protected function columns(): array
    {
        return ['image' => ['', 'image'], 'title' => ['Başlık'], 'status' => ['Durum', 'status'], 'published_at' => ['Yayın', 'date'], 'views' => ['Görüntülenme']];
    }

    protected function prepare(array $data, ?array $existing): array
    {
        if ($existing === null) {
            $data['user_id'] = Auth::id();
        }
        if ($data['status'] === 'published' && empty($data['published_at'])) {
            $data['published_at'] = date('Y-m-d H:i:s');
        }
        if ($data['excerpt'] === '') {
            $data['excerpt'] = str_limit($data['content'], 300);
        }
        return $data;
    }
}
