<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\AdminController;
use App\Core\Auth;
use App\Core\Request;
use App\Core\Session;
use App\Core\Validator;
use App\Models\User;

final class ProfileController extends AdminController
{
    protected string $permission = 'profile';

    public function index(): void
    {
        $this->view('profile/index', ['title' => 'Profilim', 'user' => Auth::user()]);
    }

    public function update(): void
    {
        $back = admin_url('profile');
        $user = User::find((int) Auth::id());
        $data = ['name' => Request::input('name'), 'email' => mb_strtolower(Request::input('email'))];
        $v = Validator::make($data, ['name' => 'required|max:100', 'email' => 'required|email|max:190'], ['name' => 'Ad Soyad', 'email' => 'E-posta']);
        if ($v->fails()) {
            $this->fail($v->firstError(), $back);
        }
        if (User::emailTaken($data['email'], (int) $user['id'])) {
            $this->fail('Bu e-posta adresi zaten kullanılıyor.', $back);
        }
        $current = (string) ($_POST['current_password'] ?? '');
        $new = (string) ($_POST['new_password'] ?? '');
        $confirm = (string) ($_POST['new_password_confirmation'] ?? '');
        if (!password_verify($current, $user['password'])) {
            $this->fail('Değişiklikleri kaydetmek için mevcut şifrenizi doğru girmelisiniz.', $back);
        }
        if ($new !== '') {
            if ($new !== $confirm) {
                $this->fail('Yeni şifreler eşleşmiyor.', $back);
            }
            if ($err = UserController::passwordError($new)) {
                $this->fail($err, $back);
            }
            $data['password'] = password_hash($new, PASSWORD_DEFAULT);
        }
        User::update((int) $user['id'], $data);
        if (isset($data['password'])) {
            Session::regenerate();
            $this->log('password', 'Şifre değiştirildi');
        }
        $this->log('profile', 'Profil güncellendi');
        $this->success('Profiliniz güncellendi.', $back);
    }
}
