<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\ResourceController;
use App\Models\Project;

final class ProjectController extends ResourceController
{
    protected string $permission = 'projects';
    protected string $model = Project::class;
    protected string $route = 'projects';
    protected string $singular = 'Proje';
    protected string $plural = 'Projeler';
    protected string $uploadFolder = 'projects';

    protected function fields(): array
    {
        return [
            'title' => ['label' => 'Proje Adı', 'type' => 'text', 'rules' => 'required|max:150', 'col' => 8],
            'project_date' => ['label' => 'Tarih', 'type' => 'date', 'rules' => 'date', 'col' => 4],
            'slug' => ['label' => 'URL (slug)', 'type' => 'text', 'rules' => 'max:190', 'col' => 6, 'help' => 'Boş bırakılırsa otomatik oluşturulur.'],
            'client' => ['label' => 'Müşteri', 'type' => 'text', 'rules' => 'max:150', 'col' => 3],
            'category' => ['label' => 'Kategori', 'type' => 'text', 'rules' => 'max:100', 'col' => 3],
            'summary' => ['label' => 'Kısa Açıklama', 'type' => 'textarea', 'rules' => 'required|max:400'],
            'content' => ['label' => 'Detaylı Açıklama', 'type' => 'html'],
            'technologies' => ['label' => 'Kullanılan Teknolojiler', 'type' => 'text', 'rules' => 'max:400', 'help' => 'Virgülle ayırın: PHP 8.3, MySQL, JavaScript'],
            'image' => ['label' => 'Görsel', 'type' => 'image'],
            'project_url' => ['label' => 'Canlı Bağlantı', 'type' => 'url', 'rules' => 'url|max:255', 'col' => 8],
            'sort_order' => ['label' => 'Sıra', 'type' => 'number', 'col' => 4],
            'is_featured' => ['label' => 'Ana sayfada öne çıkar', 'type' => 'checkbox'],
            'is_active' => ['label' => 'Yayında', 'type' => 'checkbox'],
        ];
    }

    protected function columns(): array
    {
        return ['image' => ['', 'image'], 'title' => ['Proje'], 'category' => ['Kategori'], 'project_date' => ['Tarih', 'date'], 'is_featured' => ['Öne Çıkan', 'bool'], 'is_active' => ['Durum', 'bool']];
    }
}
