<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\ResourceController;
use App\Models\Service;

final class ServiceController extends ResourceController
{
    protected string $permission = 'services';
    protected string $model = Service::class;
    protected string $route = 'services';
    protected string $singular = 'Hizmet';
    protected string $plural = 'Hizmetler';
    protected string $uploadFolder = 'services';

    protected function fields(): array
    {
        return [
            'title' => ['label' => 'Hizmet Adı', 'type' => 'text', 'rules' => 'required|max:150', 'col' => 8],
            'icon' => ['label' => 'İkon (Bootstrap Icons)', 'type' => 'icon', 'rules' => 'max:60', 'col' => 4, 'help' => 'Örn: bi-code-slash, bi-cpu, bi-phone. Liste: icons.getbootstrap.com'],
            'slug' => ['label' => 'URL (slug)', 'type' => 'text', 'rules' => 'max:190', 'col' => 8, 'help' => 'Boş bırakılırsa başlıktan otomatik oluşturulur.'],
            'sort_order' => ['label' => 'Sıra', 'type' => 'number', 'col' => 4],
            'short_description' => ['label' => 'Kısa Açıklama', 'type' => 'textarea', 'rules' => 'required|max:300'],
            'content' => ['label' => 'Detaylı İçerik', 'type' => 'html', 'help' => 'HTML desteklenir: p, h2, h3, ul, li, strong, a, img... (zararlı kodlar otomatik temizlenir)'],
            'image' => ['label' => 'Görsel', 'type' => 'image'],
            'meta_title' => ['label' => 'SEO Başlık', 'type' => 'text', 'rules' => 'max:190', 'col' => 6],
            'meta_description' => ['label' => 'SEO Açıklama', 'type' => 'text', 'rules' => 'max:300', 'col' => 6],
            'is_active' => ['label' => 'Yayında', 'type' => 'checkbox'],
        ];
    }

    protected function columns(): array
    {
        return ['icon' => ['', 'icon'], 'title' => ['Hizmet'], 'sort_order' => ['Sıra'], 'is_active' => ['Durum', 'bool']];
    }
}
