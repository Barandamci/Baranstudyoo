<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\AdminController;
use App\Core\Cache;
use App\Core\Request;
use App\Core\Validator;
use App\Models\Setting;

final class SettingController extends AdminController
{
    protected string $permission = 'settings';

    public static function groups(): array
    {
        return [
            'genel' => ['Genel', [
                'site_title' => ['Site Başlığı', 'text'],
                'site_tagline' => ['Slogan', 'text'],
                'site_description' => ['Meta Açıklama (SEO)', 'textarea'],
                'site_keywords' => ['Anahtar Kelimeler', 'text'],
                'footer_text' => ['Footer Metni', 'textarea'],
                'og_image' => ['Paylaşım Görseli (Open Graph, 1200x630)', 'image'],
            ]],
            'anasayfa' => ['Ana Sayfa', [
                'hero_badge' => ['Hero Rozet Metni', 'text'],
                'hero_title' => ['Hero Başlık', 'text'],
                'hero_subtitle' => ['Hero Alt Metin', 'textarea'],
            ]],
            'hakkimizda' => ['Hakkımızda', [
                'about_title' => ['Başlık', 'text'],
                'about_text' => ['Firma Bilgileri', 'textarea'],
                'mission' => ['Misyon', 'textarea'],
                'vision' => ['Vizyon', 'textarea'],
                'values' => ['Değerler (her satıra "Başlık|Açıklama")', 'textarea'],
            ]],
            'iletisim' => ['İletişim', [
                'contact_email' => ['E-posta', 'email'],
                'contact_phone' => ['Telefon', 'text'],
                'contact_address' => ['Adres', 'text'],
                'working_hours' => ['Çalışma Saatleri', 'text'],
                'notification_email' => ['Form Bildirim E-postası', 'email'],
                'whatsapp_number' => ['WhatsApp Numarası (905xxxxxxxxx)', 'text'],
                'whatsapp_message' => ['WhatsApp Varsayılan Mesaj', 'text'],
            ]],
            'sosyal' => ['Sosyal Medya', [
                'social_instagram' => ['Instagram', 'url'],
                'social_linkedin' => ['LinkedIn', 'url'],
                'social_github' => ['GitHub', 'url'],
                'social_x' => ['X (Twitter)', 'url'],
                'social_youtube' => ['YouTube', 'url'],
            ]],
            'domain' => ['Domain Ayarları', [
                'domain_enabled' => ['Domain sorgulama', 'select', ['1' => 'Açık', '0' => 'Kapalı']],
                'domain_tlds' => ['Sorgulanabilir uzantılar (virgülle)', 'text'],
                'domain_rate_limit' => ['IP başına 10 dakikada en fazla sorgu', 'number'],
                'domain_cache_minutes' => ['Sonuç önbellek süresi (dakika)', 'number'],
            ]],
            'sistem' => ['Sistem', [
                'registration_enabled' => ['Yeni üye kaydı', 'select', ['1' => 'Açık', '0' => 'Kapalı (Owner kaydı her zaman açıktır)']],
            ]],
            'entegrasyon' => ['Entegrasyonlar', [
                'google_analytics_id' => ['Google Analytics Ölçüm Kimliği (G-XXXXXXX)', 'text'],
                'google_site_verification' => ['Google Search Console Doğrulama Kodu', 'text'],
            ]],
        ];
    }

    public function index(): void
    {
        $this->view('settings/index', ['title' => 'Site Ayarları', 'groups' => self::groups(), 'values' => Setting::allCached()]);
    }

    public function update(): void
    {
        $back = admin_url('settings');
        $current = Setting::allCached();
        $values = [];
        foreach (self::groups() as [, $fields]) {
            foreach ($fields as $key => $def) {
                [$label, $type] = $def;
                if ($type === 'image') {
                    if (Request::file($key) || Request::bool('remove_' . $key)) {
                        $values[$key] = (string) $this->handleImage($key, 'settings', $current[$key] ?? null, $back);
                    }
                    continue;
                }
                if (!array_key_exists($key, $_POST)) {
                    continue;
                }
                $value = mb_substr(Request::input($key), 0, 5000);
                $rule = match ($type) { 'email' => 'email', 'url' => 'url', default => '' };
                if ($rule && Validator::make([$key => $value], [$key => $rule], [$key => $label])->fails()) {
                    $this->fail("$label alanı geçersiz.", $back, $_POST);
                }
                if ($type === 'select' && !array_key_exists($value, $def[2])) {
                    $value = (string) array_key_first($def[2]);
                }
                if ($key === 'domain_tlds') {
                    $value = implode(',', array_filter(array_map(static fn ($t) => trim(ltrim(trim($t), '.')), explode(',', mb_strtolower($value))), static fn ($t) => (bool) preg_match('/^[a-z0-9]+(\.[a-z0-9]+)?$/', $t)));
                }
                if ($type === 'number') {
                    $value = (string) max(0, (int) $value);
                }
                if ($key === 'google_analytics_id' && $value !== '' && !preg_match('/^(G|UA|GT|AW)-[A-Z0-9\-]+$/i', $value)) {
                    $this->fail('Google Analytics kimliği G-XXXXXXX formatında olmalıdır.', $back, $_POST);
                }
                $values[$key] = $value;
            }
        }
        Setting::setMany($values);
        $this->log('settings', 'Site ayarları güncellendi');
        $this->success('Ayarlar kaydedildi.', $back . '#' . preg_replace('/[^a-z]/', '', Request::input('_tab', 'genel')));
    }

    public function clearCache(): void
    {
        $count = Cache::clear();
        $this->log('cache', "Önbellek temizlendi ($count dosya)");
        $this->success("Önbellek temizlendi ($count dosya).", admin_url('settings'));
    }
}
