<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\ResourceController;
use App\Models\Site;

final class SiteController extends ResourceController
{
    protected string $permission = 'sites';
    protected string $model = Site::class;
    protected string $route = 'sites';
    protected string $singular = 'Site';
    protected string $plural = "Baran Stüdyo'ya Ait Siteler";
    protected string $uploadFolder = 'sites';
    protected string $searchColumn = 'name';
    protected ?string $slugSource = null;

    protected function fields(): array
    {
        return [
            'name' => ['label' => 'Site Adı', 'type' => 'text', 'rules' => 'required|max:150', 'col' => 6],
            'domain' => ['label' => 'Domain', 'type' => 'text', 'rules' => 'required|max:190', 'col' => 6, 'help' => 'Örn: baranstudyo.net.tr'],
            'url' => ['label' => 'Bağlantı', 'type' => 'url', 'rules' => 'url|max:255', 'col' => 8, 'help' => 'Boş bırakılırsa https://domain kullanılır.'],
            'sort_order' => ['label' => 'Sıra', 'type' => 'number', 'col' => 4],
            'description' => ['label' => 'Açıklama', 'type' => 'textarea', 'rules' => 'max:600'],
            'logo' => ['label' => 'Logo', 'type' => 'image'],
            'is_active' => ['label' => 'Yayında', 'type' => 'checkbox'],
        ];
    }

    protected function columns(): array
    {
        return ['logo' => ['', 'image'], 'name' => ['Site'], 'domain' => ['Domain'], 'sort_order' => ['Sıra'], 'is_active' => ['Durum', 'bool']];
    }

    protected function prepare(array $data, ?array $existing): array
    {
        $domain = mb_strtolower(trim($data['domain']));
        $domain = preg_replace('#^https?://#', '', $domain) ?? '';
        $domain = rtrim(explode('/', $domain)[0], '.');
        if (!preg_match('/^([a-z0-9]([a-z0-9\-]{0,61}[a-z0-9])?\.)+[a-z]{2,}$/', $domain)) {
            $this->fail('Geçerli bir domain girin (örn: baranstudyo.net.tr).', $existing ? admin_url("sites/{$existing['id']}/edit") : admin_url('sites/create'), $_POST);
        }
        $data['domain'] = $domain;
        $data['url'] = $data['url'] ?: 'https://' . $domain;
        return $data;
    }
}
