<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\ResourceController;
use App\Models\Testimonial;

final class TestimonialController extends ResourceController
{
    protected string $permission = 'testimonials';
    protected string $model = Testimonial::class;
    protected string $route = 'testimonials';
    protected string $singular = 'Referans';
    protected string $plural = 'Referanslar';
    protected string $uploadFolder = 'testimonials';
    protected string $searchColumn = 'client_name';
    protected ?string $slugSource = null;

    protected function fields(): array
    {
        return [
            'client_name' => ['label' => 'Ad Soyad', 'type' => 'text', 'rules' => 'required|max:120', 'col' => 4],
            'company' => ['label' => 'Firma', 'type' => 'text', 'rules' => 'max:150', 'col' => 4],
            'position' => ['label' => 'Ünvan', 'type' => 'text', 'rules' => 'max:120', 'col' => 4],
            'comment' => ['label' => 'Yorum', 'type' => 'textarea', 'rules' => 'required|max:1000'],
            'rating' => ['label' => 'Puan', 'type' => 'select', 'options' => ['5' => '5 Yıldız', '4' => '4 Yıldız', '3' => '3 Yıldız', '2' => '2 Yıldız', '1' => '1 Yıldız'], 'col' => 4],
            'sort_order' => ['label' => 'Sıra', 'type' => 'number', 'col' => 4],
            'logo' => ['label' => 'Fotoğraf / Logo', 'type' => 'image'],
            'is_active' => ['label' => 'Yayında', 'type' => 'checkbox'],
        ];
    }

    protected function columns(): array
    {
        return ['logo' => ['', 'image'], 'client_name' => ['Ad Soyad'], 'company' => ['Firma'], 'rating' => ['Puan'], 'is_active' => ['Durum', 'bool']];
    }
}
