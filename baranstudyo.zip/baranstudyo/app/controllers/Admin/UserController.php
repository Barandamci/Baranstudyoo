<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Auth;
use App\Core\Request;
use App\Core\ResourceController;
use App\Models\User;

final class UserController extends ResourceController
{
    protected string $permission = 'users';
    protected string $model = User::class;
    protected string $route = 'users';
    protected string $singular = 'Kullanıcı';
    protected string $plural = 'Kullanıcılar';
    protected string $searchColumn = 'name';
    protected ?string $slugSource = null;

    protected function fields(): array
    {
        return [
            'name' => ['label' => 'Ad Soyad', 'type' => 'text', 'rules' => 'required|max:100', 'col' => 6],
            'email' => ['label' => 'E-posta', 'type' => 'email', 'rules' => 'required|email|max:190', 'col' => 6],
            'role' => ['label' => 'Rol', 'type' => 'select', 'options' => ['user' => 'Üye (panel erişimi yok)', 'editor' => 'Editör (proje, site, blog)', 'admin' => 'Yönetici (içerik yönetimi)'], 'col' => 6],
            'password' => ['label' => 'Şifre', 'type' => 'password', 'col' => 6, 'help' => 'En az 10 karakter; büyük/küçük harf ve rakam içermeli. Düzenlemede boş bırakırsanız değişmez.'],
            'is_active' => ['label' => 'Aktif', 'type' => 'checkbox'],
        ];
    }

    protected function columns(): array
    {
        return ['name' => ['Ad Soyad'], 'email' => ['E-posta'], 'role' => ['Rol', 'role'], 'last_login_at' => ['Son Giriş', 'datetime'], 'last_login_ip' => ['Son IP'], 'is_active' => ['Durum', 'bool']];
    }

    protected function prepare(array $data, ?array $existing): array
    {
        $back = $existing ? admin_url("users/{$existing['id']}/edit") : admin_url('users/create');
        $data['email'] = mb_strtolower($data['email']);
        if (User::emailTaken($data['email'], $existing ? (int) $existing['id'] : null)) {
            $this->fail('Bu e-posta adresi zaten kullanılıyor.', $back, $_POST);
        }
        $password = (string) ($_POST['password'] ?? '');
        if ($existing === null || $password !== '') {
            if ($error = self::passwordError($password)) {
                $this->fail($error, $back, $_POST);
            }
            $data['password'] = password_hash($password, PASSWORD_DEFAULT);
        }
        if ($existing && $existing['role'] === 'owner') {
            $data['role'] = $existing['role'];
            $data['is_active'] = 1;
        }
        return $data;
    }

    protected function beforeDelete(array $item): void
    {
        if ((int) $item['id'] === Auth::id()) {
            $this->fail('Kendi hesabınızı silemezsiniz.');
        }
        if ($item['role'] === 'owner') {
            $this->fail('Owner hesabı silinemez.');
        }
    }

    public static function passwordError(string $password): ?string
    {
        if (mb_strlen($password) < 10 || !preg_match('/[a-z]/', $password) || !preg_match('/[A-Z]/', $password) || !preg_match('/\d/', $password)) {
            return 'Şifre en az 10 karakter olmalı ve büyük harf, küçük harf ile rakam içermelidir.';
        }
        return null;
    }
}
