<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Seo;
use App\Models\Post;

final class BlogController extends Controller
{
    public function index(): void
    {
        $result = Post::paginate(Request::page(), 9, Post::PUBLISHED, [], 'published_at DESC');
        $seo = Seo::make('Blog', 'Web yazılım, yapay zekâ, e-ticaret ve dijital dönüşüm üzerine güncel yazılar.', '/blog')
            ->breadcrumbs([['Blog', '/blog']]);
        if ($result['page'] > 1) {
            $seo->canonical = absolute_url('blog') . '?sayfa=' . $result['page'];
        }
        $this->view('blog/index', ['seo' => $seo, 'result' => $result]);
    }

    public function show(string $slug): void
    {
        $post = Post::findPublishedBySlug($slug) ?? $this->notFound();
        Post::incrementViews((int) $post['id']);
        $seo = Seo::make($post['meta_title'] ?: $post['title'], $post['meta_description'] ?: $post['excerpt'], '/blog/' . $post['slug'])
            ->image($post['image'])
            ->type('article')
            ->breadcrumbs([['Blog', '/blog'], [$post['title'], '/blog/' . $post['slug']]])
            ->schema(array_filter([
                '@context' => 'https://schema.org',
                '@type' => 'BlogPosting',
                'headline' => $post['title'],
                'description' => $post['excerpt'],
                'datePublished' => date('c', strtotime((string) $post['published_at'])),
                'dateModified' => date('c', strtotime((string) ($post['updated_at'] ?: $post['published_at']))),
                'image' => $post['image'] ? absolute_url('uploads/' . $post['image']) : null,
                'author' => ['@type' => 'Person', 'name' => $post['author_name'] ?: setting('site_title', config('app.name'))],
                'publisher' => ['@type' => 'Organization', 'name' => setting('site_title', config('app.name')), 'logo' => ['@type' => 'ImageObject', 'url' => absolute_url('assets/img/logo.png')]],
                'mainEntityOfPage' => absolute_url('blog/' . $post['slug']),
            ]));
        $recent = array_values(array_filter(Post::latest(4), static fn ($p) => (int) $p['id'] !== (int) $post['id']));
        $this->view('blog/show', ['seo' => $seo, 'post' => $post, 'recent' => array_slice($recent, 0, 3)]);
    }
}
