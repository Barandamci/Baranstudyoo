<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Logger;
use App\Core\Mailer;
use App\Core\RateLimiter;
use App\Core\Request;
use App\Core\Response;
use App\Core\Seo;
use App\Core\Session;
use App\Core\Validator;
use App\Core\View;
use App\Models\ActivityLog;
use App\Models\Message;
use App\Models\Service;

final class ContactController extends Controller
{
    public function index(): void
    {
        $seo = Seo::make('İletişim', 'Projeniz için Baran Stüdyo ile iletişime geçin. Ücretsiz keşif görüşmesi ve teklif için bize yazın.', '/iletisim')
            ->breadcrumbs([['İletişim', '/iletisim']]);
        $seo->schema(['@context' => 'https://schema.org', '@type' => 'ContactPage', 'name' => 'İletişim', 'url' => absolute_url('iletisim')]);
        $this->view('contact/index', ['seo' => $seo, 'services' => Service::active()]);
    }

    public function send(): void
    {
        $ajax = Request::isAjax();
        $data = [
            'name'    => Request::input('name'),
            'email'   => mb_strtolower(Request::input('email')),
            'phone'   => Request::input('phone'),
            'subject' => Request::input('subject'),
            'message' => Request::input('message'),
        ];

        // Honeypot alanı (botlar doldurur, insanlar görmez)
        if (Request::input('website') !== '') {
            $this->respond($ajax, true, 'Mesajınız alındı. Teşekkür ederiz!');
        }

        // Formun çok hızlı gönderilmesi (bot) kontrolü
        $started = (int) Request::input('_ts');
        if ($started > 0 && time() - $started < 3) {
            $this->respond($ajax, false, 'Lütfen formu kontrol edip tekrar gönderin.', [], $data);
        }

        $v = Validator::make($data, [
            'name'    => 'required|min:3|max:120',
            'email'   => 'required|email|max:190',
            'phone'   => 'phone|max:30',
            'subject' => 'required|min:3|max:200',
            'message' => 'required|min:10|max:5000',
        ], ['name' => 'Ad Soyad', 'email' => 'E-posta', 'phone' => 'Telefon', 'subject' => 'Konu', 'message' => 'Mesaj']);

        if ($v->fails()) {
            $this->respond($ajax, false, $v->firstError(), $v->errors(), $data);
        }

        $ip = client_ip();
        if (RateLimiter::tooMany('contact:' . $ip, (int) config('security.contact_max_per_window', 5), (int) config('security.contact_window_minutes', 10) * 60)) {
            $this->respond($ajax, false, 'Çok fazla mesaj gönderdiniz. Lütfen bir süre sonra tekrar deneyin.', [], $data);
        }

        $id = Message::create($data + ['ip' => $ip, 'user_agent' => user_agent(), 'is_read' => 0]);
        ActivityLog::log('contact', "İletişim formu gönderildi (#$id): " . $data['email'], null);

        $to = (string) setting('notification_email', setting('contact_email'));
        if ($to !== '') {
            $html = View::render('emails/contact', ['m' => $data + ['id' => $id, 'ip' => $ip]], null);
            if (!Mailer::send($to, 'Yeni iletişim mesajı: ' . $data['subject'], $html, $data['email'], $data['name'])) {
                Logger::info('İletişim bildirimi e-postası gönderilemedi', ['message_id' => $id]);
            }
        }

        $this->respond($ajax, true, 'Mesajınız başarıyla gönderildi. En kısa sürede size dönüş yapacağız.');
    }

    private function respond(bool $ajax, bool $success, string $message, array $errors = [], array $input = []): never
    {
        if ($ajax) {
            Response::json(['success' => $success, 'message' => $message, 'errors' => $errors], $success ? 200 : 422);
        }
        Session::flash($success ? 'success' : 'error', $message);
        if (!$success) {
            Session::withInput($input);
        }
        Response::redirect(url('iletisim') . '#iletisim-formu');
    }
}
