<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\DomainChecker;
use App\Core\RateLimiter;
use App\Core\Request;
use App\Core\Seo;

final class DomainController extends Controller
{
    public function index(): void
    {
        $this->guard();
        $lookup = Request::input('domain') !== '' ? $this->lookup(Request::input('domain'), Request::input('tld')) : null;
        $this->view('domain/index', [
            'seo' => Seo::make('Domain Sorgulama', 'Alan adınızın müsait olup olmadığını gerçek RDAP/WHOIS kayıtlarından anında sorgulayın.', '/domain-sorgula'),
            'lookup' => $lookup,
        ]);
    }

    public function api(): void
    {
        $this->guard();
        header('Cache-Control: no-store');
        $lookup = $this->lookup(Request::input('domain'), Request::input('tld'));
        $this->json($lookup, $lookup['ok'] ? 200 : 422);
    }

    private function guard(): void
    {
        if (setting('domain_enabled', '1') !== '1') {
            $this->notFound();
        }
    }

    private function lookup(string $name, string $tld): array
    {
        [$domain, $error] = DomainChecker::normalize(mb_substr($name, 0, 120), mb_substr($tld, 0, 20));
        if ($error) {
            return ['ok' => false, 'message' => $error];
        }
        if (RateLimiter::tooMany('domain:' . client_ip(), max(1, (int) setting('domain_rate_limit', 30)), 600)) {
            return ['ok' => false, 'message' => 'Çok fazla sorgu yaptınız. Lütfen birkaç dakika sonra tekrar deneyin.'];
        }
        $result = DomainChecker::check((string) $domain);
        if ($result['status'] === 'unknown') {
            return ['ok' => false, 'message' => 'Kayıt sunucusuna şu an ulaşılamadı, sonuç belirlenemedi. Lütfen biraz sonra tekrar deneyin.', 'result' => $result];
        }
        return ['ok' => true, 'message' => '', 'result' => $result];
    }
}
