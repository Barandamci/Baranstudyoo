<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;

final class ErrorController extends Controller
{
    public function notFoundPage(): void
    {
        $this->notFound();
    }
}
