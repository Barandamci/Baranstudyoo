<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Seo;
use App\Models\Post;
use App\Models\Project;
use App\Models\Service;
use App\Models\Site;

final class HomeController extends Controller
{
    public function index(): void
    {
        $seo = Seo::make(null, null, '/');
        $this->view('home/index', [
            'seo' => $seo,
            'services' => Service::active(),
            'projects' => Project::featured(6),
            'sites' => Site::active(),
            'posts' => Post::latest(3),
        ]);
    }
}
