<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Seo;
use App\Models\Service;

final class PageController extends Controller
{
    public function about(): void
    {
        $values = [];
        foreach (preg_split('/\R/', (string) setting('values')) ?: [] as $line) {
            if (trim($line) === '') {
                continue;
            }
            [$title, $desc] = array_pad(explode('|', $line, 2), 2, '');
            $values[] = ['title' => trim($title), 'description' => trim($desc)];
        }
        $seo = Seo::make('Hakkımızda', setting('about_text'), '/hakkimizda')->breadcrumbs([['Hakkımızda', '/hakkimizda']]);
        $seo->schema(['@context' => 'https://schema.org', '@type' => 'AboutPage', 'name' => 'Hakkımızda', 'url' => absolute_url('hakkimizda')]);
        $this->view('pages/about', ['seo' => $seo, 'values' => $values, 'services' => Service::active()]);
    }
}
