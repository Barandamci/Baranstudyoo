<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Seo;
use App\Models\Project;

final class ProjectController extends Controller
{
    public function index(): void
    {
        $result = Project::paginate(Request::page(), 9, 'is_active = 1');
        $seo = Seo::make('Projelerimiz', 'Baran Stüdyo tarafından geliştirilen web, mobil, e-ticaret ve yapay zekâ projelerinden örnekler.', '/projeler')
            ->breadcrumbs([['Projeler', '/projeler']]);
        if ($result['page'] > 1) {
            $seo->canonical = absolute_url('projeler') . '?sayfa=' . $result['page'];
        }
        $categories = array_values(array_unique(array_filter(array_column($result['items'], 'category'))));
        $this->view('projects/index', ['seo' => $seo, 'result' => $result, 'categories' => $categories]);
    }

    public function show(string $slug): void
    {
        $project = Project::findActiveBySlug($slug) ?? $this->notFound();
        $seo = Seo::make($project['title'], $project['summary'], '/projeler/' . $project['slug'])
            ->image($project['image'])
            ->breadcrumbs([['Projeler', '/projeler'], [$project['title'], '/projeler/' . $project['slug']]])
            ->schema(array_filter([
                '@context' => 'https://schema.org',
                '@type' => 'CreativeWork',
                'name' => $project['title'],
                'description' => $project['summary'],
                'dateCreated' => $project['project_date'],
                'image' => $project['image'] ? absolute_url('uploads/' . $project['image']) : null,
                'creator' => ['@type' => 'Organization', 'name' => setting('site_title', config('app.name'))],
                'keywords' => $project['technologies'],
            ]));
        $this->view('projects/show', ['seo' => $seo, 'project' => $project, 'related' => Project::related((int) $project['id'])]);
    }
}
