<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Cache;
use App\Core\Controller;
use App\Models\Post;
use App\Models\Project;
use App\Models\Service;

final class SeoController extends Controller
{
    public function sitemap(): void
    {
        $xml = Cache::remember('sitemap.xml', 3600, function (): string {
            $urls = [
                ['/', null, '1.0', 'weekly'],
                ['/hakkimizda', null, '0.8', 'monthly'],
                ['/hizmetler', null, '0.9', 'monthly'],
                ['/projeler', null, '0.8', 'weekly'],
                ['/blog', null, '0.8', 'daily'],
                ['/siteler', null, '0.8', 'weekly'],
                ['/domain-sorgula', null, '0.7', 'monthly'],
                ['/iletisim', null, '0.7', 'yearly'],
            ];
            foreach (Service::active() as $s) {
                $urls[] = ['/hizmetler/' . $s['slug'], $s['updated_at'] ?: $s['created_at'], '0.8', 'monthly'];
            }
            foreach (Project::all('is_active = 1') as $p) {
                $urls[] = ['/projeler/' . $p['slug'], $p['updated_at'] ?: $p['created_at'], '0.7', 'monthly'];
            }
            foreach (Post::all(Post::PUBLISHED, [], 'published_at DESC') as $p) {
                $urls[] = ['/blog/' . $p['slug'], $p['updated_at'] ?: $p['published_at'], '0.6', 'monthly'];
            }
            $out = '<?xml version="1.0" encoding="UTF-8"?>' . "\n" . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
            foreach ($urls as [$path, $mod, $prio, $freq]) {
                $out .= '  <url><loc>' . htmlspecialchars(absolute_url($path), ENT_XML1) . '</loc>'
                    . ($mod ? '<lastmod>' . date('Y-m-d', strtotime((string) $mod)) . '</lastmod>' : '')
                    . "<changefreq>$freq</changefreq><priority>$prio</priority></url>\n";
            }
            return $out . '</urlset>';
        });
        header('Content-Type: application/xml; charset=utf-8');
        echo $xml;
    }

    public function robots(): void
    {
        header('Content-Type: text/plain; charset=utf-8');
        echo "User-agent: *\n"
            . "Allow: /\n"
            . "Disallow: " . url('admin/') . "\n"
            . "Disallow: " . url('app/') . "\n"
            . "Disallow: " . url('config/') . "\n"
            . "Disallow: " . url('storage/') . "\n\n"
            . "Sitemap: " . absolute_url('sitemap.xml') . "\n";
    }
}
