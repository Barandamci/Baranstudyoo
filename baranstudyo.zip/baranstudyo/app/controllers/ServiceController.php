<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Seo;
use App\Models\Service;

final class ServiceController extends Controller
{
    public function index(): void
    {
        $seo = Seo::make('Hizmetlerimiz', 'Web tasarım, özel PHP yazılım, e-ticaret, mobil uygulama, API entegrasyonu, yapay zekâ, otomasyon ve sunucu yönetimi hizmetleri.', '/hizmetler')
            ->breadcrumbs([['Hizmetler', '/hizmetler']]);
        $this->view('services/index', ['seo' => $seo, 'services' => Service::active()]);
    }

    public function show(string $slug): void
    {
        $service = Service::findActiveBySlug($slug) ?? $this->notFound();
        $seo = Seo::make($service['meta_title'] ?: $service['title'], $service['meta_description'] ?: $service['short_description'], '/hizmetler/' . $service['slug'])
            ->image($service['image'])
            ->breadcrumbs([['Hizmetler', '/hizmetler'], [$service['title'], '/hizmetler/' . $service['slug']]])
            ->schema([
                '@context' => 'https://schema.org',
                '@type' => 'Service',
                'name' => $service['title'],
                'description' => $service['short_description'],
                'provider' => ['@type' => 'Organization', 'name' => setting('site_title', config('app.name')), 'url' => absolute_url()],
                'areaServed' => 'TR',
            ]);
        $others = array_values(array_filter(Service::active(), static fn ($s) => (int) $s['id'] !== (int) $service['id']));
        $this->view('services/show', ['seo' => $seo, 'service' => $service, 'others' => $others]);
    }
}
