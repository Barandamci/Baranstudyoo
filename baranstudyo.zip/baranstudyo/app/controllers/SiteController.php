<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Seo;
use App\Models\Site;

final class SiteController extends Controller
{
    public function index(): void
    {
        $this->view('sites/index', [
            'seo' => Seo::make("Baran Stüdyo'ya Ait Siteler", 'Baran Stüdyo tarafından geliştirilen ve yönetilen web siteleri.', '/siteler'),
            'sites' => Site::active(),
        ]);
    }
}
