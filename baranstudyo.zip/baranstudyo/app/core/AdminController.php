<?php
declare(strict_types=1);

namespace App\Core;

use App\Models\ActivityLog;

/** Yönetim paneli denetleyicileri için temel sınıf: kimlik doğrulama + yetki kontrolü */
abstract class AdminController extends Controller
{
    protected string $permission = 'dashboard';

    public function __construct()
    {
        header('Cache-Control: no-store, no-cache, must-revalidate');
        header('X-Robots-Tag: noindex, nofollow');
        if (!Auth::check()) {
            if (Request::isAjax()) {
                Response::json(['success' => false, 'message' => 'Oturumunuz sona erdi.'], 401);
            }
            Session::flash('error', 'Lütfen giriş yapın.');
            Response::redirect(admin_url('login'));
        }
        if (!Auth::can('dashboard')) {
            Session::flash('error', 'Yönetim paneline erişim yetkiniz yok.');
            Response::redirect(url('hesabim'));
        }
        if (!Auth::can($this->permission)) {
            http_response_code(403);
            echo View::render('admin/errors/403', ['title' => 'Yetkisiz Erişim'], 'admin/layouts/main');
            exit;
        }
    }

    protected function view(string $view, array $data = [], ?string $layout = 'admin/layouts/main'): void
    {
        echo View::render('admin/' . $view, $data, $layout);
    }

    protected function success(string $message, string $redirect): never
    {
        Session::flash('success', $message);
        Response::redirect($redirect);
    }

    protected function fail(string $message, ?string $redirect = null, array $input = []): never
    {
        Session::flash('error', $message);
        if ($input) {
            Session::withInput($input);
        }
        Response::redirect($redirect ?? (Request::referer() ?? admin_url()));
    }

    protected function log(string $action, string $description): void
    {
        ActivityLog::log($action, $description);
    }

    /** Görsel yükleme yardımcı metodu; hata durumunda formu geri döndürür */
    protected function handleImage(string $field, string $folder, ?string $current, string $back): ?string
    {
        $file = Request::file($field);
        if (Request::bool('remove_' . $field) && !$file) {
            Uploader::delete($current);
            return null;
        }
        if (!$file) {
            return $current;
        }
        try {
            $path = Uploader::image($file, $folder);
        } catch (\RuntimeException $e) {
            $this->fail($e->getMessage(), $back, $_POST);
        }
        Uploader::delete($current);
        return $path;
    }
}
