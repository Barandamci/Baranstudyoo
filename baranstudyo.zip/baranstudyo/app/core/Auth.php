<?php
declare(strict_types=1);

namespace App\Core;

use App\Models\ActivityLog;
use App\Models\LoginAttempt;
use App\Models\User;

final class Auth
{
    private static ?array $user = null;

    /** @return array{ok: bool, message: string} */
    public static function attempt(string $email, string $password): array
    {
        $ip = client_ip();
        $email = mb_strtolower(trim($email));
        $decay = (int) config('security.login_decay_minutes', 15);

        if (LoginAttempt::isLocked($ip, $email)) {
            ActivityLog::log('login_blocked', "Kilitli hesaba giriş denemesi: $email");
            return ['ok' => false, 'message' => "Çok fazla başarısız deneme. Lütfen $decay dakika sonra tekrar deneyin."];
        }

        $user = User::findByEmail($email);
        // Kullanıcı yoksa da hash doğrulaması yaparak zamanlama saldırısını önle
        $hash = $user['password'] ?? '$2y$10$6n5fVP2qAe/DsVTuPUjm2uqUgX3c16aQu0z0Qyl4nQsQdudS3.qXy';
        $valid = password_verify($password, $hash);

        if (!$user || !$valid || !(int) $user['is_active']) {
            LoginAttempt::record($ip, $email, false);
            ActivityLog::log('login_failed', "Başarısız giriş: $email");
            $left = LoginAttempt::remaining($ip, $email);
            return ['ok' => false, 'message' => 'E-posta veya şifre hatalı.' . ($left <= 2 ? " Kalan deneme hakkı: $left" : '')];
        }

        if (password_needs_rehash($user['password'], PASSWORD_DEFAULT)) {
            User::update((int) $user['id'], ['password' => password_hash($password, PASSWORD_DEFAULT)]);
        }

        LoginAttempt::record($ip, $email, true);
        LoginAttempt::clear($ip, $email);
        Session::regenerate();
        $_SESSION['admin'] = [
            'id' => (int) $user['id'],
            'fingerprint' => self::fingerprint(),
            'login_at' => time(),
        ];
        unset($_SESSION['_csrf']);
        User::touchLogin((int) $user['id'], $ip);
        ActivityLog::log('login', 'Giriş yapıldı', (int) $user['id']);
        return ['ok' => true, 'message' => 'Hoş geldiniz.'];
    }

    private static function fingerprint(): string
    {
        return hash('sha256', user_agent() . '|' . config('session.name'));
    }

    public static function user(): ?array
    {
        if (self::$user !== null) {
            return self::$user;
        }
        $s = $_SESSION['admin'] ?? null;
        if (!is_array($s) || empty($s['id'])) {
            return null;
        }
        if (!hash_equals((string) $s['fingerprint'], self::fingerprint())) {
            self::logout();
            return null;
        }
        $user = User::find((int) $s['id']);
        if (!$user || !(int) $user['is_active']) {
            self::logout();
            return null;
        }
        unset($user['password']);
        return self::$user = $user;
    }

    public static function check(): bool
    {
        return self::user() !== null;
    }

    public static function id(): ?int
    {
        return isset(self::user()['id']) ? (int) self::user()['id'] : null;
    }

    public static function can(string $permission): bool
    {
        $user = self::user();
        if (!$user) {
            return false;
        }
        $perms = (array) (config('roles')[$user['role']] ?? []);
        return in_array('*', $perms, true) || in_array($permission, $perms, true);
    }

    public static function logout(): void
    {
        self::$user = null;
        unset($_SESSION['admin']);
        Session::regenerate();
    }
}
