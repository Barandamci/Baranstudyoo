<?php
declare(strict_types=1);

namespace App\Core;

/** Dosya tabanlı basit önbellek (shared hosting uyumlu, ek eklenti gerektirmez) */
final class Cache
{
    private static function path(string $key): string
    {
        return STORAGE_PATH . '/cache/' . hash('sha256', $key) . '.cache';
    }

    public static function enabled(): bool
    {
        return (bool) config('cache.enabled', true);
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        if (!self::enabled()) {
            return $default;
        }
        $file = self::path($key);
        if (!is_file($file)) {
            return $default;
        }
        $raw = @file_get_contents($file);
        if ($raw === false) {
            return $default;
        }
        $payload = @unserialize($raw, ['allowed_classes' => false]);
        if (!is_array($payload) || ($payload['expires'] ?? 0) < time()) {
            @unlink($file);
            return $default;
        }
        return $payload['value'];
    }

    public static function set(string $key, mixed $value, int $ttl): void
    {
        if (!self::enabled() || $ttl <= 0) {
            return;
        }
        $dir = STORAGE_PATH . '/cache';
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
        $tmp = self::path($key) . '.' . bin2hex(random_bytes(4));
        if (@file_put_contents($tmp, serialize(['expires' => time() + $ttl, 'value' => $value]), LOCK_EX) !== false) {
            @rename($tmp, self::path($key));
        }
    }

    public static function remember(string $key, int $ttl, callable $callback): mixed
    {
        $value = self::get($key, $miss = new \stdClass());
        if ($value !== $miss && !($value instanceof \stdClass)) {
            return $value;
        }
        $value = $callback();
        self::set($key, $value, $ttl);
        return $value;
    }

    public static function forget(string $key): void
    {
        @unlink(self::path($key));
    }

    public static function clear(): int
    {
        $count = 0;
        foreach (glob(STORAGE_PATH . '/cache/*.cache') ?: [] as $file) {
            if (@unlink($file)) {
                $count++;
            }
        }
        return $count;
    }
}
