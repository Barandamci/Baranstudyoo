<?php
declare(strict_types=1);

namespace App\Core;

abstract class Controller
{
    protected function view(string $view, array $data = [], ?string $layout = 'layouts/main'): void
    {
        echo View::render($view, $data, $layout);
    }

    protected function json(array $data, int $status = 200): never
    {
        Response::json($data, $status);
    }

    protected function redirect(string $url): never
    {
        Response::redirect($url);
    }

    protected function back(): never
    {
        Response::redirect(Request::referer() ?? url());
    }

    protected function notFound(): never
    {
        http_response_code(404);
        $this->view('errors/404', ['seo' => Seo::make('Sayfa Bulunamadı')->noindex()]);
        exit;
    }
}
