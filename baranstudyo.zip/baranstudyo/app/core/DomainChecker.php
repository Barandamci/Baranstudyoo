<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Gerçek domain sorgulama: önce IANA RDAP bootstrap üzerinden RDAP, desteklenmeyen uzantılarda WHOIS (port 43).
 * Sonuç belirlenemezse "unknown" döner; hiçbir zaman tahmini/sahte sonuç üretmez.
 */
final class DomainChecker
{
    private const BOOTSTRAP_URL = 'https://data.iana.org/rdap/dns.json';
    private const WHOIS_SERVERS = ['tr' => 'whois.trabis.gov.tr', 'io' => 'whois.nic.io', 'co' => 'whois.registry.co'];
    private const NOT_FOUND = '/(no match|not found|no entries found|no data found|status:\s*(free|available)|is available|domain not found|no object found|object does not exist)/i';

    /** @return string[] */
    public static function tlds(): array
    {
        $raw = (string) setting('domain_tlds', 'com,net,org,com.tr,net.tr,org.tr,io,dev,app,info,xyz,online,store');
        $list = [];
        foreach (explode(',', mb_strtolower($raw)) as $t) {
            $t = trim(ltrim(trim($t), '.'));
            if (preg_match('/^[a-z0-9]+(\.[a-z0-9]+)?$/', $t)) {
                $list[] = $t;
            }
        }
        return array_values(array_unique($list)) ?: ['com'];
    }

    /** @return array{0:?string,1:?string} [domain, hata] */
    public static function normalize(string $name, string $tld): array
    {
        $tlds = self::tlds();
        $name = mb_strtolower(trim($name));
        $name = preg_replace('#^[a-z]+://#', '', $name) ?? '';
        $name = preg_replace('#^www\.#', '', $name) ?? '';
        $name = explode('/', $name)[0];
        $tld = mb_strtolower(trim(ltrim($tld, '.')));
        if (str_contains($name, '.')) {
            [$label, $rest] = explode('.', $name, 2);
            if (in_array($rest, $tlds, true)) {
                $tld = $rest;
            }
            $name = $label;
        }
        if ($name === '') {
            return [null, 'Lütfen bir domain adı yazın.'];
        }
        if (!in_array($tld, $tlds, true)) {
            return [null, 'Bu uzantı sorgulanamıyor.'];
        }
        if (preg_match('/[^\x20-\x7e]/', $name)) {
            if (!function_exists('idn_to_ascii')) {
                return [null, 'Türkçe karakterli domainler bu sunucuda sorgulanamıyor. Lütfen Türkçe karakter kullanmayın.'];
            }
            $name = (string) idn_to_ascii($name, IDNA_DEFAULT, INTL_IDNA_VARIANT_UTS46);
        }
        if (!preg_match('/^[a-z0-9]([a-z0-9\-]{0,61}[a-z0-9])?$/', $name)) {
            return [null, 'Domain adı yalnızca harf, rakam ve tire (-) içerebilir; tire ile başlayıp bitemez.'];
        }
        return [$name . '.' . $tld, null];
    }

    public static function check(string $domain): array
    {
        $key = 'domain:' . $domain;
        $cached = Cache::get($key);
        if (is_array($cached)) {
            return $cached;
        }
        $result = self::rdap($domain) ?? self::whois($domain) ?? self::result($domain, 'unknown', '-');
        if ($result['status'] !== 'unknown') {
            Cache::set($key, $result, max(1, (int) setting('domain_cache_minutes', 10)) * 60);
        }
        return $result;
    }

    private static function result(string $domain, string $status, string $source, array $extra = []): array
    {
        return $extra + [
            'domain' => $domain, 'status' => $status, 'source' => $source,
            'created' => null, 'expires' => null, 'updated' => null,
            'registrar' => null, 'nameservers' => [], 'statuses' => [],
            'checked_at' => date('Y-m-d H:i:s'),
        ];
    }

    private static function rdapBase(string $domain): ?string
    {
        $map = Cache::get('rdap:bootstrap');
        if (!is_array($map)) {
            [$code, $body] = self::http(self::BOOTSTRAP_URL);
            $json = $code === 200 ? json_decode($body, true) : null;
            if (!is_array($json) || empty($json['services'])) {
                return null;
            }
            $map = [];
            foreach ($json['services'] as [$tlds, $urls]) {
                $url = null;
                foreach ($urls as $u) {
                    if (str_starts_with($u, 'https://')) { $url = $u; break; }
                }
                foreach ($tlds as $t) {
                    $map[strtolower($t)] = $url ?? $urls[0];
                }
            }
            Cache::set('rdap:bootstrap', $map, 86400);
        }
        $labels = explode('.', $domain);
        array_shift($labels);
        while ($labels) {
            $suffix = implode('.', $labels);
            if (isset($map[$suffix])) {
                return rtrim($map[$suffix], '/') . '/';
            }
            array_shift($labels);
        }
        return null;
    }

    private static function rdap(string $domain): ?array
    {
        $base = self::rdapBase($domain);
        if (!$base) {
            return null;
        }
        [$code, $body] = self::http($base . 'domain/' . rawurlencode($domain));
        if ($code === 404) {
            return self::result($domain, 'available', 'RDAP');
        }
        $data = $code === 200 ? json_decode($body, true) : null;
        if (!is_array($data)) {
            return null;
        }
        $events = [];
        foreach ($data['events'] ?? [] as $ev) {
            $events[$ev['eventAction'] ?? ''] = self::date($ev['eventDate'] ?? null);
        }
        $registrar = null;
        foreach ($data['entities'] ?? [] as $ent) {
            if (in_array('registrar', $ent['roles'] ?? [], true)) {
                foreach ($ent['vcardArray'][1] ?? [] as $v) {
                    if (($v[0] ?? '') === 'fn') { $registrar = (string) $v[3]; }
                }
            }
        }
        $ns = array_map(static fn ($n) => strtolower((string) ($n['ldhName'] ?? '')), $data['nameservers'] ?? []);
        return self::result($domain, 'registered', 'RDAP', [
            'created' => $events['registration'] ?? null,
            'expires' => $events['expiration'] ?? null,
            'updated' => $events['last changed'] ?? null,
            'registrar' => $registrar,
            'nameservers' => array_values(array_filter($ns)),
            'statuses' => array_map('strval', $data['status'] ?? []),
        ]);
    }

    private static function whoisServer(string $domain): ?string
    {
        $tld = substr($domain, strrpos($domain, '.') + 1);
        if (isset(self::WHOIS_SERVERS[$tld])) {
            return self::WHOIS_SERVERS[$tld];
        }
        $server = Cache::get('whois:' . $tld);
        if (is_string($server)) {
            return $server ?: null;
        }
        $resp = self::socket('whois.iana.org', $tld);
        $server = ($resp && preg_match('/^whois:\s*(\S+)/mi', $resp, $m)) ? $m[1] : '';
        Cache::set('whois:' . $tld, $server, 86400);
        return $server ?: null;
    }

    private static function whois(string $domain): ?array
    {
        $server = self::whoisServer($domain);
        $text = $server ? self::socket($server, $domain) : null;
        if (!$text) {
            return null;
        }
        if (preg_match(self::NOT_FOUND, $text)) {
            return self::result($domain, 'available', 'WHOIS');
        }
        $find = static function (array $patterns) use ($text): ?string {
            foreach ($patterns as $p) {
                if (preg_match($p, $text, $m)) { return trim($m[1]); }
            }
            return null;
        };
        $created = $find(['/(?:Creation Date|Created On|Registered on|Registration Time|Created)[ \t.]*:[ \t]*(.+)/i']);
        $expires = $find(['/(?:Registry Expiry Date|Registrar Registration Expiration Date|Expiration Date|Expires on|Expiry Date|paid-till)[ \t.]*:[ \t]*(.+)/i']);
        $updated = $find(['/(?:Updated Date|Last Updated On|Last Update Time)[ \t.]*:[ \t]*(.+)/i']);
        $registrar = $find(['/\*\* Registrar:.*?Organization Name[ \t]*:[ \t]*([^\r\n]+)/is', '/^[ \t]*Registrar:[ \t]*(\S.*)$/mi']);
        $isRegistered = $created || $expires || preg_match('/Domain Status:\s*Active|Domain Name:\s*' . preg_quote($domain, '/') . '/i', $text);
        if (!$isRegistered) {
            return self::result($domain, 'unknown', 'WHOIS');
        }
        preg_match_all('/^\s*(?:Name Server|nserver)[ \t]*:[ \t]*(\S+)/mi', $text, $ns);
        if (!$ns[1] && preg_match('/\*\* Domain Servers:\s*(.+?)\*\*/s', $text, $blk)) {
            $ns[1] = preg_split('/\s+/', trim($blk[1])) ?: [];
        }
        return self::result($domain, 'registered', 'WHOIS', [
            'created' => self::date($created), 'expires' => self::date($expires), 'updated' => self::date($updated),
            'registrar' => $registrar ? mb_substr($registrar, 0, 150) : null,
            'nameservers' => array_slice(array_map('strtolower', $ns[1]), 0, 6),
        ]);
    }

    private static function date(?string $raw): ?string
    {
        if (!$raw) {
            return null;
        }
        $raw = rtrim(trim($raw), '.');
        $ts = strtotime($raw);
        if ($ts === false && preg_match('/^(\d{4})-([A-Za-z]{3})-(\d{1,2})/', $raw, $m)) {
            $ts = strtotime("$m[3] $m[2] $m[1]");
        }
        return $ts ? date('Y-m-d', $ts) : null;
    }

    /** @return array{0:int,1:string} */
    private static function http(string $url): array
    {
        if (function_exists('curl_init')) {
            $buffer = '';
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 3,
                CURLOPT_CONNECTTIMEOUT => 6, CURLOPT_TIMEOUT => 10, CURLOPT_PROTOCOLS => CURLPROTO_HTTPS,
                CURLOPT_HTTPHEADER => ['Accept: application/rdap+json, application/json'],
                CURLOPT_USERAGENT => 'BaranStudyo-DomainCheck/1.0 (+https://baranstudyo.net.tr)',
                CURLOPT_WRITEFUNCTION => static function ($ch, string $chunk) use (&$buffer): int {
                    $buffer .= $chunk;
                    return strlen($buffer) > 2_000_000 ? 0 : strlen($chunk);
                },
            ]);
            $ok = curl_exec($ch);
            $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $errno = curl_errno($ch);
            curl_close($ch);
            // Bazı RDAP sunucuları bağlantıyı TLS close_notify göndermeden kapatır (errno 56); yanıt yine de geçerlidir.
            if ($ok === false && $errno !== 56) {
                return [0, ''];
            }
            return [$code, $buffer];
        }
        $ctx = stream_context_create(['http' => ['timeout' => 10, 'ignore_errors' => true, 'header' => "Accept: application/rdap+json\r\nUser-Agent: BaranStudyo-DomainCheck/1.0\r\n"]]);
        $body = @file_get_contents($url, false, $ctx);
        $code = 0;
        foreach ($http_response_header ?? [] as $h) {
            if (preg_match('#^HTTP/\S+\s+(\d{3})#', $h, $m)) { $code = (int) $m[1]; }
        }
        return [$code, (string) $body];
    }

    private static function socket(string $server, string $query): ?string
    {
        $fp = @fsockopen($server, 43, $errno, $errstr, 6);
        if (!$fp) {
            return null;
        }
        stream_set_timeout($fp, 8);
        fwrite($fp, $query . "\r\n");
        $out = '';
        while (!feof($fp) && strlen($out) < 65536) {
            $chunk = fread($fp, 8192);
            if ($chunk === false || $chunk === '') {
                if (stream_get_meta_data($fp)['timed_out']) { break; }
                continue;
            }
            $out .= $chunk;
        }
        fclose($fp);
        return $out !== '' ? $out : null;
    }
}
