<?php
declare(strict_types=1);

namespace App\Core;

use Throwable;

/** Güvenli hata yönetimi: canlıda detay gizlenir, tüm hatalar log dosyasına yazılır */
final class ErrorHandler
{
    private static bool $debug = false;

    public static function register(bool $debug): void
    {
        self::$debug = $debug;
        error_reporting(E_ALL);
        ini_set('display_errors', $debug ? '1' : '0');
        ini_set('log_errors', '1');

        set_error_handler(static function (int $severity, string $message, string $file, int $line): bool {
            if (!(error_reporting() & $severity)) {
                return false;
            }
            throw new \ErrorException($message, 0, $severity, $file, $line);
        });

        set_exception_handler([self::class, 'handle']);

        register_shutdown_function(static function (): void {
            $err = error_get_last();
            if ($err && in_array($err['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
                self::handle(new \ErrorException($err['message'], 0, $err['type'], $err['file'], $err['line']));
            }
        });
    }

    public static function handle(Throwable $e): void
    {
        Logger::error(get_class($e) . ': ' . $e->getMessage(), ['file' => $e->getFile() . ':' . $e->getLine()]);

        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        if (!headers_sent()) {
            http_response_code(500);
        }
        if (PHP_SAPI === 'cli') {
            fwrite(STDERR, $e . PHP_EOL);
            return;
        }
        $isJson = str_contains((string) ($_SERVER['HTTP_ACCEPT'] ?? ''), 'application/json')
            || strtolower((string) ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '')) === 'xmlhttprequest';
        if ($isJson) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['success' => false, 'message' => 'Beklenmeyen bir hata oluştu. Lütfen daha sonra tekrar deneyin.'], JSON_UNESCAPED_UNICODE);
            return;
        }
        if (self::$debug) {
            echo '<pre style="padding:20px;background:#111;color:#f88;white-space:pre-wrap">' . e((string) $e) . '</pre>';
            return;
        }
        $view = APP_PATH . '/views/errors/500.php';
        if (is_file($view)) {
            require $view;
        } else {
            echo 'Sunucu hatası.';
        }
    }
}
