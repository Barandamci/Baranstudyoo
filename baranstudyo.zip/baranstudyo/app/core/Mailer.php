<?php
declare(strict_types=1);

namespace App\Core;

/** Bağımlılıksız e-posta gönderimi: PHP mail() veya SMTP (SSL/TLS + AUTH LOGIN) */
final class Mailer
{
    public static function send(string $to, string $subject, string $html, ?string $replyTo = null, ?string $replyName = null): bool
    {
        $to = self::clean($to);
        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
            return false;
        }
        $fromEmail = self::clean((string) config('mail.from_email'));
        $fromName = self::clean((string) config('mail.from_name', 'Baran Stüdyo'));
        $encodedSubject = '=?UTF-8?B?' . base64_encode(self::clean($subject)) . '?=';

        $headers = [
            'MIME-Version: 1.0',
            'Content-Type: text/html; charset=UTF-8',
            'Content-Transfer-Encoding: base64',
            'From: =?UTF-8?B?' . base64_encode($fromName) . "?= <$fromEmail>",
            'Date: ' . date('r'),
            'Message-ID: <' . bin2hex(random_bytes(12)) . '@' . (parse_url((string) config('app.url'), PHP_URL_HOST) ?: 'localhost') . '>',
            'X-Mailer: BaranStudyo',
        ];
        if ($replyTo && filter_var($replyTo = self::clean($replyTo), FILTER_VALIDATE_EMAIL)) {
            $headers[] = 'Reply-To: ' . ($replyName ? '=?UTF-8?B?' . base64_encode(self::clean($replyName)) . '?= ' : '') . "<$replyTo>";
        }
        $body = chunk_split(base64_encode($html));

        try {
            if (config('mail.driver') === 'smtp') {
                return self::smtp($fromEmail, $to, array_merge(["To: <$to>", "Subject: $encodedSubject"], $headers), $body);
            }
            return @mail($to, $encodedSubject, $body, implode("\r\n", $headers), '-f' . $fromEmail);
        } catch (\Throwable $e) {
            Logger::error('E-posta gönderilemedi: ' . $e->getMessage());
            return false;
        }
    }

    /** Header injection koruması */
    private static function clean(string $value): string
    {
        return trim(str_replace(["\r", "\n", '%0a', '%0d'], '', $value));
    }

    private static function smtp(string $from, string $to, array $headers, string $body): bool
    {
        $c = config('mail.smtp');
        $enc = strtolower((string) ($c['encryption'] ?? 'ssl'));
        $remote = ($enc === 'ssl' ? 'ssl://' : 'tcp://') . $c['host'] . ':' . (int) $c['port'];
        $ctx = stream_context_create(['ssl' => ['verify_peer' => true, 'verify_peer_name' => true]]);
        $fp = @stream_socket_client($remote, $errno, $errstr, (int) ($c['timeout'] ?? 15), STREAM_CLIENT_CONNECT, $ctx);
        if (!$fp) {
            throw new \RuntimeException("SMTP bağlantı hatası: $errstr ($errno)");
        }
        stream_set_timeout($fp, (int) ($c['timeout'] ?? 15));
        $host = parse_url((string) config('app.url'), PHP_URL_HOST) ?: 'localhost';

        $expect = static function (array $codes) use ($fp): string {
            $data = '';
            while (($line = fgets($fp, 515)) !== false) {
                $data .= $line;
                if (isset($line[3]) && $line[3] === ' ') {
                    break;
                }
            }
            if (!in_array((int) substr($data, 0, 3), $codes, true)) {
                throw new \RuntimeException('SMTP yanıtı beklenmedik: ' . trim($data));
            }
            return $data;
        };
        $cmd = static function (string $command, array $codes) use ($fp, $expect): string {
            fwrite($fp, $command . "\r\n");
            return $expect($codes);
        };

        $expect([220]);
        $cmd("EHLO $host", [250]);
        if ($enc === 'tls') {
            $cmd('STARTTLS', [220]);
            if (!stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT | STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT)) {
                throw new \RuntimeException('STARTTLS başarısız.');
            }
            $cmd("EHLO $host", [250]);
        }
        if (!empty($c['username'])) {
            $cmd('AUTH LOGIN', [334]);
            $cmd(base64_encode((string) $c['username']), [334]);
            $cmd(base64_encode((string) $c['password']), [235]);
        }
        $cmd("MAIL FROM:<$from>", [250]);
        $cmd("RCPT TO:<$to>", [250, 251]);
        $cmd('DATA', [354]);
        $message = implode("\r\n", $headers) . "\r\n\r\n" . $body;
        $message = preg_replace('/^\./m', '..', $message);
        fwrite($fp, $message . "\r\n.\r\n");
        $expect([250]);
        $cmd('QUIT', [221]);
        fclose($fp);
        return true;
    }
}
