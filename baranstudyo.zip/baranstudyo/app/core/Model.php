<?php
declare(strict_types=1);

namespace App\Core;

use PDO;
use PDOStatement;

/**
 * Temel model: tüm sorgular PDO prepared statements ile çalışır.
 * Kolon adları yalnızca $fillable listesinden alınır (kullanıcı girdisi asla kolon adı olamaz).
 */
abstract class Model
{
    protected static string $table = '';
    protected static array $fillable = [];
    protected static string $defaultOrder = 'id DESC';

    protected static function db(): PDO
    {
        return Database::connection();
    }

    protected static function query(string $sql, array $params = []): PDOStatement
    {
        $stmt = static::db()->prepare($sql);
        foreach ($params as $key => $value) {
            $type = match (true) {
                is_int($value)  => PDO::PARAM_INT,
                is_bool($value) => PDO::PARAM_BOOL,
                $value === null => PDO::PARAM_NULL,
                default         => PDO::PARAM_STR,
            };
            $stmt->bindValue(is_int($key) ? $key + 1 : ':' . ltrim((string) $key, ':'), $value, $type);
        }
        $stmt->execute();
        return $stmt;
    }

    public static function find(int $id): ?array
    {
        $row = static::query('SELECT * FROM `' . static::$table . '` WHERE id = :id LIMIT 1', ['id' => $id])->fetch();
        return $row ?: null;
    }

    public static function findBy(string $column, mixed $value): ?array
    {
        if (!in_array($column, static::$fillable, true)) {
            throw new \InvalidArgumentException('Geçersiz kolon.');
        }
        $row = static::query('SELECT * FROM `' . static::$table . '` WHERE `' . $column . '` = :v LIMIT 1', ['v' => $value])->fetch();
        return $row ?: null;
    }

    public static function all(?string $where = null, array $params = [], ?string $order = null, ?int $limit = null): array
    {
        $sql = 'SELECT * FROM `' . static::$table . '`';
        if ($where) {
            $sql .= ' WHERE ' . $where;
        }
        $sql .= ' ORDER BY ' . ($order ?? static::$defaultOrder);
        if ($limit !== null) {
            $sql .= ' LIMIT ' . max(1, $limit);
        }
        return static::query($sql, $params)->fetchAll();
    }

    public static function count(?string $where = null, array $params = []): int
    {
        $sql = 'SELECT COUNT(*) FROM `' . static::$table . '`' . ($where ? ' WHERE ' . $where : '');
        return (int) static::query($sql, $params)->fetchColumn();
    }

    /** @return array{items: array, total: int, page: int, pages: int, per_page: int} */
    public static function paginate(int $page, int $perPage = 10, ?string $where = null, array $params = [], ?string $order = null): array
    {
        $total = static::count($where, $params);
        $pages = max(1, (int) ceil($total / $perPage));
        $page = min(max(1, $page), $pages);
        $offset = ($page - 1) * $perPage;
        $sql = 'SELECT * FROM `' . static::$table . '`' . ($where ? ' WHERE ' . $where : '')
            . ' ORDER BY ' . ($order ?? static::$defaultOrder) . ' LIMIT ' . (int) $perPage . ' OFFSET ' . (int) $offset;
        return ['items' => static::query($sql, $params)->fetchAll(), 'total' => $total, 'page' => $page, 'pages' => $pages, 'per_page' => $perPage];
    }

    public static function create(array $data): int
    {
        $data = array_intersect_key($data, array_flip(static::$fillable));
        $cols = array_keys($data);
        $sql = 'INSERT INTO `' . static::$table . '` (`' . implode('`, `', $cols) . '`) VALUES (:' . implode(', :', $cols) . ')';
        static::query($sql, $data);
        return (int) static::db()->lastInsertId();
    }

    public static function update(int $id, array $data): bool
    {
        $data = array_intersect_key($data, array_flip(static::$fillable));
        if (!$data) {
            return false;
        }
        $sets = implode(', ', array_map(static fn ($c) => "`$c` = :$c", array_keys($data)));
        $data['__id'] = $id;
        return static::query('UPDATE `' . static::$table . '` SET ' . $sets . ' WHERE id = :__id', $data)->rowCount() >= 0;
    }

    public static function delete(int $id): bool
    {
        return static::query('DELETE FROM `' . static::$table . '` WHERE id = :id', ['id' => $id])->rowCount() > 0;
    }

    /** Benzersiz slug üretir */
    public static function uniqueSlug(string $source, ?int $ignoreId = null): string
    {
        $base = slugify($source);
        $slug = $base;
        $i = 2;
        while (true) {
            $params = ['slug' => $slug];
            $sql = 'SELECT COUNT(*) FROM `' . static::$table . '` WHERE slug = :slug';
            if ($ignoreId) {
                $sql .= ' AND id <> :id';
                $params['id'] = $ignoreId;
            }
            if ((int) static::query($sql, $params)->fetchColumn() === 0) {
                return $slug;
            }
            $slug = $base . '-' . $i++;
        }
    }
}
