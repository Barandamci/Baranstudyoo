<?php
declare(strict_types=1);

namespace App\Core;

/** Ziyaretçi sayfaları için tam sayfa HTML önbelleği */
final class PageCache
{
    private const EXCLUDED = ['/iletisim'];

    private static function key(): string
    {
        return 'page:' . ($_SERVER['REQUEST_URI'] ?? '/');
    }

    public static function eligible(string $path): bool
    {
        return Cache::enabled()
            && (int) config('cache.page_ttl', 0) > 0
            && Request::method() === 'GET'
            && !in_array($path, self::EXCLUDED, true)
            && empty($_SESSION['admin'])
            && empty($_SESSION['_flash_old']);
    }

    public static function serve(): bool
    {
        $hit = Cache::get(self::key());
        if (!is_array($hit) || !isset($hit['html'], $hit['nonce'], $hit['type'])) {
            return false;
        }
        header('Content-Type: ' . $hit['type']);
        header('X-Page-Cache: HIT');
        echo str_replace($hit['nonce'], Security::nonce(), $hit['html']);
        return true;
    }

    public static function store(string $html): void
    {
        // CSRF token içeren sayfalar oturuma özeldir; önbelleğe alınmaz
        if (http_response_code() !== 200 || str_contains($html, 'name="_csrf"')) {
            return;
        }
        $type = 'text/html; charset=utf-8';
        foreach (headers_list() as $h) {
            if (stripos($h, 'Content-Type:') === 0) {
                $type = trim(substr($h, 13));
            }
            if (stripos($h, 'Location:') === 0) {
                return;
            }
        }
        Cache::set(self::key(), ['html' => $html, 'nonce' => Security::nonce(), 'type' => $type], (int) config('cache.page_ttl', 600));
    }
}
