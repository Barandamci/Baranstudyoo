<?php
declare(strict_types=1);

namespace App\Core;

final class RateLimiter
{
    /** true dönerse limit aşılmıştır */
    public static function tooMany(string $key, int $max, int $windowSeconds): bool
    {
        $file = STORAGE_PATH . '/cache/rl_' . hash('sha256', $key) . '.json';
        $now = time();
        $fp = @fopen($file, 'c+');
        if (!$fp) {
            return false;
        }
        flock($fp, LOCK_EX);
        $hits = json_decode((string) stream_get_contents($fp), true) ?: [];
        $hits = array_values(array_filter($hits, static fn ($t) => is_int($t) && $t > $now - $windowSeconds));
        $limited = count($hits) >= $max;
        if (!$limited) {
            $hits[] = $now;
        }
        ftruncate($fp, 0);
        rewind($fp);
        fwrite($fp, json_encode($hits));
        flock($fp, LOCK_UN);
        fclose($fp);
        return $limited;
    }
}
