<?php
declare(strict_types=1);

namespace App\Core;

final class Request
{
    public static function input(string $key, string $default = ''): string
    {
        $value = $_POST[$key] ?? $_GET[$key] ?? $default;
        return is_string($value) ? trim($value) : $default;
    }

    public static function int(string $key, int $default = 0): int
    {
        $v = $_POST[$key] ?? $_GET[$key] ?? null;
        return is_numeric($v) ? (int) $v : $default;
    }

    public static function bool(string $key): int
    {
        return !empty($_POST[$key]) ? 1 : 0;
    }

    public static function page(): int
    {
        return max(1, (int) ($_GET['sayfa'] ?? $_GET['page'] ?? 1));
    }

    public static function file(string $key): ?array
    {
        $f = $_FILES[$key] ?? null;
        if (!is_array($f) || ($f['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
            return null;
        }
        return $f;
    }

    public static function isAjax(): bool
    {
        return strtolower((string) ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '')) === 'xmlhttprequest'
            || str_contains((string) ($_SERVER['HTTP_ACCEPT'] ?? ''), 'application/json');
    }

    public static function method(): string
    {
        return strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
    }

    /** Yalnızca aynı siteye ait referer döner (açık yönlendirme koruması) */
    public static function referer(): ?string
    {
        $ref = (string) ($_SERVER['HTTP_REFERER'] ?? '');
        $host = (string) ($_SERVER['HTTP_HOST'] ?? '');
        if ($ref === '' || $host === '' || parse_url($ref, PHP_URL_HOST) !== parse_url('http://' . $host, PHP_URL_HOST)) {
            return null;
        }
        $path = (string) parse_url($ref, PHP_URL_PATH);
        $query = parse_url($ref, PHP_URL_QUERY);
        return $path . ($query ? '?' . $query : '');
    }
}
