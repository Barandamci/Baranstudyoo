<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Genel CRUD denetleyicisi. Alt sınıflar alanları ve liste kolonlarını tanımlar.
 * Alan tipleri: text, textarea, html, number, checkbox, image, date, datetime, select, url, email, icon, password
 */
abstract class ResourceController extends AdminController
{
    /** @var class-string<Model> */
    protected string $model;
    protected string $route;
    protected string $singular;
    protected string $plural;
    protected string $uploadFolder = 'genel';
    protected string $searchColumn = 'title';
    protected ?string $slugSource = 'title';

    /** @return array<string, array{label:string, type:string, rules?:string, options?:array, help?:string, col?:int}> */
    abstract protected function fields(): array;

    /** @return array<string, array{0:string, 1?:string}> */
    abstract protected function columns(): array;

    protected function prepare(array $data, ?array $existing): array
    {
        return $data;
    }

    protected function beforeDelete(array $item): void
    {
    }

    public function index(): void
    {
        $q = mb_substr(Request::input('q'), 0, 100);
        $where = $q !== '' ? "`{$this->searchColumn}` LIKE :q" : null;
        $params = $q !== '' ? ['q' => '%' . addcslashes($q, '%_\\') . '%'] : [];
        $result = $this->model::paginate(Request::page(), 15, $where, $params);
        $this->view('resource/index', $this->shared() + ['title' => $this->plural, 'result' => $result, 'q' => $q]);
    }

    public function create(): void
    {
        $this->view('resource/form', $this->shared() + ['title' => 'Yeni ' . $this->singular, 'item' => null]);
    }

    public function store(): void
    {
        $back = admin_url($this->route . '/create');
        $data = $this->collect(null, $back);
        $id = $this->model::create($data);
        Cache::clear();
        $this->log('create', "{$this->singular} eklendi (#$id): " . $this->label($data));
        $this->success("{$this->singular} başarıyla eklendi.", admin_url($this->route));
    }

    public function edit(int $id): void
    {
        $item = $this->model::find($id) ?? $this->notFoundAdmin();
        $this->view('resource/form', $this->shared() + ['title' => $this->singular . ' Düzenle', 'item' => $item]);
    }

    public function update(int $id): void
    {
        $item = $this->model::find($id) ?? $this->notFoundAdmin();
        $data = $this->collect($item, admin_url("{$this->route}/$id/edit"));
        $this->model::update($id, $data);
        Cache::clear();
        $this->log('update', "{$this->singular} güncellendi (#$id): " . $this->label($data + $item));
        $this->success("{$this->singular} güncellendi.", admin_url("{$this->route}/$id/edit"));
    }

    public function destroy(int $id): void
    {
        $item = $this->model::find($id) ?? $this->notFoundAdmin();
        $this->beforeDelete($item);
        foreach ($this->fields() as $name => $f) {
            if ($f['type'] === 'image') {
                Uploader::delete($item[$name] ?? null);
            }
        }
        $this->model::delete($id);
        Cache::clear();
        $this->log('delete', "{$this->singular} silindi (#$id): " . $this->label($item));
        $this->success("{$this->singular} silindi.", admin_url($this->route));
    }

    protected function collect(?array $existing, string $back): array
    {
        $fields = $this->fields();
        $raw = [];
        $rules = [];
        $labels = [];
        foreach ($fields as $name => $f) {
            $labels[$name] = $f['label'];
            if (!in_array($f['type'], ['image', 'checkbox', 'password'], true)) {
                $raw[$name] = Request::input($name);
                if (!empty($f['rules'])) {
                    $rules[$name] = $f['rules'];
                }
            }
        }
        $v = Validator::make($raw, $rules, $labels);
        if ($v->fails()) {
            $this->fail($v->firstError(), $back, $_POST);
        }

        $data = [];
        foreach ($fields as $name => $f) {
            $value = $raw[$name] ?? null;
            $data[$name] = match ($f['type']) {
                'checkbox' => Request::bool($name),
                'number'   => Request::int($name),
                'html'     => Sanitizer::html((string) ($_POST[$name] ?? '')),
                'date', 'datetime', 'url' => $value !== '' ? $value : null,
                'select'   => array_key_exists((string) $value, $f['options'] ?? []) ? $value : array_key_first($f['options'] ?? ['' => '']),
                'icon'     => preg_match('/^bi-[a-z0-9\-]+$/', (string) $value) ? $value : 'bi-code-slash',
                'image', 'password' => null,
                default    => $value,
            };
            if ($f['type'] === 'datetime' && $data[$name]) {
                $data[$name] = date('Y-m-d H:i:s', strtotime(str_replace('T', ' ', (string) $data[$name])) ?: time());
            }
        }
        foreach ($fields as $name => $f) {
            if ($f['type'] === 'image') {
                $data[$name] = $this->handleImage($name, $this->uploadFolder, $existing[$name] ?? null, $back);
            }
            if ($f['type'] === 'password') {
                unset($data[$name]);
            }
        }
        if (array_key_exists('slug', $fields) && $this->slugSource) {
            $data['slug'] = $this->model::uniqueSlug($data['slug'] ?: (string) $data[$this->slugSource], $existing ? (int) $existing['id'] : null);
        }
        return $this->prepare($data, $existing);
    }

    protected function label(array $data): string
    {
        return mb_substr((string) ($data[$this->searchColumn] ?? ''), 0, 120);
    }

    protected function shared(): array
    {
        return [
            'fields' => $this->fields(),
            'columns' => $this->columns(),
            'route' => $this->route,
            'singular' => $this->singular,
            'plural' => $this->plural,
        ];
    }

    protected function notFoundAdmin(): never
    {
        http_response_code(404);
        echo View::render('admin/errors/404', ['title' => 'Kayıt Bulunamadı'], 'admin/layouts/main');
        exit;
    }
}
