<?php
declare(strict_types=1);

namespace App\Core;

final class Response
{
    public static function json(array $data, int $status = 200): never
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    public static function redirect(string $url, int $status = 302): never
    {
        // Yalnızca site içi göreli yönlendirmelere izin ver
        if (!str_starts_with($url, '/') || str_starts_with($url, '//')) {
            $url = url();
        }
        header('Location: ' . $url, true, $status);
        exit;
    }
}
