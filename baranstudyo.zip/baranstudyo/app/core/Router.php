<?php
declare(strict_types=1);

namespace App\Core;

final class Router
{
    private array $routes = [];

    public function __construct(private readonly string $prefix = '', private readonly string $namespace = 'App\\Controllers\\')
    {
    }

    public function get(string $path, string $handler): self
    {
        return $this->add('GET', $path, $handler);
    }

    public function post(string $path, string $handler): self
    {
        return $this->add('POST', $path, $handler);
    }

    private function add(string $method, string $path, string $handler): self
    {
        $path = '/' . trim($path, '/');
        $pattern = preg_replace(['#\{id\}#', '#\{slug\}#'], ['(\d+)', '([a-z0-9\-]+)'], $path);
        $this->routes[$method][] = ['pattern' => '#^' . $pattern . '$#', 'handler' => $handler];
        return $this;
    }

    public function resolvePath(string $uri): string
    {
        $path = rawurldecode((string) parse_url($uri, PHP_URL_PATH));
        $base = base_path_prefix() . $this->prefix;
        if ($base !== '' && str_starts_with($path, $base)) {
            $path = substr($path, strlen($base));
        }
        $path = preg_replace('#/index\.php$#', '', $path) ?? $path;
        return '/' . trim($path, '/');
    }

    public function dispatch(string $method, string $uri, callable $notFound): void
    {
        $method = strtoupper($method) === 'HEAD' ? 'GET' : strtoupper($method);
        $rawPath = (string) parse_url($uri, PHP_URL_PATH);
        $path = $this->resolvePath($uri);

        // SEO: sondaki eğik çizgiyi kaldırarak tek URL'ye yönlendir
        if ($method === 'GET' && strlen($rawPath) > 1 && str_ends_with($rawPath, '/') && $path !== '/') {
            $query = parse_url($uri, PHP_URL_QUERY);
            header('Location: ' . rtrim($rawPath, '/') . ($query ? '?' . $query : ''), true, 301);
            return;
        }

        if ($method === 'POST' && !Csrf::verify(Csrf::fromRequest())) {
            http_response_code(403);
            if (Request::isAjax()) {
                Response::json(['success' => false, 'message' => 'Güvenlik doğrulaması başarısız. Sayfayı yenileyip tekrar deneyin.'], 403);
            }
            Session::flash('error', 'Oturum doğrulaması başarısız oldu. Lütfen tekrar deneyin.');
            $back = Request::referer() ?? url();
            Response::redirect($back);
        }

        foreach ($this->routes[$method] ?? [] as $route) {
            if (preg_match($route['pattern'], $path, $m)) {
                array_shift($m);
                [$class, $action] = explode('@', $route['handler']);
                $class = $this->namespace . $class;
                $controller = new $class();
                $args = array_map(static fn ($v) => ctype_digit($v) ? (int) $v : $v, $m);
                $controller->$action(...$args);
                return;
            }
        }

        $allowed = array_filter(array_keys($this->routes), function ($verb) use ($path, $method) {
            if ($verb === $method) {
                return false;
            }
            foreach ($this->routes[$verb] as $r) {
                if (preg_match($r['pattern'], $path)) {
                    return true;
                }
            }
            return false;
        });
        if ($allowed) {
            http_response_code(405);
            header('Allow: ' . implode(', ', $allowed));
        }
        $notFound();
    }
}
