<?php
declare(strict_types=1);

namespace App\Core;

use DOMDocument;
use DOMElement;
use DOMNode;

/** Blog/hizmet içerikleri için beyaz liste tabanlı HTML temizleyici (XSS koruması) */
final class Sanitizer
{
    private const TAGS = [
        'p' => [], 'br' => [], 'h2' => [], 'h3' => [], 'h4' => [], 'strong' => [], 'b' => [], 'em' => [], 'i' => [], 'u' => [],
        'ul' => [], 'ol' => [], 'li' => [], 'blockquote' => [], 'code' => [], 'pre' => [], 'hr' => [],
        'a' => ['href', 'title', 'target'], 'img' => ['src', 'alt', 'title', 'width', 'height'],
        'table' => [], 'thead' => [], 'tbody' => [], 'tr' => [], 'th' => [], 'td' => [], 'span' => [], 'div' => [],
    ];

    public static function html(?string $html): string
    {
        $html = trim((string) $html);
        if ($html === '') {
            return '';
        }
        // Düz metin girilmişse paragraflara çevir
        if (!preg_match('/<\s*[a-z][^>]*>/i', $html)) {
            $paragraphs = preg_split('/\R{2,}/', $html) ?: [];
            return implode("\n", array_map(static fn ($p) => '<p>' . nl2br(e(trim($p)), false) . '</p>', array_filter($paragraphs, 'strlen')));
        }

        $doc = new DOMDocument('1.0', 'UTF-8');
        $prev = libxml_use_internal_errors(true);
        $doc->loadHTML('<?xml encoding="UTF-8"><div id="__root">' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD | LIBXML_NONET);
        libxml_clear_errors();
        libxml_use_internal_errors($prev);

        $root = $doc->getElementById('__root');
        if (!$root) {
            return e(strip_tags($html));
        }
        self::clean($root);
        $out = '';
        foreach ($root->childNodes as $child) {
            $out .= $doc->saveHTML($child);
        }
        return trim($out);
    }

    private static function clean(DOMNode $node): void
    {
        for ($i = $node->childNodes->length - 1; $i >= 0; $i--) {
            $child = $node->childNodes->item($i);
            if ($child === null) {
                continue;
            }
            if ($child->nodeType === XML_COMMENT_NODE || $child->nodeType === XML_PI_NODE) {
                $node->removeChild($child);
                continue;
            }
            if (!$child instanceof DOMElement) {
                continue;
            }
            $tag = strtolower($child->tagName);
            if (in_array($tag, ['script', 'style', 'iframe', 'object', 'embed', 'form', 'input', 'button', 'textarea', 'select', 'svg', 'math', 'link', 'meta', 'base'], true)) {
                $node->removeChild($child);
                continue;
            }
            self::clean($child);
            if (!array_key_exists($tag, self::TAGS)) {
                while ($child->firstChild) {
                    $node->insertBefore($child->firstChild, $child);
                }
                $node->removeChild($child);
                continue;
            }
            $allowed = self::TAGS[$tag];
            for ($a = $child->attributes->length - 1; $a >= 0; $a--) {
                $attr = $child->attributes->item($a);
                $name = strtolower($attr->nodeName);
                if (!in_array($name, $allowed, true)) {
                    $child->removeAttribute($attr->nodeName);
                    continue;
                }
                if (in_array($name, ['href', 'src'], true)) {
                    $val = trim($attr->nodeValue ?? '');
                    if (!preg_match('#^(https?://|/|\#|mailto:|tel:)#i', $val) || str_starts_with($val, '//')) {
                        $child->removeAttribute($attr->nodeName);
                    }
                }
            }
            if ($tag === 'a') {
                if ($child->getAttribute('target') !== '' && $child->getAttribute('target') !== '_blank') {
                    $child->removeAttribute('target');
                }
                if ($child->getAttribute('target') === '_blank') {
                    $child->setAttribute('rel', 'noopener noreferrer');
                }
            }
            if ($tag === 'img') {
                $child->setAttribute('loading', 'lazy');
            }
        }
    }
}
