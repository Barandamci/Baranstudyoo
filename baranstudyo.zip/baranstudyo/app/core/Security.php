<?php
declare(strict_types=1);

namespace App\Core;

final class Security
{
    private static ?string $nonce = null;

    public static function nonce(): string
    {
        return self::$nonce ??= base64_encode(random_bytes(16));
    }

    public static function sendHeaders(): void
    {
        if (headers_sent() || PHP_SAPI === 'cli') {
            return;
        }
        header_remove('X-Powered-By');
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: SAMEORIGIN');
        header('Referrer-Policy: strict-origin-when-cross-origin');
        header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
        header('Cross-Origin-Opener-Policy: same-origin');
        if (is_https()) {
            header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
        }
        if (config('security.csp', true)) {
            $n = self::nonce();
            header("Content-Security-Policy: default-src 'self'; "
                . "script-src 'self' 'nonce-$n' https://cdn.jsdelivr.net https://www.googletagmanager.com https://static.cloudflareinsights.com; "
                . "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://fonts.googleapis.com; "
                . "font-src 'self' data: https://cdn.jsdelivr.net https://fonts.gstatic.com; "
                . "img-src 'self' data: https:; "
                . "connect-src 'self' https://www.google.com https://www.google-analytics.com https://*.google-analytics.com https://*.analytics.google.com https://www.googletagmanager.com https://cloudflareinsights.com; "
                . "frame-src 'self' https://www.google.com https://maps.google.com; "
                . "frame-ancestors 'self'; base-uri 'self'; form-action 'self'; object-src 'none'");
        }
    }
}
