<?php
declare(strict_types=1);

namespace App\Core;

/** Dinamik meta başlık, açıklama, Open Graph ve Schema.org verisi */
final class Seo
{
    public string $title;
    public string $description;
    public string $canonical;
    public string $image = '';
    public string $type = 'website';
    public bool $noindex = false;
    public array $schema = [];
    public array $breadcrumbs = [];

    public function __construct(?string $title = null, ?string $description = null, ?string $path = null)
    {
        $site = (string) setting('site_title', config('app.name'));
        $this->title = $title ? $title . ' | ' . $site : $site . ' | ' . setting('site_tagline', 'Dijital Dünyada Güçlü Çözümler');
        $this->description = str_limit($description ?: (string) setting('site_description', ''), 160);
        $this->canonical = absolute_url($path ?? current_path());
        $og = (string) setting('og_image');
        $this->image = $og !== '' ? absolute_url('uploads/' . $og) : absolute_url('assets/img/og-default.png');
    }

    public static function make(?string $title = null, ?string $description = null, ?string $path = null): self
    {
        return new self($title, $description, $path);
    }

    public function image(?string $uploadPath): self
    {
        if ($uploadPath) {
            $this->image = absolute_url('uploads/' . $uploadPath);
        }
        return $this;
    }

    public function type(string $type): self
    {
        $this->type = $type;
        return $this;
    }

    public function schema(array $schema): self
    {
        $this->schema[] = $schema;
        return $this;
    }

    public function noindex(): self
    {
        $this->noindex = true;
        return $this;
    }

    /** @param array<array{0:string,1:string}> $items [ad, yol] */
    public function breadcrumbs(array $items): self
    {
        $list = [];
        foreach (array_merge([['Ana Sayfa', '/']], $items) as $i => [$name, $path]) {
            $list[] = ['@type' => 'ListItem', 'position' => $i + 1, 'name' => $name, 'item' => absolute_url($path)];
        }
        $this->breadcrumbs = $items;
        return $this->schema(['@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => $list]);
    }

    public function organizationSchema(): array
    {
        $sameAs = array_values(array_filter([
            setting('social_instagram'), setting('social_linkedin'), setting('social_github'), setting('social_x'), setting('social_youtube'),
        ]));
        return array_filter([
            '@context' => 'https://schema.org',
            '@type' => 'Organization',
            'name' => setting('site_title', config('app.name')),
            'url' => absolute_url(),
            'logo' => absolute_url('assets/img/logo.png'),
            'description' => setting('site_description'),
            'email' => setting('contact_email'),
            'telephone' => setting('contact_phone'),
            'address' => setting('contact_address') ? ['@type' => 'PostalAddress', 'streetAddress' => setting('contact_address'), 'addressCountry' => 'TR'] : null,
            'sameAs' => $sameAs ?: null,
        ]);
    }

    public function websiteSchema(): array
    {
        return [
            '@context' => 'https://schema.org',
            '@type' => 'WebSite',
            'name' => setting('site_title', config('app.name')),
            'url' => absolute_url(),
            'inLanguage' => 'tr-TR',
        ];
    }

    public function jsonLd(): string
    {
        $out = '';
        foreach (array_merge([$this->organizationSchema(), $this->websiteSchema()], $this->schema) as $s) {
            $out .= '<script type="application/ld+json">' . json_encode($s, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP) . "</script>\n";
        }
        return $out;
    }
}
