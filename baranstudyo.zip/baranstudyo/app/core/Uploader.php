<?php
declare(strict_types=1);

namespace App\Core;

use RuntimeException;

/**
 * Güvenli görsel yükleme:
 * - Gerçek MIME tipi (finfo) ve getimagesize ile doğrulama
 * - Rastgele dosya adı, uzantı MIME'dan belirlenir
 * - GD ile yeniden kodlama (zararlı gömülü kod/EXIF temizlenir) + boyut küçültme + WebP optimizasyonu
 */
final class Uploader
{
    private const ALLOWED = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp',
        'image/gif'  => 'gif',
    ];

    public static function image(array $file, string $folder, ?int $maxWidth = null): string
    {
        $error = (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($error !== UPLOAD_ERR_OK) {
            throw new RuntimeException(match ($error) {
                UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'Dosya boyutu çok büyük.',
                UPLOAD_ERR_PARTIAL => 'Dosya kısmen yüklendi, tekrar deneyin.',
                default => 'Dosya yüklenemedi.',
            });
        }
        $tmp = (string) $file['tmp_name'];
        if (!is_uploaded_file($tmp)) {
            throw new RuntimeException('Geçersiz dosya yükleme isteği.');
        }
        if ((int) $file['size'] > (int) config('upload.max_size', 5242880)) {
            throw new RuntimeException('Dosya boyutu en fazla ' . round(config('upload.max_size') / 1048576, 1) . ' MB olabilir.');
        }

        $mime = (new \finfo(FILEINFO_MIME_TYPE))->file($tmp) ?: '';
        if (!isset(self::ALLOWED[$mime])) {
            throw new RuntimeException('Yalnızca JPG, PNG, WEBP veya GIF görseller yüklenebilir.');
        }
        $info = @getimagesize($tmp);
        if ($info === false || $info[0] < 1 || $info[1] < 1 || $info[0] > 10000 || $info[1] > 10000) {
            throw new RuntimeException('Geçersiz veya bozuk görsel dosyası.');
        }

        $folder = preg_replace('/[^a-z0-9_\-]/', '', strtolower($folder)) ?: 'genel';
        $subdir = $folder . '/' . date('Y/m');
        $dir = UPLOAD_PATH . '/' . $subdir;
        if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) {
            throw new RuntimeException('Yükleme klasörü oluşturulamadı.');
        }
        $name = bin2hex(random_bytes(16));
        $maxWidth ??= (int) config('upload.max_width', 1600);

        if (extension_loaded('gd') && $mime !== 'image/gif') {
            $relative = self::reencode($tmp, $mime, $info, $dir, $subdir, $name, $maxWidth);
            if ($relative !== null) {
                return $relative;
            }
        }

        $relative = $subdir . '/' . $name . '.' . self::ALLOWED[$mime];
        if (!move_uploaded_file($tmp, UPLOAD_PATH . '/' . $relative)) {
            throw new RuntimeException('Dosya kaydedilemedi.');
        }
        @chmod(UPLOAD_PATH . '/' . $relative, 0644);
        return $relative;
    }

    private static function reencode(string $tmp, string $mime, array $info, string $dir, string $subdir, string $name, int $maxWidth): ?string
    {
        $src = match ($mime) {
            'image/jpeg' => @imagecreatefromjpeg($tmp),
            'image/png'  => @imagecreatefrompng($tmp),
            'image/webp' => function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($tmp) : false,
            default      => false,
        };
        if (!$src) {
            return null;
        }
        [$w, $h] = [$info[0], $info[1]];
        if ($w > $maxWidth) {
            $nw = $maxWidth;
            $nh = (int) round($h * ($maxWidth / $w));
            $dst = imagecreatetruecolor($nw, $nh);
            imagealphablending($dst, false);
            imagesavealpha($dst, true);
            imagefill($dst, 0, 0, imagecolorallocatealpha($dst, 0, 0, 0, 127));
            imagecopyresampled($dst, $src, 0, 0, 0, 0, $nw, $nh, $w, $h);
            imagedestroy($src);
            $src = $dst;
        } else {
            imagepalettetotruecolor($src);
            imagealphablending($src, false);
            imagesavealpha($src, true);
        }
        $quality = (int) config('upload.quality', 82);
        if (config('upload.webp', true) && function_exists('imagewebp')) {
            $relative = $subdir . '/' . $name . '.webp';
            $ok = imagewebp($src, UPLOAD_PATH . '/' . $relative, $quality);
        } elseif ($mime === 'image/png') {
            $relative = $subdir . '/' . $name . '.png';
            $ok = imagepng($src, UPLOAD_PATH . '/' . $relative, 7);
        } else {
            $relative = $subdir . '/' . $name . '.jpg';
            imageinterlace($src, true);
            $ok = imagejpeg($src, UPLOAD_PATH . '/' . $relative, $quality);
        }
        imagedestroy($src);
        if (!$ok) {
            return null;
        }
        @chmod(UPLOAD_PATH . '/' . $relative, 0644);
        return $relative;
    }

    public static function delete(?string $relative): void
    {
        if (!$relative) {
            return;
        }
        $base = realpath(UPLOAD_PATH);
        $path = realpath(UPLOAD_PATH . '/' . $relative);
        if ($base && $path && str_starts_with($path, $base . DIRECTORY_SEPARATOR) && is_file($path)) {
            @unlink($path);
        }
    }
}
