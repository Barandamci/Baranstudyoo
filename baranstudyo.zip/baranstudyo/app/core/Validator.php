<?php
declare(strict_types=1);

namespace App\Core;

final class Validator
{
    private array $errors = [];

    public function __construct(private readonly array $data)
    {
    }

    /** Kurallar: required, email, max:n, min:n, phone, url, date, in:a,b */
    public static function make(array $data, array $rules, array $labels = []): self
    {
        $v = new self($data);
        foreach ($rules as $field => $ruleString) {
            $value = trim((string) ($data[$field] ?? ''));
            $label = $labels[$field] ?? $field;
            foreach (explode('|', $ruleString) as $rule) {
                [$name, $param] = array_pad(explode(':', $rule, 2), 2, null);
                $error = match ($name) {
                    'required' => $value === '' ? "$label alanı zorunludur." : null,
                    'email'    => $value !== '' && !filter_var($value, FILTER_VALIDATE_EMAIL) ? "$label geçerli bir e-posta adresi olmalıdır." : null,
                    'max'      => mb_strlen($value) > (int) $param ? "$label en fazla $param karakter olabilir." : null,
                    'min'      => $value !== '' && mb_strlen($value) < (int) $param ? "$label en az $param karakter olmalıdır." : null,
                    'phone'    => $value !== '' && !preg_match('/^[0-9\s\+\-\(\)]{7,20}$/', $value) ? "$label geçerli bir telefon numarası olmalıdır." : null,
                    'url'      => $value !== '' && (!filter_var($value, FILTER_VALIDATE_URL) || !preg_match('#^https?://#i', $value)) ? "$label geçerli bir URL olmalıdır." : null,
                    'date'     => $value !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}/', $value) ? "$label geçerli bir tarih olmalıdır." : null,
                    'in'       => $value !== '' && !in_array($value, explode(',', (string) $param), true) ? "$label geçersiz." : null,
                    default    => null,
                };
                if ($error) {
                    $v->errors[$field] = $error;
                    break;
                }
            }
        }
        return $v;
    }

    public function fails(): bool
    {
        return $this->errors !== [];
    }

    public function errors(): array
    {
        return $this->errors;
    }

    public function firstError(): string
    {
        return (string) (array_values($this->errors)[0] ?? '');
    }
}
