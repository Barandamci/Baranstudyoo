<?php
declare(strict_types=1);

namespace App\Core;

final class View
{
    public static function render(string $__view, array $__data = [], ?string $__layout = 'layouts/main'): string
    {
        $__file = APP_PATH . '/views/' . $__view . '.php';
        if (!is_file($__file)) {
            throw new \RuntimeException("Görünüm bulunamadı: $__view");
        }
        extract($__data, EXTR_SKIP);
        ob_start();
        require $__file;
        $content = (string) ob_get_clean();
        if ($__layout === null) {
            return $content;
        }
        ob_start();
        require APP_PATH . '/views/' . $__layout . '.php';
        return (string) ob_get_clean();
    }

    public static function partial(string $name, array $data = []): string
    {
        return self::render($name, $data, null);
    }
}
