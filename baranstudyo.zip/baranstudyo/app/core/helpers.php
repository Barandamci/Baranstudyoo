<?php
declare(strict_types=1);

use App\Core\Csrf;
use App\Core\Session;
use App\Models\Setting;

function config(string $key, mixed $default = null): mixed
{
    $value = $GLOBALS['__config'] ?? [];
    foreach (explode('.', $key) as $segment) {
        if (!is_array($value) || !array_key_exists($segment, $value)) {
            return $default;
        }
        $value = $value[$segment];
    }
    return $value;
}

/** HTML çıktısı için güvenli kaçış (XSS koruması) */
function e(mixed $value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML5, 'UTF-8');
}

function base_path_prefix(): string
{
    static $prefix = null;
    if ($prefix === null) {
        $path = (string) parse_url((string) config('app.url', ''), PHP_URL_PATH);
        $prefix = rtrim($path, '/');
    }
    return $prefix;
}

/** Kök-göreli URL üretir: url('hizmetler') => /hizmetler */
function url(string $path = ''): string
{
    $path = ltrim($path, '/');
    return base_path_prefix() . '/' . $path;
}

/** Tam URL (canonical, Open Graph, sitemap için) */
function absolute_url(string $path = ''): string
{
    $base = rtrim((string) config('app.url', ''), '/');
    if ($base === '') {
        $scheme = is_https() ? 'https' : 'http';
        $base = $scheme . '://' . preg_replace('/[^a-z0-9\.\-:]/i', '', $_SERVER['HTTP_HOST'] ?? 'localhost');
        return $base . '/' . ltrim($path, '/');
    }
    $origin = preg_replace('#^(https?://[^/]+).*$#', '$1', $base);
    $u = url($path);
    return $origin . $u;
}

function admin_url(string $path = ''): string
{
    return url('admin/' . ltrim($path, '/'));
}

/** Önbellek kırıcı sürüm parametresi ile statik dosya yolu */
function asset(string $path): string
{
    $path = ltrim($path, '/');
    $file = BASE_PATH . '/assets/' . $path;
    $v = is_file($file) ? '?v=' . filemtime($file) : '';
    return url('assets/' . $path) . $v;
}

function upload_url(?string $path): string
{
    if (!$path) {
        return '';
    }
    return url('uploads/' . ltrim($path, '/'));
}

function setting(string $key, mixed $default = ''): mixed
{
    static $settings = null;
    if ($settings === null) {
        try {
            $settings = Setting::allCached();
        } catch (Throwable) {
            $settings = [];
        }
    }
    return ($settings[$key] ?? '') !== '' ? $settings[$key] : $default;
}

function is_https(): bool
{
    if (!empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off') {
        return true;
    }
    if ((int) ($_SERVER['SERVER_PORT'] ?? 0) === 443) {
        return true;
    }
    if (strtolower((string) ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https') {
        return true;
    }
    $cf = (string) ($_SERVER['HTTP_CF_VISITOR'] ?? '');
    return $cf !== '' && str_contains($cf, '"https"');
}

/** Gerçek ziyaretçi IP adresi (Cloudflare / proxy uyumlu) */
function client_ip(): string
{
    $candidates = [];
    if (config('security.trust_cloudflare') && !empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        $candidates[] = $_SERVER['HTTP_CF_CONNECTING_IP'];
    }
    if (config('security.trust_proxy') && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $candidates[] = trim(explode(',', (string) $_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
    }
    $candidates[] = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    foreach ($candidates as $ip) {
        if (filter_var($ip, FILTER_VALIDATE_IP)) {
            return $ip;
        }
    }
    return '0.0.0.0';
}

function user_agent(): string
{
    return mb_substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255);
}

function slugify(string $text): string
{
    $map = ['ç' => 'c', 'Ç' => 'c', 'ğ' => 'g', 'Ğ' => 'g', 'ı' => 'i', 'I' => 'i', 'İ' => 'i',
            'ö' => 'o', 'Ö' => 'o', 'ş' => 's', 'Ş' => 's', 'ü' => 'u', 'Ü' => 'u', 'â' => 'a', 'î' => 'i', 'û' => 'u'];
    $text = strtr($text, $map);
    $text = mb_strtolower($text, 'UTF-8');
    $text = preg_replace('/[^a-z0-9]+/', '-', $text) ?? '';
    $text = trim($text, '-');
    return $text !== '' ? mb_substr($text, 0, 180) : 'icerik-' . bin2hex(random_bytes(3));
}

function csrf_field(): string
{
    return Csrf::field();
}

function csrf_token(): string
{
    return Csrf::token();
}

function old(string $key, mixed $default = ''): string
{
    $old = Session::get('_old', []);
    return (string) ($old[$key] ?? $default);
}

function flash(string $key): ?string
{
    return Session::getFlash($key);
}

function str_limit(?string $text, int $limit = 150): string
{
    $text = trim(preg_replace('/\s+/u', ' ', strip_tags((string) $text)) ?? '');
    return mb_strlen($text) > $limit ? rtrim(mb_substr($text, 0, $limit)) . '…' : $text;
}

function tr_date(?string $date, bool $withTime = false): string
{
    if (!$date) {
        return '';
    }
    $ts = strtotime($date);
    if ($ts === false) {
        return '';
    }
    $months = ['', 'Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
    $out = date('j', $ts) . ' ' . $months[(int) date('n', $ts)] . ' ' . date('Y', $ts);
    return $withTime ? $out . ' ' . date('H:i', $ts) : $out;
}

function current_path(): string
{
    $path = (string) parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
    $prefix = base_path_prefix();
    if ($prefix !== '' && str_starts_with($path, $prefix)) {
        $path = substr($path, strlen($prefix));
    }
    return '/' . trim($path, '/');
}

function is_active(string $path, bool $exact = false): string
{
    $current = current_path();
    $path = '/' . trim($path, '/');
    if ($exact || $path === '/') {
        return $current === $path ? 'active' : '';
    }
    return str_starts_with($current, $path) ? 'active' : '';
}

function csp_nonce(): string
{
    return App\Core\Security::nonce();
}

function tech_list(?string $technologies): array
{
    return array_values(array_filter(array_map('trim', explode(',', (string) $technologies))));
}

function whatsapp_link(): string
{
    $number = preg_replace('/\D+/', '', (string) setting('whatsapp_number'));
    if ($number === '') {
        return '';
    }
    $text = (string) setting('whatsapp_message', 'Merhaba, Baran Stüdyo hakkında bilgi almak istiyorum.');
    return 'https://wa.me/' . $number . '?text=' . rawurlencode($text);
}
