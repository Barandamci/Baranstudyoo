<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Logger;
use App\Core\Model;

/** IP loglama: yönetim işlemleri, girişler ve form gönderimleri */
final class ActivityLog extends Model
{
    protected static string $table = 'activity_logs';
    protected static array $fillable = ['user_id', 'action', 'description', 'ip', 'user_agent'];

    public static function log(string $action, string $description = '', ?int $userId = null): void
    {
        try {
            $userId ??= isset($_SESSION['admin']['id']) ? (int) $_SESSION['admin']['id'] : null;
            static::create([
                'user_id' => $userId,
                'action' => mb_substr($action, 0, 50),
                'description' => mb_substr($description, 0, 255),
                'ip' => client_ip(),
                'user_agent' => user_agent(),
            ]);
        } catch (\Throwable $e) {
            Logger::error('Aktivite logu yazılamadı: ' . $e->getMessage());
        }
    }

    public static function withUsers(int $page, int $perPage = 30, string $action = ''): array
    {
        $where = $action !== '' ? 'WHERE l.action = :action' : '';
        $params = $action !== '' ? ['action' => $action] : [];
        $total = (int) static::query("SELECT COUNT(*) FROM activity_logs l $where", $params)->fetchColumn();
        $pages = max(1, (int) ceil($total / $perPage));
        $page = min(max(1, $page), $pages);
        $items = static::query("SELECT l.*, u.name AS user_name FROM activity_logs l LEFT JOIN users u ON u.id = l.user_id $where ORDER BY l.id DESC LIMIT $perPage OFFSET " . (($page - 1) * $perPage), $params)->fetchAll();
        return compact('items', 'total', 'page', 'pages') + ['per_page' => $perPage];
    }
}
