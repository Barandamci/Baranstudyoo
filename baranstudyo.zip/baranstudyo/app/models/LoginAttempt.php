<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

/** Brute force koruması: başarısız giriş denemelerini IP ve e-posta bazında sayar */
final class LoginAttempt extends Model
{
    protected static string $table = 'login_attempts';
    protected static array $fillable = ['ip', 'email', 'success', 'user_agent', 'cleared'];

    private static function window(): string
    {
        return date('Y-m-d H:i:s', time() - (int) config('security.login_decay_minutes', 15) * 60);
    }

    public static function failures(string $ip, ?string $email = null): int
    {
        $params = ['ip' => $ip, 'since' => self::window()];
        $where = 'ip = :ip AND success = 0 AND cleared = 0 AND created_at >= :since';
        if ($email !== null) {
            $where .= ' AND email = :email';
            $params['email'] = $email;
        }
        return static::count($where, $params);
    }

    public static function isLocked(string $ip, string $email): bool
    {
        return self::failures($ip, $email) >= (int) config('security.login_max_attempts', 5)
            || self::failures($ip) >= (int) config('security.login_max_ip_attempts', 20);
    }

    public static function remaining(string $ip, string $email): int
    {
        return max(0, (int) config('security.login_max_attempts', 5) - self::failures($ip, $email));
    }

    public static function record(string $ip, string $email, bool $success): void
    {
        static::create(['ip' => $ip, 'email' => mb_substr($email, 0, 190), 'success' => $success ? 1 : 0, 'user_agent' => user_agent(), 'cleared' => 0]);
    }

    public static function clear(string $ip, string $email): void
    {
        static::query('UPDATE login_attempts SET cleared = 1 WHERE ip = :ip AND email = :email AND success = 0', ['ip' => $ip, 'email' => $email]);
    }

    public static function prune(int $days = 90): void
    {
        static::query('DELETE FROM login_attempts WHERE created_at < :d', ['d' => date('Y-m-d H:i:s', time() - $days * 86400)]);
    }
}
