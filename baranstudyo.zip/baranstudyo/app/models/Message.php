<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

final class Message extends Model
{
    protected static string $table = 'messages';
    protected static array $fillable = ['name', 'email', 'phone', 'subject', 'message', 'ip', 'user_agent', 'is_read'];

    public static function unreadCount(): int
    {
        return static::count('is_read = 0');
    }
}
