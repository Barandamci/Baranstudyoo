<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

final class Post extends Model
{
    protected static string $table = 'posts';
    protected static array $fillable = ['user_id', 'title', 'slug', 'excerpt', 'content', 'image', 'meta_title', 'meta_description', 'status', 'published_at'];
    protected static string $defaultOrder = 'COALESCE(published_at, created_at) DESC, id DESC';

    public const PUBLISHED = "status = 'published' AND published_at <= NOW()";

    public static function latest(int $limit = 3): array
    {
        return static::all(self::PUBLISHED, [], 'published_at DESC', $limit);
    }

    public static function findPublishedBySlug(string $slug): ?array
    {
        $row = static::query('SELECT p.*, u.name AS author_name FROM posts p LEFT JOIN users u ON u.id = p.user_id WHERE p.slug = :slug AND ' . str_replace(['status', 'published_at'], ['p.status', 'p.published_at'], self::PUBLISHED) . ' LIMIT 1', ['slug' => $slug])->fetch();
        return $row ?: null;
    }

    public static function incrementViews(int $id): void
    {
        static::query('UPDATE posts SET views = views + 1 WHERE id = :id', ['id' => $id]);
    }
}
