<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

final class Project extends Model
{
    protected static string $table = 'projects';
    protected static array $fillable = ['title', 'slug', 'client', 'category', 'summary', 'content', 'image', 'technologies', 'project_date', 'project_url', 'is_featured', 'is_active', 'sort_order'];
    protected static string $defaultOrder = 'sort_order ASC, project_date DESC, id DESC';

    public static function featured(int $limit = 6): array
    {
        return static::all('is_active = 1', [], 'is_featured DESC, sort_order ASC, project_date DESC', $limit);
    }

    public static function findActiveBySlug(string $slug): ?array
    {
        $row = static::query('SELECT * FROM projects WHERE slug = :slug AND is_active = 1 LIMIT 1', ['slug' => $slug])->fetch();
        return $row ?: null;
    }

    public static function related(int $id, int $limit = 3): array
    {
        return static::all('is_active = 1 AND id <> :id', ['id' => $id], 'project_date DESC', $limit);
    }
}
