<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Cache;
use App\Core\Model;

final class Service extends Model
{
    protected static string $table = 'services';
    protected static array $fillable = ['title', 'slug', 'icon', 'short_description', 'content', 'image', 'sort_order', 'is_active', 'meta_title', 'meta_description'];
    protected static string $defaultOrder = 'sort_order ASC, id ASC';

    public static function active(): array
    {
        return Cache::remember('services:active', (int) config('cache.data_ttl', 3600),
            static fn () => static::all('is_active = 1'));
    }

    public static function findActiveBySlug(string $slug): ?array
    {
        $row = static::query('SELECT * FROM services WHERE slug = :slug AND is_active = 1 LIMIT 1', ['slug' => $slug])->fetch();
        return $row ?: null;
    }
}
