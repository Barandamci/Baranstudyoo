<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Cache;
use App\Core\Database;

final class Setting
{
    public static function allCached(): array
    {
        return Cache::remember('settings:all', (int) config('cache.data_ttl', 3600), static function (): array {
            $rows = Database::connection()->query('SELECT `key`, `value` FROM settings')->fetchAll();
            return array_column($rows, 'value', 'key');
        });
    }

    public static function setMany(array $values): void
    {
        $stmt = Database::connection()->prepare('INSERT INTO settings (`key`, `value`) VALUES (:k, :v) ON DUPLICATE KEY UPDATE `value` = VALUES(`value`)');
        foreach ($values as $k => $v) {
            if (!preg_match('/^[a-z0-9_]{1,100}$/', (string) $k)) {
                continue;
            }
            $stmt->execute(['k' => $k, 'v' => (string) $v]);
        }
        Cache::clear();
    }
}
