<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

final class Site extends Model
{
    protected static string $table = 'sites';
    protected static array $fillable = ['name', 'domain', 'logo', 'description', 'url', 'sort_order', 'is_active'];

    public static function active(): array
    {
        return static::all('is_active = 1', [], 'sort_order ASC, id DESC');
    }
}
