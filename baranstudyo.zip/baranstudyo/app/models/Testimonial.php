<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

final class Testimonial extends Model
{
    protected static string $table = 'testimonials';
    protected static array $fillable = ['client_name', 'company', 'position', 'comment', 'rating', 'logo', 'sort_order', 'is_active'];
    protected static string $defaultOrder = 'sort_order ASC, id DESC';

    public static function active(int $limit = 6): array
    {
        return static::all('is_active = 1', [], null, $limit);
    }
}
