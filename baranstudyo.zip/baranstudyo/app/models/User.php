<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

final class User extends Model
{
    protected static string $table = 'users';
    protected static array $fillable = ['name', 'email', 'password', 'role', 'is_active', 'last_login_at', 'last_login_ip'];

    public static function findByEmail(string $email): ?array
    {
        return static::findBy('email', mb_strtolower(trim($email)));
    }

    public static function touchLogin(int $id, string $ip): void
    {
        static::update($id, ['last_login_at' => date('Y-m-d H:i:s'), 'last_login_ip' => $ip]);
    }

    public static function emailTaken(string $email, ?int $ignoreId = null): bool
    {
        $params = ['email' => mb_strtolower($email)];
        $where = 'email = :email';
        if ($ignoreId) {
            $where .= ' AND id <> :id';
            $params['id'] = $ignoreId;
        }
        return static::count($where, $params) > 0;
    }

    public static function ownerExists(): bool
    {
        return static::count("role = 'owner'") > 0;
    }

    /** Owner e-postası ile ilk kayıt olan kullanıcı Owner olur; diğer herkes normal kullanıcıdır. */
    public static function roleForNewAccount(string $email): string
    {
        $owner = mb_strtolower((string) config('owner_email', ''));
        return ($owner !== '' && mb_strtolower($email) === $owner && !self::ownerExists()) ? 'owner' : 'user';
    }
}
