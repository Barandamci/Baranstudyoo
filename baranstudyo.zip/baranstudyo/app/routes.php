<?php
declare(strict_types=1);

/** @var App\Core\Router $router */
$router->get('/', 'HomeController@index');
$router->get('/hakkimizda', 'PageController@about');
$router->get('/hizmetler', 'ServiceController@index');
$router->get('/hizmetler/{slug}', 'ServiceController@show');
$router->get('/projeler', 'ProjectController@index');
$router->get('/projeler/{slug}', 'ProjectController@show');
$router->get('/blog', 'BlogController@index');
$router->get('/blog/{slug}', 'BlogController@show');
$router->get('/iletisim', 'ContactController@index');
$router->post('/iletisim', 'ContactController@send');
$router->get('/siteler', 'SiteController@index');
$router->get('/domain-sorgula', 'DomainController@index');
$router->get('/domain-sorgula/api', 'DomainController@api');
$router->get('/giris', 'AccountController@loginForm');
$router->post('/giris', 'AccountController@login');
$router->get('/kayit', 'AccountController@registerForm');
$router->post('/kayit', 'AccountController@register');
$router->post('/cikis', 'AccountController@logout');
$router->get('/hesabim', 'AccountController@index');
$router->get('/sitemap.xml', 'SeoController@sitemap');
$router->get('/robots.txt', 'SeoController@robots');
