<?php
declare(strict_types=1);

/** @var App\Core\Router $router  (önek: /admin) */
$router->get('/', 'DashboardController@index');
$router->get('/login', 'AuthController@loginForm');
$router->post('/login', 'AuthController@login');
$router->post('/logout', 'AuthController@logout');

foreach (['services' => 'ServiceController', 'projects' => 'ProjectController', 'posts' => 'PostController', 'testimonials' => 'TestimonialController', 'sites' => 'SiteController', 'users' => 'UserController'] as $path => $ctrl) {
    $router->get("/$path", "$ctrl@index");
    $router->get("/$path/create", "$ctrl@create");
    $router->post("/$path", "$ctrl@store");
    $router->get("/$path/{id}/edit", "$ctrl@edit");
    $router->post("/$path/{id}", "$ctrl@update");
    $router->post("/$path/{id}/delete", "$ctrl@destroy");
}

$router->get('/messages', 'MessageController@index');
$router->get('/messages/{id}', 'MessageController@show');
$router->post('/messages/{id}/toggle', 'MessageController@toggle');
$router->post('/messages/{id}/delete', 'MessageController@destroy');

$router->get('/settings', 'SettingController@index');
$router->post('/settings', 'SettingController@update');
$router->post('/settings/cache', 'SettingController@clearCache');

$router->get('/logs', 'LogController@index');

$router->get('/profile', 'ProfileController@index');
$router->post('/profile', 'ProfileController@update');
