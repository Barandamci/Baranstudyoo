<?php /** @var array $user */
$roles = ['owner' => 'Owner', 'admin' => 'Yönetici', 'editor' => 'Editör', 'user' => 'Üye']; ?>
<section class="section auth-section">
    <div class="container">
        <div class="auth-card reveal" style="max-width:560px">
            <?= App\Core\View::partial('partials/alerts') ?>
            <div class="d-flex align-items-center gap-3 mb-4">
                <span class="account-avatar"><?= e(mb_strtoupper(mb_substr($user['name'], 0, 1))) ?></span>
                <div><h1 class="h4 mb-0"><?= e($user['name']) ?></h1><span class="text-muted-soft small"><?= e($user['email']) ?></span></div>
                <span class="badge role-badge ms-auto"><?= e($roles[$user['role']] ?? $user['role']) ?></span>
            </div>
            <dl class="row small mb-4">
                <dt class="col-5 text-muted-soft">Üyelik tarihi</dt><dd class="col-7"><?= e(tr_date($user['created_at'])) ?></dd>
                <dt class="col-5 text-muted-soft">Son giriş</dt><dd class="col-7"><?= e(tr_date($user['last_login_at'], true)) ?></dd>
            </dl>
            <div class="d-flex flex-wrap gap-2">
                <?php if (App\Core\Auth::can('dashboard')): ?><a href="<?= admin_url() ?>" class="btn btn-gradient"><i class="bi bi-speedometer2"></i> Yönetim Paneli</a><?php endif; ?>
                <a href="<?= url('domain-sorgula') ?>" class="btn btn-glass"><i class="bi bi-globe2"></i> Domain Sorgula</a>
                <form method="post" action="<?= url('cikis') ?>" class="ms-auto"><?= csrf_field() ?><button class="btn btn-outline-light"><i class="bi bi-box-arrow-right"></i> Çıkış</button></form>
            </div>
        </div>
    </div>
</section>
