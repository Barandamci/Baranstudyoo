<section class="section auth-section">
    <div class="container">
        <div class="auth-card reveal">
            <img src="<?= asset('img/logo-mark.webp') ?>" alt="Baran Stüdyo" width="96" height="71" class="auth-logo">
            <h1 class="h3 text-center mb-1">Giriş Yap</h1>
            <p class="text-center text-muted-soft mb-4">Baran Stüdyo hesabınıza giriş yapın</p>
            <?= App\Core\View::partial('partials/alerts') ?>
            <form method="post" action="<?= url('giris') ?>">
                <?= csrf_field() ?>
                <div class="mb-3"><label class="form-label" for="email">E-posta</label><input class="form-control" type="email" id="email" name="email" value="<?= e(old('email')) ?>" required autocomplete="username"></div>
                <div class="mb-4"><label class="form-label" for="password">Şifre</label><input class="form-control" type="password" id="password" name="password" required autocomplete="current-password"></div>
                <button class="btn btn-gradient w-100 btn-lg" type="submit">Giriş Yap <i class="bi bi-box-arrow-in-right"></i></button>
            </form>
            <p class="text-center small mt-4 mb-0 text-muted-soft">Hesabınız yok mu? <a href="<?= url('kayit') ?>">Kayıt olun</a></p>
        </div>
    </div>
</section>
