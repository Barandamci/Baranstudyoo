<section class="section auth-section">
    <div class="container">
        <div class="auth-card reveal">
            <img src="<?= asset('img/logo-mark.webp') ?>" alt="Baran Stüdyo" width="96" height="71" class="auth-logo">
            <h1 class="h3 text-center mb-1">Kayıt Ol</h1>
            <p class="text-center text-muted-soft mb-4">Ücretsiz Baran Stüdyo hesabı oluşturun</p>
            <?= App\Core\View::partial('partials/alerts') ?>
            <?php if (!$open): ?>
                <div class="alert alert-warning">Yeni üye kaydı şu anda kapalıdır.</div>
            <?php endif; ?>
            <form method="post" action="<?= url('kayit') ?>" novalidate>
                <?= csrf_field() ?>
                <div class="hp" aria-hidden="true"><input type="text" name="website" tabindex="-1" autocomplete="off"></div>
                <div class="mb-3"><label class="form-label" for="name">Ad Soyad</label><input class="form-control" id="name" name="name" value="<?= e(old('name')) ?>" required maxlength="100" autocomplete="name"></div>
                <div class="mb-3"><label class="form-label" for="email">E-posta</label><input class="form-control" type="email" id="email" name="email" value="<?= e(old('email')) ?>" required maxlength="190" autocomplete="email"></div>
                <div class="row g-3 mb-2">
                    <div class="col-sm-6"><label class="form-label" for="password">Şifre</label><input class="form-control" type="password" id="password" name="password" required minlength="8" autocomplete="new-password"></div>
                    <div class="col-sm-6"><label class="form-label" for="password_confirmation">Şifre (Tekrar)</label><input class="form-control" type="password" id="password_confirmation" name="password_confirmation" required autocomplete="new-password"></div>
                </div>
                <div class="form-text mb-4">En az 8 karakter, harf ve rakam içermelidir.</div>
                <button class="btn btn-gradient w-100 btn-lg" type="submit">Hesap Oluştur <i class="bi bi-person-plus"></i></button>
            </form>
            <p class="text-center small mt-4 mb-0 text-muted-soft">Zaten hesabınız var mı? <a href="<?= url('giris') ?>">Giriş yapın</a></p>
        </div>
    </div>
</section>
