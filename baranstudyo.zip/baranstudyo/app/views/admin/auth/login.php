<!DOCTYPE html>
<html lang="tr" data-bs-theme="dark">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <title>Yönetim Girişi | Baran Stüdyo</title>
    <link rel="icon" href="<?= asset('img/favicon.png') ?>" type="image/png"><link rel="apple-touch-icon" href="<?= asset('img/apple-touch-icon.png') ?>">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?= asset('css/admin.css') ?>" rel="stylesheet">
</head>
<body class="login-page">
<div class="login-orb" aria-hidden="true"></div>
<main class="login-card">
    <div class="text-center mb-4">
        <img src="<?= asset('img/logo.webp') ?>" width="150" height="150" alt="Baran Stüdyo">
        <h1 class="h4 mt-3 mb-1">Yönetim Paneli</h1>
        <p class="text-secondary small mb-0">Baran Stüdyo hesabınızla giriş yapın</p>
    </div>
    <?php if ($m = flash('error')): ?><div class="alert alert-danger py-2 small"><i class="bi bi-exclamation-triangle"></i> <?= e($m) ?></div><?php endif; ?>
    <?php if ($m = flash('success')): ?><div class="alert alert-success py-2 small"><?= e($m) ?></div><?php endif; ?>
    <form method="post" action="<?= admin_url('login') ?>" autocomplete="on">
        <?= csrf_field() ?>
        <div class="mb-3">
            <label class="form-label" for="email">E-posta</label>
            <div class="input-group"><span class="input-group-text"><i class="bi bi-envelope"></i></span>
                <input type="email" class="form-control" id="email" name="email" value="<?= e(old('email')) ?>" required autofocus autocomplete="username"></div>
        </div>
        <div class="mb-4">
            <label class="form-label" for="password">Şifre</label>
            <div class="input-group"><span class="input-group-text"><i class="bi bi-lock"></i></span>
                <input type="password" class="form-control" id="password" name="password" required autocomplete="current-password"></div>
        </div>
        <button class="btn btn-gradient w-100 py-2" type="submit"><i class="bi bi-box-arrow-in-right"></i> Giriş Yap</button>
    </form>
    <p class="text-center small text-secondary mt-4 mb-0"><i class="bi bi-shield-check"></i> Bağlantınız korunmaktadır. IP: <?= e(client_ip()) ?></p>
</main>
</body>
</html>
