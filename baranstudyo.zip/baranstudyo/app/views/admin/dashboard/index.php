<?php /** @var array $stats @var array $messages @var array $logs */
$cards = [
    ['Hizmetler', $stats['services'], 'bi-grid', 'services', 'c1'],
    ['Projeler', $stats['projects'], 'bi-kanban', 'projects', 'c2'],
    ['Blog Yazıları', $stats['posts'], 'bi-journal-text', 'posts', 'c3'],
    ['Okunmamış Mesaj', $stats['unread'], 'bi-envelope', 'messages?filtre=okunmamis', 'c4'],
];
?>
<div class="row g-3 mb-4">
    <?php foreach ($cards as [$label, $value, $icon, $link, $c]): ?>
    <div class="col-6 col-xl-3">
        <a href="<?= admin_url($link) ?>" class="stat-card <?= $c ?>">
            <i class="bi <?= $icon ?>"></i>
            <div><div class="stat-num"><?= (int) $value ?></div><div class="stat-lbl"><?= e($label) ?></div></div>
        </a>
    </div>
    <?php endforeach; ?>
</div>
<div class="row g-4">
    <div class="col-xl-7">
        <div class="panel h-100">
            <div class="panel-head"><h2>Son Mesajlar</h2><a href="<?= admin_url('messages') ?>" class="small">Tümü <i class="bi bi-arrow-right"></i></a></div>
            <div class="list-group list-group-flush">
                <?php foreach ($messages as $m): ?>
                <a href="<?= admin_url('messages/' . (int) $m['id']) ?>" class="list-group-item list-group-item-action <?= (int) $m['is_read'] ? '' : 'unread' ?>">
                    <div class="d-flex justify-content-between"><strong><?= e($m['name']) ?></strong><small class="text-secondary"><?= e(tr_date($m['created_at'], true)) ?></small></div>
                    <div class="small text-secondary text-truncate"><?= e($m['subject']) ?> — <?= e(str_limit($m['message'], 80)) ?></div>
                </a>
                <?php endforeach; ?>
                <?php if (!$messages): ?><div class="p-4 text-secondary text-center">Henüz mesaj yok.</div><?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-xl-5">
        <div class="panel h-100">
            <div class="panel-head"><h2>Son Aktiviteler</h2><?php if (App\Core\Auth::can('logs')): ?><a href="<?= admin_url('logs') ?>" class="small">Loglar <i class="bi bi-arrow-right"></i></a><?php endif; ?></div>
            <ul class="activity">
                <?php foreach ($logs as $l): ?>
                <li><span class="dot act-<?= e($l['action']) ?>"></span><div><div class="small"><?= e($l['description']) ?></div><div class="text-secondary" style="font-size:.75rem"><?= e($l['user_name'] ?? 'Ziyaretçi') ?> · <?= e($l['ip']) ?> · <?= e(tr_date($l['created_at'], true)) ?></div></div></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</div>
<div class="panel mt-4">
    <div class="panel-head"><h2>Hızlı İşlemler</h2></div>
    <div class="d-flex flex-wrap gap-2 p-3">
        <a href="<?= admin_url('projects/create') ?>" class="btn btn-gradient"><i class="bi bi-plus-lg"></i> Proje Ekle</a>
        <a href="<?= admin_url('posts/create') ?>" class="btn btn-outline-light"><i class="bi bi-pencil"></i> Blog Yazısı</a>
        <a href="<?= admin_url('services/create') ?>" class="btn btn-outline-light"><i class="bi bi-grid"></i> Hizmet Ekle</a>
        <?php if (App\Core\Auth::can('settings')): ?><a href="<?= admin_url('settings') ?>" class="btn btn-outline-light"><i class="bi bi-gear"></i> Site Ayarları</a><?php endif; ?>
    </div>
</div>
