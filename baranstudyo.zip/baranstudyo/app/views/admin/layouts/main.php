<?php
use App\Core\Auth;
$u = Auth::user();
$unread = 0;
try { $unread = App\Models\Message::unreadCount(); } catch (Throwable) {}
$menu = [
    ['', 'bi-speedometer2', 'Dashboard', 'dashboard'],
    ['services', 'bi-grid', 'Hizmetler', 'services'],
    ['projects', 'bi-kanban', 'Projeler', 'projects'],
    ['posts', 'bi-journal-text', 'Blog', 'posts'],
    ['sites', 'bi-globe2', 'Siteler', 'sites'],
    ['messages', 'bi-envelope', 'Mesajlar', 'messages'],
    ['settings#domain', 'bi-search', 'Domain Ayarları', 'settings'],
    ['settings', 'bi-gear', 'Site & Sistem Ayarları', 'settings'],
    ['users', 'bi-people', 'Kullanıcılar', 'users'],
    ['logs', 'bi-shield-lock', 'Güvenlik Logları', 'logs'],
];
?>
<!DOCTYPE html>
<html lang="tr" data-bs-theme="dark">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <meta name="csrf-token" content="<?= e(csrf_token()) ?>">
    <title><?= e($title ?? 'Yönetim') ?> | Baran Stüdyo Yönetim</title>
    <link rel="icon" href="<?= asset('img/favicon.png') ?>" type="image/png"><link rel="apple-touch-icon" href="<?= asset('img/apple-touch-icon.png') ?>">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?= asset('css/admin.css') ?>" rel="stylesheet">
</head>
<body class="admin">
<aside class="sidebar" id="sidebar">
    <a href="<?= admin_url() ?>" class="sidebar-brand"><img src="<?= asset('img/logo-mark.webp') ?>" width="43" height="32" alt=""> <span>Baran<b>Stüdyo</b></span></a>
    <nav class="sidebar-nav">
        <?php foreach ($menu as [$path, $icon, $label, $perm]): if (!Auth::can($perm)) continue;
            $href = admin_url($path);
            $active = $path === '' ? current_path() === '/admin' : ($path !== 'settings#domain' && str_starts_with(current_path(), '/admin/' . $path)); ?>
        <a href="<?= $href ?>" class="<?= $active ? 'active' : '' ?>"><i class="bi <?= $icon ?>"></i> <?= e($label) ?>
            <?php if ($perm === 'messages' && $unread > 0): ?><span class="badge rounded-pill bg-danger ms-auto"><?= $unread ?></span><?php endif; ?>
        </a>
        <?php endforeach; ?>
    </nav>
    <div class="sidebar-foot">
        <a href="<?= url() ?>" target="_blank" rel="noopener"><i class="bi bi-box-arrow-up-right"></i> Siteyi Görüntüle</a>
    </div>
</aside>
<div class="sidebar-backdrop" data-toggle-sidebar></div>
<div class="main">
    <header class="topbar">
        <button class="btn btn-icon d-lg-none" type="button" data-toggle-sidebar aria-label="Menü"><i class="bi bi-list"></i></button>
        <h1 class="topbar-title"><?= e($title ?? '') ?></h1>
        <div class="dropdown ms-auto">
            <button class="btn btn-user dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                <span class="avatar"><?= e(mb_strtoupper(mb_substr((string) ($u['name'] ?? 'A'), 0, 1))) ?></span>
                <span class="d-none d-sm-inline"><?= e($u['name'] ?? '') ?></span>
            </button>
            <ul class="dropdown-menu dropdown-menu-end">
                <li><span class="dropdown-item-text small text-secondary"><?= e($u['email'] ?? '') ?> · <?= (['owner' => 'Owner', 'admin' => 'Yönetici', 'editor' => 'Editör'][$u['role'] ?? ''] ?? 'Üye') ?></span></li>
                <li><a class="dropdown-item" href="<?= admin_url('profile') ?>"><i class="bi bi-person"></i> Profilim</a></li>
                <li><hr class="dropdown-divider"></li>
                <li>
                    <form action="<?= admin_url('logout') ?>" method="post"><?= csrf_field() ?>
                        <button class="dropdown-item text-danger" type="submit"><i class="bi bi-box-arrow-right"></i> Çıkış Yap</button>
                    </form>
                </li>
            </ul>
        </div>
    </header>
    <div class="content">
        <?php if ($m = flash('success')): ?><div class="alert alert-success alert-dismissible fade show"><i class="bi bi-check-circle"></i> <?= e($m) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>
        <?php if ($m = flash('error')): ?><div class="alert alert-danger alert-dismissible fade show"><i class="bi bi-exclamation-triangle"></i> <?= e($m) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>
        <?= $content ?>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous" defer></script>
<script src="<?= asset('js/admin.js') ?>" defer></script>
</body>
</html>
