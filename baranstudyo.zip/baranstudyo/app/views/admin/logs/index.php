<?php /** @var array $result @var string $action @var array $attempts */
$actions = ['' => 'Tümü', 'login' => 'Giriş', 'login_failed' => 'Başarısız giriş', 'login_blocked' => 'Engellenen giriş', 'logout' => 'Çıkış', 'create' => 'Ekleme', 'update' => 'Güncelleme', 'delete' => 'Silme', 'settings' => 'Ayarlar', 'contact' => 'İletişim formu', 'password' => 'Şifre']; ?>
<div class="row g-4">
    <div class="col-xl-8">
        <div class="panel">
            <div class="panel-head">
                <h2>Aktivite & IP Logları</h2>
                <form method="get"><select name="action" class="form-select form-select-sm" data-autosubmit>
                    <?php foreach ($actions as $k => $l): ?><option value="<?= $k ?>" <?= $k === $action ? 'selected' : '' ?>><?= e($l) ?></option><?php endforeach; ?>
                </select></form>
            </div>
            <div class="table-responsive">
                <table class="table table-sm table-hover align-middle mb-0 small">
                    <thead><tr><th>Tarih</th><th>İşlem</th><th>Açıklama</th><th>Kullanıcı</th><th>IP</th></tr></thead>
                    <tbody>
                    <?php foreach ($result['items'] as $l): ?>
                    <tr title="<?= e($l['user_agent']) ?>">
                        <td class="text-nowrap"><?= e(tr_date($l['created_at'], true)) ?></td>
                        <td><span class="badge act-badge act-<?= e($l['action']) ?>"><?= e($actions[$l['action']] ?? $l['action']) ?></span></td>
                        <td><?= e($l['description']) ?></td>
                        <td><?= e($l['user_name'] ?? '-') ?></td>
                        <td class="font-monospace"><?= e($l['ip']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?= App\Core\View::partial('admin/partials/pagination', ['result' => $result]) ?>
        </div>
    </div>
    <div class="col-xl-4">
        <div class="panel">
            <div class="panel-head"><h2>Son Başarısız Girişler</h2></div>
            <ul class="list-group list-group-flush small">
                <?php foreach ($attempts as $a): ?>
                <li class="list-group-item"><div class="d-flex justify-content-between"><span class="font-monospace"><?= e($a['ip']) ?></span><span class="text-secondary"><?= e(tr_date($a['created_at'], true)) ?></span></div><div class="text-secondary text-truncate"><?= e($a['email']) ?></div></li>
                <?php endforeach; ?>
                <?php if (!$attempts): ?><li class="list-group-item text-secondary">Kayıt yok.</li><?php endif; ?>
            </ul>
            <p class="small text-secondary p-3 mb-0"><i class="bi bi-info-circle"></i> Aynı IP + e-posta ile <?= (int) config('security.login_max_attempts') ?> başarısız denemeden sonra giriş <?= (int) config('security.login_decay_minutes') ?> dakika kilitlenir.</p>
        </div>
    </div>
</div>
