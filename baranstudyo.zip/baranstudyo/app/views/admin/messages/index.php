<?php /** @var array $result @var string $filter @var string $q */ ?>
<div class="panel">
    <div class="panel-head flex-wrap gap-2">
        <div class="btn-group btn-group-sm">
            <a href="<?= admin_url('messages') ?>" class="btn btn-outline-light <?= $filter === '' ? 'active' : '' ?>">Tümü</a>
            <a href="<?= admin_url('messages') ?>?filtre=okunmamis" class="btn btn-outline-light <?= $filter === 'okunmamis' ? 'active' : '' ?>">Okunmamış</a>
        </div>
        <form class="d-flex gap-2" method="get"><input type="hidden" name="filtre" value="<?= e($filter) ?>">
            <input type="search" name="q" value="<?= e($q) ?>" class="form-control form-control-sm" placeholder="İsim, e-posta, konu..."><button class="btn btn-sm btn-outline-light"><i class="bi bi-search"></i></button></form>
    </div>
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead><tr><th></th><th>Gönderen</th><th>Konu</th><th>Telefon</th><th>IP</th><th>Tarih</th><th class="text-end">İşlemler</th></tr></thead>
            <tbody>
            <?php foreach ($result['items'] as $m): ?>
            <tr class="<?= (int) $m['is_read'] ? '' : 'unread' ?>">
                <td><i class="bi <?= (int) $m['is_read'] ? 'bi-envelope-open text-secondary' : 'bi-envelope-fill text-info' ?>"></i></td>
                <td><a href="<?= admin_url('messages/' . (int) $m['id']) ?>" class="text-reset"><strong><?= e($m['name']) ?></strong><br><small class="text-secondary"><?= e($m['email']) ?></small></a></td>
                <td><?= e(str_limit($m['subject'], 50)) ?></td>
                <td class="small"><?= e($m['phone'] ?: '-') ?></td>
                <td class="small font-monospace"><?= e($m['ip']) ?></td>
                <td class="small text-nowrap"><?= e(tr_date($m['created_at'], true)) ?></td>
                <td class="text-end text-nowrap">
                    <a href="<?= admin_url('messages/' . (int) $m['id']) ?>" class="btn btn-sm btn-outline-light" title="Görüntüle"><i class="bi bi-eye"></i></a>
                    <form action="<?= admin_url('messages/' . (int) $m['id'] . '/toggle') ?>" method="post" class="d-inline"><?= csrf_field() ?><button class="btn btn-sm btn-outline-light" title="Okundu/Okunmadı"><i class="bi bi-check2-all"></i></button></form>
                    <form action="<?= admin_url('messages/' . (int) $m['id'] . '/delete') ?>" method="post" class="d-inline" data-confirm="Mesaj silinsin mi?"><?= csrf_field() ?><button class="btn btn-sm btn-outline-danger" title="Sil"><i class="bi bi-trash"></i></button></form>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (!$result['items']): ?><tr><td colspan="7" class="text-center text-secondary py-5">Mesaj bulunamadı.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
    <?= App\Core\View::partial('admin/partials/pagination', ['result' => $result]) ?>
</div>
