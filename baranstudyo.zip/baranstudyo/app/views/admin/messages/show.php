<?php /** @var array $message */ $m = $message; ?>
<div class="row g-4">
    <div class="col-lg-8">
        <div class="panel p-4">
            <h2 class="h5 mb-1"><?= e($m['subject']) ?></h2>
            <p class="text-secondary small mb-4"><?= e(tr_date($m['created_at'], true)) ?></p>
            <div class="message-body"><?= nl2br(e($m['message'])) ?></div>
            <div class="d-flex flex-wrap gap-2 mt-4 pt-3 border-top border-secondary-subtle">
                <a href="mailto:<?= e($m['email']) ?>?subject=<?= rawurlencode('Re: ' . $m['subject']) ?>" class="btn btn-gradient"><i class="bi bi-reply"></i> E-posta ile Yanıtla</a>
                <?php if ($m['phone']): $wa = preg_replace('/\D/', '', $m['phone']); if (str_starts_with($wa, '0')) { $wa = '9' . $wa; } ?>
                <a href="https://wa.me/<?= e($wa) ?>" target="_blank" rel="noopener noreferrer" class="btn btn-success"><i class="bi bi-whatsapp"></i> WhatsApp</a>
                <?php endif; ?>
                <a href="<?= admin_url('messages') ?>" class="btn btn-outline-light">Geri</a>
                <form action="<?= admin_url('messages/' . (int) $m['id'] . '/delete') ?>" method="post" class="ms-auto" data-confirm="Mesaj silinsin mi?"><?= csrf_field() ?><button class="btn btn-outline-danger"><i class="bi bi-trash"></i> Sil</button></form>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="panel p-4">
            <h3 class="h6 mb-3">Gönderen Bilgileri</h3>
            <dl class="row small mb-0">
                <dt class="col-4 text-secondary">Ad Soyad</dt><dd class="col-8"><?= e($m['name']) ?></dd>
                <dt class="col-4 text-secondary">E-posta</dt><dd class="col-8 text-break"><?= e($m['email']) ?></dd>
                <dt class="col-4 text-secondary">Telefon</dt><dd class="col-8"><?= e($m['phone'] ?: '-') ?></dd>
                <dt class="col-4 text-secondary">IP</dt><dd class="col-8 font-monospace"><?= e($m['ip']) ?></dd>
                <dt class="col-4 text-secondary">Tarayıcı</dt><dd class="col-8 small text-break text-secondary"><?= e($m['user_agent']) ?></dd>
            </dl>
        </div>
    </div>
</div>
