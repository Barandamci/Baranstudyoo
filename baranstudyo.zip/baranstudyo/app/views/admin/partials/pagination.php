<?php if (($result['pages'] ?? 1) <= 1) { return; }
$qs = $_GET; ?>
<div class="d-flex justify-content-between align-items-center p-3 border-top border-secondary-subtle small">
    <span class="text-secondary">Toplam <?= (int) $result['total'] ?> kayıt</span>
    <ul class="pagination pagination-sm mb-0">
        <?php for ($i = 1; $i <= $result['pages']; $i++): $qs['sayfa'] = $i; ?>
        <li class="page-item <?= $i === $result['page'] ? 'active' : '' ?>"><a class="page-link" href="?<?= e(http_build_query($qs)) ?>"><?= $i ?></a></li>
        <?php endfor; ?>
    </ul>
</div>
