<?php /** @var array $user */ ?>
<form method="post" action="<?= admin_url('profile') ?>" class="panel p-4" style="max-width:720px">
    <?= csrf_field() ?>
    <div class="row g-3">
        <div class="col-md-6"><label class="form-label" for="name">Ad Soyad</label><input class="form-control" id="name" name="name" value="<?= e($user['name']) ?>" required></div>
        <div class="col-md-6"><label class="form-label" for="email">E-posta</label><input type="email" class="form-control" id="email" name="email" value="<?= e($user['email']) ?>" required></div>
        <div class="col-12"><hr class="border-secondary-subtle"><h2 class="h6">Şifre Değiştir <small class="text-secondary fw-normal">(değiştirmek istemiyorsanız boş bırakın)</small></h2></div>
        <div class="col-md-6"><label class="form-label" for="np">Yeni Şifre</label><input type="password" class="form-control" id="np" name="new_password" autocomplete="new-password"></div>
        <div class="col-md-6"><label class="form-label" for="npc">Yeni Şifre (Tekrar)</label><input type="password" class="form-control" id="npc" name="new_password_confirmation" autocomplete="new-password"></div>
        <div class="col-12"><div class="form-text">En az 10 karakter; büyük harf, küçük harf ve rakam içermelidir. Şifreler password_hash (bcrypt) ile saklanır.</div></div>
        <div class="col-md-6"><label class="form-label" for="cp">Mevcut Şifre <span class="text-danger">*</span></label><input type="password" class="form-control" id="cp" name="current_password" required autocomplete="current-password"></div>
    </div>
    <button class="btn btn-gradient mt-4" type="submit"><i class="bi bi-check-lg"></i> Kaydet</button>
    <p class="small text-secondary mt-3 mb-0">Son giriş: <?= e(tr_date($user['last_login_at'], true)) ?> · IP: <?= e($user['last_login_ip']) ?></p>
</form>
