<?php /** @var array $fields @var ?array $item @var string $route */
$val = static function (string $name, mixed $default = '') use ($item): string {
    $old = old($name, "\0");
    if ($old !== "\0") return $old;
    return (string) ($item[$name] ?? $default);
};
?>
<form method="post" enctype="multipart/form-data" action="<?= admin_url($item ? $route . '/' . (int) $item['id'] : $route) ?>" class="panel p-4">
    <?= csrf_field() ?>
    <div class="row g-3">
    <?php foreach ($fields as $name => $f):
        $type = $f['type']; $id = 'f_' . $name; $col = $f['col'] ?? 12;
        $required = str_contains($f['rules'] ?? '', 'required') || ($type === 'password' && !$item); ?>
        <div class="col-md-<?= (int) $col ?>">
        <?php if ($type === 'checkbox'): ?>
            <div class="form-check form-switch mt-2">
                <input class="form-check-input" type="checkbox" role="switch" id="<?= $id ?>" name="<?= e($name) ?>" value="1" <?= ($item ? (int) ($item[$name] ?? 0) : 1) ? 'checked' : '' ?>>
                <label class="form-check-label" for="<?= $id ?>"><?= e($f['label']) ?></label>
            </div>
        <?php else: ?>
            <label class="form-label" for="<?= $id ?>"><?= e($f['label']) ?><?= $required ? ' <span class="text-danger">*</span>' : '' ?></label>
            <?php switch ($type):
                case 'textarea': ?><textarea class="form-control" id="<?= $id ?>" name="<?= e($name) ?>" rows="3" <?= $required ? 'required' : '' ?>><?= e($val($name)) ?></textarea><?php break;
                case 'html': ?>
                    <div class="editor-toolbar" data-target="<?= $id ?>">
                        <button type="button" data-tag="h2">H2</button><button type="button" data-tag="h3">H3</button><button type="button" data-tag="p">P</button>
                        <button type="button" data-tag="strong"><i class="bi bi-type-bold"></i></button><button type="button" data-tag="em"><i class="bi bi-type-italic"></i></button>
                        <button type="button" data-tag="ul"><i class="bi bi-list-ul"></i></button><button type="button" data-tag="a"><i class="bi bi-link-45deg"></i></button>
                        <button type="button" data-tag="blockquote"><i class="bi bi-quote"></i></button><button type="button" data-tag="code"><i class="bi bi-code"></i></button>
                    </div>
                    <textarea class="form-control font-monospace editor" id="<?= $id ?>" name="<?= e($name) ?>" rows="12"><?= e($val($name)) ?></textarea><?php break;
                case 'select': ?><select class="form-select" id="<?= $id ?>" name="<?= e($name) ?>"><?php foreach ($f['options'] as $k => $l): ?><option value="<?= e($k) ?>" <?= (string) $k === $val($name, array_key_first($f['options'])) ? 'selected' : '' ?>><?= e($l) ?></option><?php endforeach; ?></select><?php break;
                case 'image': ?>
                    <div class="image-field">
                        <?php if (!empty($item[$name])): ?>
                        <img src="<?= e(upload_url($item[$name])) ?>" alt="" class="preview mb-2">
                        <div class="form-check mb-2"><input class="form-check-input" type="checkbox" name="remove_<?= e($name) ?>" value="1" id="rm_<?= $id ?>"><label class="form-check-label small" for="rm_<?= $id ?>">Mevcut görseli kaldır</label></div>
                        <?php else: ?><img src="" alt="" class="preview mb-2 d-none"><?php endif; ?>
                        <input type="file" class="form-control" id="<?= $id ?>" name="<?= e($name) ?>" accept="image/jpeg,image/png,image/webp,image/gif" data-preview>
                        <div class="form-text">JPG, PNG, WEBP veya GIF · en fazla <?= round(config('upload.max_size') / 1048576, 1) ?> MB · otomatik optimize edilir (WebP).</div>
                    </div><?php break;
                case 'password': ?><input type="password" class="form-control" id="<?= $id ?>" name="<?= e($name) ?>" autocomplete="new-password" <?= $required ? 'required' : '' ?>><?php break;
                case 'icon': ?><div class="input-group"><span class="input-group-text"><i class="bi <?= e($val($name, 'bi-code-slash')) ?>" data-icon-preview></i></span><input type="text" class="form-control" id="<?= $id ?>" name="<?= e($name) ?>" value="<?= e($val($name, 'bi-code-slash')) ?>" data-icon-input></div><?php break;
                default:
                    $inputType = match ($type) { 'number' => 'number', 'date' => 'date', 'datetime' => 'datetime-local', 'url' => 'url', 'email' => 'email', default => 'text' };
                    $v = $val($name);
                    if ($type === 'datetime' && $v !== '') { $v = date('Y-m-d\TH:i', strtotime($v) ?: time()); } ?>
                    <input type="<?= $inputType ?>" class="form-control" id="<?= $id ?>" name="<?= e($name) ?>" value="<?= e($v) ?>" <?= $required ? 'required' : '' ?> <?= $name === 'title' ? 'data-slug-source' : '' ?> <?= $name === 'slug' ? 'data-slug-target' : '' ?>>
            <?php endswitch; ?>
            <?php if (!empty($f['help'])): ?><div class="form-text"><?= e($f['help']) ?></div><?php endif; ?>
        <?php endif; ?>
        </div>
    <?php endforeach; ?>
    </div>
    <div class="d-flex gap-2 mt-4 pt-3 border-top border-secondary-subtle">
        <button class="btn btn-gradient" type="submit"><i class="bi bi-check-lg"></i> Kaydet</button>
        <a href="<?= admin_url($route) ?>" class="btn btn-outline-light">Listeye Dön</a>
    </div>
</form>
