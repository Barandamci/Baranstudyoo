<?php /** @var array $result @var array $columns @var string $route @var string $singular @var string $q */ ?>
<div class="panel">
    <div class="panel-head flex-wrap gap-2">
        <form class="d-flex gap-2" method="get" role="search">
            <input type="search" name="q" value="<?= e($q) ?>" class="form-control form-control-sm" placeholder="Ara..." aria-label="Ara">
            <button class="btn btn-sm btn-outline-light"><i class="bi bi-search"></i></button>
        </form>
        <a href="<?= admin_url($route . '/create') ?>" class="btn btn-gradient btn-sm"><i class="bi bi-plus-lg"></i> Yeni <?= e($singular) ?></a>
    </div>
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead><tr><?php foreach ($columns as [$label]): ?><th><?= e($label) ?></th><?php endforeach; ?><th class="text-end">İşlemler</th></tr></thead>
            <tbody>
            <?php foreach ($result['items'] as $item): ?>
                <tr>
                    <?php foreach ($columns as $key => $col): $type = $col[1] ?? 'text'; $v = $item[$key] ?? null; ?>
                    <td>
                        <?php switch ($type):
                            case 'image': ?><?php if ($v): ?><img src="<?= e(upload_url($v)) ?>" class="thumb" alt="" loading="lazy"><?php else: ?><span class="thumb thumb-empty"><i class="bi bi-image"></i></span><?php endif; ?><?php break;
                            case 'icon': ?><span class="icon-box"><i class="bi <?= e($v) ?>"></i></span><?php break;
                            case 'bool': ?><span class="badge <?= $v ? 'text-bg-success' : 'text-bg-secondary' ?>"><?= $v ? 'Evet' : 'Hayır' ?></span><?php break;
                            case 'status': ?><span class="badge <?= $v === 'published' ? 'text-bg-success' : 'text-bg-warning' ?>"><?= $v === 'published' ? 'Yayında' : 'Taslak' ?></span><?php break;
                            case 'role': ?><span class="badge <?= $v === 'owner' ? 'text-bg-danger' : ($v === 'user' ? 'text-bg-secondary' : 'text-bg-dark border') ?>"><?= e(['owner' => 'Owner', 'admin' => 'Yönetici', 'editor' => 'Editör', 'user' => 'Üye'][$v] ?? $v) ?></span><?php break;
                            case 'date': ?><?= e(tr_date($v)) ?><?php break;
                            case 'datetime': ?><?= e(tr_date($v, true)) ?><?php break;
                            default: ?><?= e(str_limit((string) $v, 70)) ?>
                        <?php endswitch; ?>
                    </td>
                    <?php endforeach; ?>
                    <td class="text-end text-nowrap">
                        <a href="<?= admin_url($route . '/' . (int) $item['id'] . '/edit') ?>" class="btn btn-sm btn-outline-light" title="Düzenle"><i class="bi bi-pencil"></i></a>
                        <form action="<?= admin_url($route . '/' . (int) $item['id'] . '/delete') ?>" method="post" class="d-inline" data-confirm="Bu kaydı silmek istediğinize emin misiniz?">
                            <?= csrf_field() ?><button class="btn btn-sm btn-outline-danger" title="Sil"><i class="bi bi-trash"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$result['items']): ?><tr><td colspan="<?= count($columns) + 1 ?>" class="text-center text-secondary py-5">Kayıt bulunamadı.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
    <?= App\Core\View::partial('admin/partials/pagination', ['result' => $result]) ?>
</div>
