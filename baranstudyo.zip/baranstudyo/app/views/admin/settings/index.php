<?php /** @var array $groups @var array $values */
$val = static fn (string $k) => old($k, "\0") !== "\0" ? old($k) : (string) ($values[$k] ?? ''); ?>
<form method="post" enctype="multipart/form-data" action="<?= admin_url('settings') ?>" class="panel">
    <?= csrf_field() ?>
    <input type="hidden" name="_tab" value="genel" id="activeTab">
    <ul class="nav nav-tabs px-3 pt-3" role="tablist">
        <?php $first = true; foreach ($groups as $key => [$label]): ?>
        <li class="nav-item" role="presentation"><button class="nav-link <?= $first ? 'active' : '' ?>" data-bs-toggle="tab" data-bs-target="#tab-<?= $key ?>" data-tab="<?= $key ?>" type="button" role="tab"><?= e($label) ?></button></li>
        <?php $first = false; endforeach; ?>
    </ul>
    <div class="tab-content p-4">
        <?php $first = true; foreach ($groups as $key => [$label, $fields]): ?>
        <div class="tab-pane fade <?= $first ? 'show active' : '' ?>" id="tab-<?= $key ?>" role="tabpanel">
            <div class="row g-3">
            <?php foreach ($fields as $name => $def): [$flabel, $type] = $def; $id = 's_' . $name; ?>
                <div class="<?= $type === 'textarea' || $type === 'image' ? 'col-12' : 'col-md-6' ?>">
                    <label class="form-label" for="<?= $id ?>"><?= e($flabel) ?></label>
                    <?php if ($type === 'textarea'): ?>
                        <textarea class="form-control" id="<?= $id ?>" name="<?= $name ?>" rows="<?= in_array($name, ['about_text', 'values'], true) ? 6 : 3 ?>"><?= e($val($name)) ?></textarea>
                    <?php elseif ($type === 'select'): ?>
                        <select class="form-select" id="<?= $id ?>" name="<?= $name ?>"><?php foreach ($def[2] as $ok => $ol): ?><option value="<?= e($ok) ?>" <?= (string) $ok === $val($name) ? 'selected' : '' ?>><?= e($ol) ?></option><?php endforeach; ?></select>
                    <?php elseif ($type === 'image'): ?>
                        <?php if (!empty($values[$name])): ?><img src="<?= e(upload_url($values[$name])) ?>" class="preview mb-2" alt="">
                        <div class="form-check mb-2"><input class="form-check-input" type="checkbox" name="remove_<?= $name ?>" value="1" id="rm_<?= $id ?>"><label class="form-check-label small" for="rm_<?= $id ?>">Görseli kaldır</label></div>
                        <?php else: ?><img src="" class="preview mb-2 d-none" alt=""><?php endif; ?>
                        <input type="file" class="form-control" id="<?= $id ?>" name="<?= $name ?>" accept="image/jpeg,image/png,image/webp" data-preview>
                    <?php else: ?>
                        <input type="<?= $type === 'number' ? 'number' : ($type === 'email' ? 'email' : ($type === 'url' ? 'url' : 'text')) ?>" class="form-control" id="<?= $id ?>" name="<?= $name ?>" value="<?= e($val($name)) ?>">
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
            </div>
        </div>
        <?php $first = false; endforeach; ?>
    </div>
    <div class="d-flex flex-wrap gap-2 p-4 pt-0">
        <button class="btn btn-gradient" type="submit"><i class="bi bi-check-lg"></i> Ayarları Kaydet</button>
    </div>
</form>
<div class="panel p-4 mt-4 d-flex flex-wrap align-items-center gap-3">
    <div><h2 class="h6 mb-1">Önbellek</h2><p class="small text-secondary mb-0">Sayfa ve veri önbelleği her içerik değişikliğinde otomatik temizlenir. Gerekirse manuel temizleyebilirsiniz.</p></div>
    <form action="<?= admin_url('settings/cache') ?>" method="post" class="ms-auto"><?= csrf_field() ?><button class="btn btn-outline-warning"><i class="bi bi-trash3"></i> Önbelleği Temizle</button></form>
</div>
