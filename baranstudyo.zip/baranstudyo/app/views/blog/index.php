<?php /** @var array $result */ ?>
<?= App\Core\View::partial('partials/page_hero', ['title' => 'Blog', 'subtitle' => 'Yazılım, yapay zekâ ve dijital dönüşüm üzerine yazılar', 'crumbs' => [['Blog', '/blog']]]) ?>
<section class="section">
    <div class="container">
        <div class="row g-4">
            <?php foreach ($result['items'] as $i => $post): ?>
            <div class="col-md-6 col-lg-4 reveal" style="--d: <?= ($i % 3) * 80 ?>ms"><?= App\Core\View::partial('partials/post_card', ['post' => $post]) ?></div>
            <?php endforeach; ?>
            <?php if (!$result['items']): ?><p class="text-muted-soft text-center">Henüz yazı yayınlanmamış.</p><?php endif; ?>
        </div>
        <?= App\Core\View::partial('partials/pagination', ['result' => $result, 'base' => 'blog']) ?>
    </div>
</section>
