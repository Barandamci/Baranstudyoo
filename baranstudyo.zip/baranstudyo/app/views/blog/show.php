<?php /** @var array $post @var array $recent */ ?>
<?= App\Core\View::partial('partials/page_hero', ['title' => $post['title'], 'subtitle' => '', 'crumbs' => [['Blog', '/blog'], [$post['title'], '/blog/' . $post['slug']]]]) ?>
<section class="section pt-4">
    <div class="container">
        <div class="row g-4 g-lg-5">
            <article class="col-lg-8 reveal">
                <div class="post-meta mb-4">
                    <span><i class="bi bi-calendar3"></i> <time datetime="<?= e(date('c', strtotime((string) $post['published_at']))) ?>"><?= e(tr_date($post['published_at'])) ?></time></span>
                    <?php if ($post['author_name']): ?><span><i class="bi bi-person"></i> <?= e($post['author_name']) ?></span><?php endif; ?>
                    <span><i class="bi bi-eye"></i> <?= (int) $post['views'] + 1 ?> görüntülenme</span>
                </div>
                <?php if ($post['image']): ?>
                <img src="<?= e(upload_url($post['image'])) ?>" alt="<?= e($post['title']) ?>" class="img-fluid rounded-4 mb-4 detail-image" width="1200" height="675">
                <?php endif; ?>
                <?php if ($post['excerpt']): ?><p class="lead-text"><?= e($post['excerpt']) ?></p><?php endif; ?>
                <div class="content-body"><?= $post['content'] ?></div>
                <div class="share-bar mt-5">
                    <span class="text-muted-soft">Paylaş:</span>
                    <?php $u = rawurlencode(absolute_url('blog/' . $post['slug'])); $t = rawurlencode($post['title']); ?>
                    <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?= $u ?>" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn"><i class="bi bi-linkedin"></i></a>
                    <a href="https://twitter.com/intent/tweet?url=<?= $u ?>&amp;text=<?= $t ?>" target="_blank" rel="noopener noreferrer" aria-label="X"><i class="bi bi-twitter-x"></i></a>
                    <a href="https://wa.me/?text=<?= $t ?>%20<?= $u ?>" target="_blank" rel="noopener noreferrer" aria-label="WhatsApp"><i class="bi bi-whatsapp"></i></a>
                </div>
            </article>
            <aside class="col-lg-4">
                <div class="side-card sticky-lg-top">
                    <h2 class="h5 mb-3">Son Yazılar</h2>
                    <ul class="side-list">
                        <?php foreach ($recent as $r): ?>
                        <li><a href="<?= url('blog/' . e($r['slug'])) ?>"><i class="bi bi-journal-text"></i> <?= e($r['title']) ?></a></li>
                        <?php endforeach; ?>
                    </ul>
                    <a href="<?= url('iletisim') ?>" class="btn btn-gradient w-100 mt-3">Projenizi konuşalım</a>
                </div>
            </aside>
        </div>
    </div>
</section>
