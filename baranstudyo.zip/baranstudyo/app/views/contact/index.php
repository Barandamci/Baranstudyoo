<?php /** @var array $services */
$prefill = isset($_GET['konu']) && is_string($_GET['konu']) ? mb_substr($_GET['konu'], 0, 150) : '';
?>
<?= App\Core\View::partial('partials/page_hero', ['title' => 'İletişim', 'subtitle' => 'Projenizi dinlemek için sabırsızlanıyoruz', 'crumbs' => [['İletişim', '/iletisim']]]) ?>
<section class="section">
    <div class="container">
        <div class="row g-4 g-lg-5">
            <div class="col-lg-5 reveal">
                <span class="eyebrow">Bize Ulaşın</span>
                <h2 class="section-title">Birlikte harika işler çıkaralım</h2>
                <p class="text-muted-soft mb-4">Formu doldurun, en geç 24 saat içinde size dönüş yapalım. Dilerseniz telefon veya WhatsApp üzerinden de bize ulaşabilirsiniz.</p>
                <div class="contact-items">
                    <?php if (setting('contact_phone')): ?>
                    <a class="contact-item" href="tel:<?= e(preg_replace('/[^0-9+]/', '', (string) setting('contact_phone'))) ?>"><i class="bi bi-telephone"></i><span><small>Telefon</small><?= e(setting('contact_phone')) ?></span></a>
                    <?php endif; ?>
                    <?php if (setting('contact_email')): ?>
                    <a class="contact-item" href="mailto:<?= e(setting('contact_email')) ?>"><i class="bi bi-envelope"></i><span><small>E-posta</small><?= e(setting('contact_email')) ?></span></a>
                    <?php endif; ?>
                    <?php if ($wa = whatsapp_link()): ?>
                    <a class="contact-item" href="<?= e($wa) ?>" target="_blank" rel="noopener noreferrer"><i class="bi bi-whatsapp"></i><span><small>WhatsApp</small>Hemen yazın</span></a>
                    <?php endif; ?>
                    <?php if (setting('contact_address')): ?>
                    <div class="contact-item"><i class="bi bi-geo-alt"></i><span><small>Adres</small><?= e(setting('contact_address')) ?></span></div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-lg-7 reveal" style="--d: 100ms">
                <div class="form-card" id="iletisim-formu">
                    <?php if ($msg = flash('success')): ?><div class="alert alert-success"><?= e($msg) ?></div><?php endif; ?>
                    <?php if ($msg = flash('error')): ?><div class="alert alert-danger"><?= e($msg) ?></div><?php endif; ?>
                    <div class="form-alert" role="status" aria-live="polite"></div>
                    <form action="<?= url('iletisim') ?>" method="post" class="ajax-form" novalidate>
                        <?= csrf_field() ?>
                        <input type="hidden" name="_ts" value="<?= time() ?>">
                        <div class="hp-field" aria-hidden="true"><label for="website">Web siteniz</label><input type="text" name="website" id="website" tabindex="-1" autocomplete="off"></div>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label" for="name">Ad Soyad *</label>
                                <input type="text" class="form-control" id="name" name="name" required minlength="3" maxlength="120" autocomplete="name" value="<?= e(old('name')) ?>">
                                <div class="invalid-feedback"></div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label" for="email">E-posta *</label>
                                <input type="email" class="form-control" id="email" name="email" required maxlength="190" autocomplete="email" value="<?= e(old('email')) ?>">
                                <div class="invalid-feedback"></div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label" for="phone">Telefon</label>
                                <input type="tel" class="form-control" id="phone" name="phone" maxlength="30" autocomplete="tel" value="<?= e(old('phone')) ?>" placeholder="05xx xxx xx xx">
                                <div class="invalid-feedback"></div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label" for="subject">Konu *</label>
                                <input type="text" class="form-control" id="subject" name="subject" required minlength="3" maxlength="200" list="subjectList" value="<?= e(old('subject', $prefill)) ?>">
                                <datalist id="subjectList">
                                    <?php foreach ($services as $s): ?><option value="<?= e($s['title']) ?>"><?php endforeach; ?>
                                </datalist>
                                <div class="invalid-feedback"></div>
                            </div>
                            <div class="col-12">
                                <label class="form-label" for="message">Mesaj *</label>
                                <textarea class="form-control" id="message" name="message" rows="6" required minlength="10" maxlength="5000"><?= e(old('message')) ?></textarea>
                                <div class="invalid-feedback"></div>
                            </div>
                            <div class="col-12">
                                <button type="submit" class="btn btn-gradient btn-lg w-100">
                                    <span class="btn-text">Mesajı Gönder <i class="bi bi-send"></i></span>
                                    <span class="btn-loading d-none"><span class="spinner-border spinner-border-sm"></span> Gönderiliyor...</span>
                                </button>
                                <p class="small text-muted-soft mt-2 mb-0"><i class="bi bi-shield-lock"></i> Bilgileriniz yalnızca size dönüş yapmak amacıyla kullanılır.</p>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
