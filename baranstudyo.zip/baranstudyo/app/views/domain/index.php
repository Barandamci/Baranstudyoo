<?= App\Core\View::partial('partials/page_hero', ['title' => 'Domain Sorgulama', 'subtitle' => 'Alan adının durumunu resmi RDAP / WHOIS kayıtlarından anlık olarak sorgulayın.', 'crumbs' => [['Domain Sorgulama', null]]]) ?>
<section class="section pt-5">
    <div class="container" style="max-width: 860px">
        <div class="domain-box reveal">
            <?= App\Core\View::partial('partials/domain_form') ?>
            <?php if ($lookup): ?><div class="domain-result-static"><?= App\Core\View::partial('partials/domain_result', ['lookup' => $lookup]) ?></div><?php endif; ?>
        </div>
        <p class="text-muted-soft small mt-4"><i class="bi bi-info-circle"></i> Sonuçlar, ilgili uzantının resmi kayıt otoritesinin RDAP servisinden (desteklemeyen uzantılarda WHOIS sunucusundan) alınır. Bilgi kaynakta yer almıyorsa gösterilmez.</p>
    </div>
</section>
