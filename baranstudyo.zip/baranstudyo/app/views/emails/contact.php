<?php /** @var array $m */ ?>
<div style="font-family:Arial,sans-serif;max-width:620px;margin:0 auto;background:#0b1226;color:#e2e8f0;border-radius:12px;overflow:hidden">
    <div style="padding:24px 28px;background:linear-gradient(90deg,#0ea5e9,#6366f1);color:#fff">
        <h2 style="margin:0;font-size:20px">Yeni İletişim Mesajı (#<?= (int) $m['id'] ?>)</h2>
    </div>
    <div style="padding:24px 28px">
        <table style="width:100%;border-collapse:collapse;color:#e2e8f0;font-size:14px">
            <tr><td style="padding:6px 0;width:110px;color:#94a3b8">Ad Soyad</td><td><?= e($m['name']) ?></td></tr>
            <tr><td style="padding:6px 0;color:#94a3b8">E-posta</td><td><?= e($m['email']) ?></td></tr>
            <tr><td style="padding:6px 0;color:#94a3b8">Telefon</td><td><?= e($m['phone'] ?: '-') ?></td></tr>
            <tr><td style="padding:6px 0;color:#94a3b8">Konu</td><td><?= e($m['subject']) ?></td></tr>
            <tr><td style="padding:6px 0;color:#94a3b8">IP</td><td><?= e($m['ip']) ?></td></tr>
        </table>
        <div style="margin-top:16px;padding:16px;background:#111a35;border-radius:8px;white-space:pre-wrap;line-height:1.6"><?= e($m['message']) ?></div>
        <p style="margin-top:20px;font-size:12px;color:#64748b">Bu mesaj <?= e(absolute_url()) ?> iletişim formundan gönderildi. Yanıtla diyerek doğrudan gönderene cevap verebilirsiniz.</p>
    </div>
</div>
