<section class="error-page">
    <div class="hero-grid" aria-hidden="true"></div>
    <div class="orb orb-1" aria-hidden="true"></div>
    <div class="container text-center position-relative">
        <div class="error-code text-gradient">404</div>
        <h1 class="h2 mb-3">Aradığınız sayfa bulunamadı</h1>
        <p class="text-muted-soft mb-4">Sayfa taşınmış, silinmiş veya hiç var olmamış olabilir.</p>
        <a href="<?= url() ?>" class="btn btn-gradient btn-lg"><i class="bi bi-house"></i> Ana sayfaya dön</a>
    </div>
</section>
