<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex">
<title>Geçici bir sorun oluştu</title>
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#050816;color:#e2e8f0;font-family:system-ui,-apple-system,Segoe UI,sans-serif;text-align:center;padding:20px}h1{font-size:72px;margin:0;background:linear-gradient(90deg,#22d3ee,#6366f1,#a855f7);-webkit-background-clip:text;background-clip:text;color:transparent}a{color:#22d3ee}</style>
</head>
<body><div><h1>500</h1><h2>Geçici bir sorun oluştu</h2><p>Teknik ekibimiz bilgilendirildi. Lütfen birkaç dakika sonra tekrar deneyin.</p><p><a href="/">Ana sayfaya dön</a></p></div></body>
</html>
