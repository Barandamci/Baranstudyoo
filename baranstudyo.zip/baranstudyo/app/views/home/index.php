<?php
/** @var array $services @var array $projects @var array $sites @var array $posts */
?>
<section class="hero">
    <div class="hero-grid" aria-hidden="true"></div>
    <div class="orb orb-1" aria-hidden="true"></div>
    <div class="orb orb-2" aria-hidden="true"></div>
    <div class="orb orb-3" aria-hidden="true"></div>
    <div class="container position-relative">
        <div class="row align-items-center g-4 g-lg-5">
            <div class="col-lg-6">
                <span class="hero-badge reveal"><span class="pulse-dot"></span><?= e(setting('hero_badge', 'Yeni nesil yazılım stüdyosu')) ?></span>
                <h1 class="hero-title reveal">
                    <?php
                    $title = (string) setting('hero_title', 'Dijital Dünyada Güçlü Çözümler');
                    $words = explode(' ', $title);
                    $last = array_pop($words);
                    echo e(implode(' ', $words)) . ' <span class="text-gradient">' . e($last) . '</span>';
                    ?>
                </h1>
                <p class="hero-subtitle reveal"><?= e(setting('hero_subtitle')) ?></p>
                <div class="hero-typing reveal" aria-hidden="true">
                    <i class="bi bi-terminal"></i> <span class="typing" data-words="Web Yazılım|Yapay Zekâ Çözümleri|Mobil Uygulama|E-Ticaret Sistemleri|Kurumsal Web Tasarım"></span><span class="caret"></span>
                </div>
                <div class="d-flex flex-wrap gap-3 mt-4 reveal">
                    <a href="<?= url('iletisim') ?>" class="btn btn-gradient btn-lg">İletişime Geçin <i class="bi bi-arrow-right"></i></a>
                    <a href="<?= url('projeler') ?>" class="btn btn-glass btn-lg"><i class="bi bi-grid-1x2"></i> Projelerimiz</a>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="hero-visual reveal">
                    <div class="code-window">
                        <div class="code-head"><span></span><span></span><span></span><em>BaranStudyo.php</em></div>
<pre class="code-body"><code><span class="c-k">final class</span> <span class="c-t">BaranStudyo</span>
{
    <span class="c-k">public function</span> <span class="c-f">build</span>(<span class="c-t">Idea</span> $idea): <span class="c-t">Product</span>
    {
        <span class="c-k">return</span> $idea
            -&gt;<span class="c-f">design</span>(<span class="c-s">'modern'</span>)
            -&gt;<span class="c-f">develop</span>(<span class="c-s">'PHP 8.3'</span>, <span class="c-s">'AI'</span>)
            -&gt;<span class="c-f">secure</span>()
            -&gt;<span class="c-f">launch</span>(<span class="c-s">'now'</span>);
    }
}</code></pre>
                    </div>
                    <div class="float-card fc-1"><i class="bi bi-shield-check"></i><div><strong>Güvenli</strong><span>Güvenlik odaklı kod</span></div></div>
                    <div class="float-card fc-2"><i class="bi bi-lightning-charge"></i><div><strong>Hızlı</strong><span>Optimize altyapı</span></div></div>
                    <div class="float-card fc-3"><i class="bi bi-cpu"></i><div><strong>Yapay Zekâ</strong><span>Akıllı sistemler</span></div></div>
                </div>
            </div>
        </div>
        <div class="domain-hero reveal" id="domain-sorgula">
            <div class="domain-hero-head"><i class="bi bi-globe2"></i><div><strong>Domain Sorgulama</strong><span>Alan adınızın müsaitlik durumunu resmi kayıtlardan anında öğrenin</span></div></div>
            <?= App\Core\View::partial('partials/domain_form') ?>
        </div>
    </div>
</section>

<section class="section" id="hakkimizda-ozet">
    <div class="container">
        <div class="row align-items-center g-4 g-lg-5">
            <div class="col-lg-5 reveal">
                <span class="eyebrow">Baran Stüdyo</span>
                <h2 class="section-title"><?= e(setting('about_title', 'Teknolojiyi işinizin gücüne dönüştürüyoruz')) ?></h2>
                <p class="text-muted-soft"><?= nl2br(e(str_limit(setting('about_text'), 420))) ?></p>
                <a href="<?= url('hakkimizda') ?>" class="link-arrow mt-2">Bizi daha yakından tanıyın <i class="bi bi-arrow-right"></i></a>
            </div>
            <div class="col-lg-7">
                <div class="row g-3">
                    <?php foreach ([
                        ['bi-rocket-takeoff', 'Uçtan Uca Geliştirme', 'Analiz, tasarım, yazılım, test ve yayın; tüm süreç tek ekipte.'],
                        ['bi-shield-lock', 'Güvenlik Öncelikli', 'SQL injection, XSS, CSRF ve brute force korumalı mimari.'],
                        ['bi-speedometer2', 'Performans Odaklı', 'Önbellek, görsel optimizasyonu ve temiz kod ile hızlı sistemler.'],
                        ['bi-headset', 'Sürekli Destek', 'Yayın sonrası bakım, izleme ve geliştirme desteği.'],
                    ] as $i => [$icon, $t, $d]): ?>
                    <div class="col-sm-6 reveal" style="--d: <?= $i * 80 ?>ms">
                        <div class="feature-card h-100">
                            <div class="feature-icon"><i class="bi <?= $icon ?>"></i></div>
                            <h3><?= e($t) ?></h3>
                            <p class="text-muted-soft mb-0"><?= e($d) ?></p>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section section-alt" id="hizmetler">
    <div class="container">
        <div class="section-head text-center reveal">
            <span class="eyebrow">Hizmetlerimiz</span>
            <h2 class="section-title">Dijital Dünyada Güçlü Çözümler</h2>
            <p class="text-muted-soft mx-auto">İşinizin her ihtiyacına yönelik, modern teknolojilerle geliştirilmiş uçtan uca yazılım hizmetleri.</p>
        </div>
        <div class="row g-4">
            <?php foreach ($services as $i => $s): ?>
            <div class="col-md-6 col-lg-3 reveal" style="--d: <?= ($i % 4) * 80 ?>ms">
                <a href="<?= url('hizmetler/' . e($s['slug'])) ?>" class="service-card h-100">
                    <div class="service-icon"><i class="bi <?= e($s['icon']) ?>"></i></div>
                    <h3><?= e($s['title']) ?></h3>
                    <p><?= e($s['short_description']) ?></p>
                    <span class="service-link">Detaylı bilgi <i class="bi bi-arrow-right"></i></span>
                </a>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="section" id="projeler">
    <div class="container">
        <div class="section-head d-flex flex-wrap justify-content-between align-items-end gap-3 reveal">
            <div>
                <span class="eyebrow">Projeler</span>
                <h2 class="section-title mb-0">Öne çıkan çalışmalarımız</h2>
            </div>
            <a href="<?= url('projeler') ?>" class="btn btn-glass">Tüm projeler <i class="bi bi-arrow-right"></i></a>
        </div>
        <?php if ($projects): ?><div class="row g-4">
            <?php foreach ($projects as $i => $p): ?>
            <div class="col-md-6 col-lg-4 reveal" style="--d: <?= ($i % 3) * 80 ?>ms"><?= App\Core\View::partial('partials/project_card', ['p' => $p]) ?></div>
            <?php endforeach; ?>
        </div><?php else: ?><?= App\Core\View::partial('partials/empty_state', ['icon' => 'bi-kanban', 'text' => 'Henüz proje eklenmedi.']) ?><?php endif; ?>
    </div>
</section>

<section class="section" id="siteler">
    <div class="container">
        <div class="section-head d-flex flex-wrap justify-content-between align-items-end gap-3 reveal">
            <div><span class="eyebrow">Sitelerimiz</span><h2 class="section-title mb-0">Baran Stüdyo'ya Ait Siteler</h2></div>
            <?php if ($sites): ?><a href="<?= url('siteler') ?>" class="btn btn-glass">Tümünü Gör <i class="bi bi-arrow-right"></i></a><?php endif; ?>
        </div>
        <?php if ($sites): ?>
        <div class="row g-4"><?php foreach (array_slice($sites, 0, 6) as $i => $s): ?><div class="col-md-6 col-lg-4 reveal" style="--d: <?= ($i % 3) * 80 ?>ms"><?= App\Core\View::partial('partials/site_card', ['s' => $s]) ?></div><?php endforeach; ?></div>
        <?php else: ?><?= App\Core\View::partial('partials/empty_state', ['icon' => 'bi-globe2', 'text' => 'Henüz site eklenmedi.']) ?><?php endif; ?>
    </div>
</section>


<section class="section section-alt">
    <div class="container">
        <div class="section-head text-center reveal">
            <span class="eyebrow">Çalışma Sürecimiz</span>
            <h2 class="section-title">Fikirden yayına 4 adım</h2>
        </div>
        <div class="row g-4 process">
            <?php foreach ([
                ['01', 'Keşif & Analiz', 'İhtiyaçlarınızı, hedef kitlenizi ve rakiplerinizi analiz ederek yol haritası çıkarırız.'],
                ['02', 'Tasarım', 'Kullanıcı deneyimi odaklı, markanıza özel arayüz tasarımları hazırlarız.'],
                ['03', 'Geliştirme', 'Güvenli, test edilmiş ve ölçeklenebilir kod ile ürününüzü hayata geçiririz.'],
                ['04', 'Yayın & Destek', 'Canlıya alır, performansı izler ve sürekli gelişim için yanınızda oluruz.'],
            ] as $i => [$n, $t, $d]): ?>
            <div class="col-md-6 col-lg-3 reveal" style="--d: <?= $i * 80 ?>ms">
                <div class="process-step h-100">
                    <span class="process-num"><?= $n ?></span>
                    <h3><?= e($t) ?></h3>
                    <p class="text-muted-soft mb-0"><?= e($d) ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>


<?php if ($posts): ?>
<section class="section section-alt">
    <div class="container">
        <div class="section-head d-flex flex-wrap justify-content-between align-items-end gap-3 reveal">
            <div>
                <span class="eyebrow">Blog</span>
                <h2 class="section-title mb-0">Güncel yazılar</h2>
            </div>
            <a href="<?= url('blog') ?>" class="btn btn-glass">Tüm yazılar <i class="bi bi-arrow-right"></i></a>
        </div>
        <div class="row g-4">
            <?php foreach ($posts as $i => $post): ?>
            <div class="col-md-6 col-lg-4 reveal" style="--d: <?= $i * 80 ?>ms"><?= App\Core\View::partial('partials/post_card', ['post' => $post]) ?></div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<div class="pt-5"></div>
<?= App\Core\View::partial('partials/cta') ?>
