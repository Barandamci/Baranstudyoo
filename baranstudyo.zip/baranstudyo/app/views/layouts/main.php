<?php
/** @var App\Core\Seo $seo */
/** @var string $content */
$seo ??= App\Core\Seo::make();
$gaId = preg_replace('/[^A-Z0-9\-]/i', '', (string) setting('google_analytics_id'));
$nonce = csp_nonce();
?>
<!DOCTYPE html>
<html lang="tr" data-bs-theme="dark">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($seo->title) ?></title>
    <meta name="description" content="<?= e($seo->description) ?>">
    <?php if (setting('site_keywords')): ?><meta name="keywords" content="<?= e(setting('site_keywords')) ?>"><?php endif; ?>
    <meta name="robots" content="<?= $seo->noindex ? 'noindex, nofollow' : 'index, follow, max-image-preview:large' ?>">
    <link rel="canonical" href="<?= e($seo->canonical) ?>">
    <meta name="theme-color" content="#050816">
    <?php if (setting('google_site_verification')): ?><meta name="google-site-verification" content="<?= e(setting('google_site_verification')) ?>"><?php endif; ?>

    <!-- Open Graph / Twitter -->
    <meta property="og:locale" content="tr_TR">
    <meta property="og:type" content="<?= e($seo->type) ?>">
    <meta property="og:site_name" content="<?= e(setting('site_title', config('app.name'))) ?>">
    <meta property="og:title" content="<?= e($seo->title) ?>">
    <meta property="og:description" content="<?= e($seo->description) ?>">
    <meta property="og:url" content="<?= e($seo->canonical) ?>">
    <meta property="og:image" content="<?= e($seo->image) ?>">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?= e($seo->title) ?>">
    <meta name="twitter:description" content="<?= e($seo->description) ?>">
    <meta name="twitter:image" content="<?= e($seo->image) ?>">

    <link rel="icon" href="<?= asset('img/favicon.png') ?>" type="image/png"><link rel="apple-touch-icon" href="<?= asset('img/apple-touch-icon.png') ?>">
    <link rel="apple-touch-icon" href="<?= asset('img/logo.png') ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preconnect" href="https://cdn.jsdelivr.net" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?= asset('css/style.css') ?>" rel="stylesheet">

    <?= $seo->jsonLd() ?>

    <?php if ($gaId !== ''): ?>
    <script async src="https://www.googletagmanager.com/gtag/js?id=<?= e($gaId) ?>"></script>
    <script nonce="<?= e($nonce) ?>">window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','<?= e($gaId) ?>',{anonymize_ip:true});</script>
    <?php endif; ?>
</head>
<body>
<a class="visually-hidden-focusable skip-link" href="#main">İçeriğe geç</a>
<?= App\Core\View::partial('partials/header') ?>

<main id="main">
    <?= $content ?>
</main>

<?= App\Core\View::partial('partials/footer') ?>

<?php if ($wa = whatsapp_link()): ?>
<a href="<?= e($wa) ?>" class="whatsapp-float" target="_blank" rel="noopener noreferrer" aria-label="WhatsApp ile iletişime geçin">
    <i class="bi bi-whatsapp"></i><span class="whatsapp-tooltip">WhatsApp ile yazın</span>
</a>
<?php endif; ?>
<button type="button" class="back-to-top" aria-label="Yukarı çık"><i class="bi bi-arrow-up"></i></button>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous" defer></script>
<script src="<?= asset('js/main.js') ?>" defer></script>
</body>
</html>
