<?php /** @var array $values @var array $services */ ?>
<?= App\Core\View::partial('partials/page_hero', ['title' => 'Hakkımızda', 'subtitle' => setting('site_tagline'), 'crumbs' => [['Hakkımızda', '/hakkimizda']]]) ?>

<section class="section">
    <div class="container">
        <div class="row g-4 g-lg-5 align-items-center">
            <div class="col-lg-6 reveal">
                <span class="eyebrow">Firma Bilgileri</span>
                <h2 class="section-title"><?= e(setting('about_title')) ?></h2>
                <div class="text-muted-soft lead-text"><?= nl2br(e(setting('about_text'))) ?></div>
            </div>
            <div class="col-lg-6 reveal">
                <div class="about-panel">
                    <img src="<?= asset('img/logo.webp') ?>" alt="Baran Stüdyo logosu" width="220" height="220" class="d-block mx-auto" loading="lazy">
                    <ul class="check-list mt-4 mb-0">
                        <li><i class="bi bi-check2-circle"></i> PHP 8.3, yapay zekâ ve modern web teknolojileri</li>
                        <li><i class="bi bi-check2-circle"></i> Güvenlik ve performans odaklı yazılım mimarisi</li>
                        <li><i class="bi bi-check2-circle"></i> Şeffaf süreç yönetimi ve uzun soluklu destek</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section section-alt">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-6 reveal">
                <div class="mv-card h-100">
                    <div class="feature-icon"><i class="bi bi-bullseye"></i></div>
                    <h2>Misyonumuz</h2>
                    <p class="text-muted-soft mb-0"><?= nl2br(e(setting('mission'))) ?></p>
                </div>
            </div>
            <div class="col-lg-6 reveal" style="--d: 100ms">
                <div class="mv-card h-100">
                    <div class="feature-icon"><i class="bi bi-eye"></i></div>
                    <h2>Vizyonumuz</h2>
                    <p class="text-muted-soft mb-0"><?= nl2br(e(setting('vision'))) ?></p>
                </div>
            </div>
        </div>
    </div>
</section>

<?php if ($values): ?>
<section class="section">
    <div class="container">
        <div class="section-head text-center reveal">
            <span class="eyebrow">Değerlerimiz</span>
            <h2 class="section-title">Bizi biz yapan ilkeler</h2>
        </div>
        <div class="row g-4">
            <?php $icons = ['bi-eye', 'bi-gem', 'bi-shield-check', 'bi-lightbulb', 'bi-lightning', 'bi-people'];
            foreach ($values as $i => $v): ?>
            <div class="col-md-6 col-lg-4 reveal" style="--d: <?= ($i % 3) * 80 ?>ms">
                <div class="feature-card h-100">
                    <div class="feature-icon"><i class="bi <?= $icons[$i % count($icons)] ?>"></i></div>
                    <h3><?= e($v['title']) ?></h3>
                    <p class="text-muted-soft mb-0"><?= e($v['description']) ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<?= App\Core\View::partial('partials/cta') ?>
