<?php if ($m = flash('success')): ?><div class="alert alert-success"><i class="bi bi-check-circle"></i> <?= e($m) ?></div><?php endif; ?>
<?php if ($m = flash('error')): ?><div class="alert alert-danger"><i class="bi bi-exclamation-triangle"></i> <?= e($m) ?></div><?php endif; ?>
