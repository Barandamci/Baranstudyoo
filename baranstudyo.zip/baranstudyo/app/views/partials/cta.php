<section class="section pt-0">
    <div class="container">
        <div class="cta-box reveal">
            <div class="cta-glow" aria-hidden="true"></div>
            <div class="row align-items-center g-4 position-relative">
                <div class="col-lg-8">
                    <span class="eyebrow">Projenizi konuşalım</span>
                    <h2 class="cta-title">Fikrinizi güçlü bir dijital ürüne dönüştürelim.</h2>
                    <p class="text-muted-soft mb-0">Ücretsiz keşif görüşmesi için bize ulaşın; ihtiyaçlarınızı analiz edip size özel yol haritası ve teklif hazırlayalım.</p>
                </div>
                <div class="col-lg-4 text-lg-end d-flex flex-wrap gap-2 justify-content-lg-end">
                    <a href="<?= url('iletisim') ?>" class="btn btn-gradient btn-lg">İletişime Geçin <i class="bi bi-arrow-right"></i></a>
                    <?php if ($wa = whatsapp_link()): ?>
                    <a href="<?= e($wa) ?>" class="btn btn-outline-light btn-lg" target="_blank" rel="noopener noreferrer"><i class="bi bi-whatsapp"></i> WhatsApp</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>
