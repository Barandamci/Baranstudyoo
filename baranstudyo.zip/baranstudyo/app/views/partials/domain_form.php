<?php $tlds = App\Core\DomainChecker::tlds(); $selTld = $_GET['tld'] ?? $tlds[0]; ?>
<form class="domain-form" action="<?= url('domain-sorgula') ?>" method="get" data-domain-form data-api="<?= url('domain-sorgula/api') ?>" role="search">
    <div class="domain-input">
        <i class="bi bi-globe2" aria-hidden="true"></i>
        <input type="text" name="domain" value="<?= e($_GET['domain'] ?? '') ?>" placeholder="alanadiniz" aria-label="Domain adı" maxlength="63" autocomplete="off" spellcheck="false" required>
        <select name="tld" aria-label="Uzantı">
            <?php foreach ($tlds as $t): ?><option value="<?= e($t) ?>" <?= $t === $selTld ? 'selected' : '' ?>>.<?= e($t) ?></option><?php endforeach; ?>
        </select>
        <button type="submit" class="btn btn-gradient"><span class="d-none d-sm-inline">Sorgula</span><i class="bi bi-search d-sm-none"></i></button>
    </div>
    <div class="domain-result" aria-live="polite"></div>
</form>
