<?php /** @var array $lookup */
if (!$lookup['ok']): ?>
<div class="dr dr-error"><i class="bi bi-exclamation-circle"></i> <?= e($lookup['message']) ?></div>
<?php else: $r = $lookup['result']; ?>
<div class="dr <?= $r['status'] === 'available' ? 'dr-ok' : 'dr-taken' ?>">
    <div class="dr-head">
        <i class="bi <?= $r['status'] === 'available' ? 'bi-check-circle-fill' : 'bi-x-circle-fill' ?>"></i>
        <div><strong><?= e($r['domain']) ?></strong> <span><?= $r['status'] === 'available' ? 'müsait — kayıt edilebilir' : 'kayıtlı — alınmış' ?></span></div>
    </div>
    <?php if ($r['status'] === 'registered'): ?>
    <dl class="dr-info">
        <div><dt>Kayıt tarihi</dt><dd><?= e($r['created'] ? tr_date($r['created']) : 'Kayıt kaynağında yok') ?></dd></div>
        <div><dt>Bitiş tarihi</dt><dd><?= e($r['expires'] ? tr_date($r['expires']) : 'Kayıt kaynağında yok') ?></dd></div>
        <?php if ($r['registrar']): ?><div><dt>Kayıt firması</dt><dd><?= e($r['registrar']) ?></dd></div><?php endif; ?>
        <?php if ($r['nameservers']): ?><div><dt>DNS</dt><dd><?= e(implode(', ', $r['nameservers'])) ?></dd></div><?php endif; ?>
    </dl>
    <?php endif; ?>
    <small class="dr-src">Kaynak: <?= e($r['source']) ?> · <?= e(tr_date($r['checked_at'], true)) ?></small>
</div>
<?php endif; ?>
