<div class="empty-state reveal"><i class="bi <?= e($icon ?? 'bi-inbox') ?>"></i><p><?= e($text) ?></p></div>
