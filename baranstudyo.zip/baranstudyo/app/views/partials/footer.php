<?php
$social = array_filter([
    'instagram' => setting('social_instagram'),
    'linkedin' => setting('social_linkedin'),
    'github' => setting('social_github'),
    'twitter-x' => setting('social_x'),
    'youtube' => setting('social_youtube'),
]);
try {
    $footerServices = array_slice(App\Models\Service::active(), 0, 6);
} catch (Throwable) {
    $footerServices = [];
}
?>
<footer class="site-footer">
    <div class="footer-glow" aria-hidden="true"></div>
    <div class="container">
        <div class="row g-4 g-lg-5">
            <div class="col-lg-4">
                <a class="brand mb-3 d-inline-flex" href="<?= url() ?>">
                    <span class="brand-mark"><img src="<?= asset('img/logo-mark.webp') ?>" alt="" width="54" height="40" loading="lazy"></span>
                    <span class="brand-text">Baran<span>Stüdyo</span></span>
                </a>
                <p class="text-muted-soft"><?= e(setting('footer_text')) ?></p>
                <?php if ($social): ?>
                <div class="social-links">
                    <?php foreach ($social as $icon => $link): ?>
                    <a href="<?= e($link) ?>" target="_blank" rel="noopener noreferrer" aria-label="<?= e(ucfirst($icon)) ?>"><i class="bi bi-<?= e($icon) ?>"></i></a>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
            <div class="col-6 col-lg-2">
                <h3 class="footer-title">Kurumsal</h3>
                <ul class="footer-links">
                    <li><a href="<?= url('hakkimizda') ?>">Hakkımızda</a></li>
                    <li><a href="<?= url('projeler') ?>">Projeler</a></li>
                    <li><a href="<?= url('blog') ?>">Blog</a></li>
                    <li><a href="<?= url('iletisim') ?>">İletişim</a></li>
                </ul>
            </div>
            <div class="col-6 col-lg-3">
                <h3 class="footer-title">Hizmetler</h3>
                <ul class="footer-links">
                    <?php foreach ($footerServices as $s): ?>
                    <li><a href="<?= url('hizmetler/' . e($s['slug'])) ?>"><?= e($s['title']) ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <div class="col-lg-3">
                <h3 class="footer-title">İletişim</h3>
                <ul class="footer-contact">
                    <?php if (setting('contact_phone')): ?>
                    <li><i class="bi bi-telephone"></i><a href="tel:<?= e(preg_replace('/[^0-9+]/', '', (string) setting('contact_phone'))) ?>"><?= e(setting('contact_phone')) ?></a></li>
                    <?php endif; ?>
                    <?php if (setting('contact_email')): ?>
                    <li><i class="bi bi-envelope"></i><a href="mailto:<?= e(setting('contact_email')) ?>"><?= e(setting('contact_email')) ?></a></li>
                    <?php endif; ?>
                    <?php if (setting('contact_address')): ?>
                    <li><i class="bi bi-geo-alt"></i><span><?= e(setting('contact_address')) ?></span></li>
                    <?php endif; ?>
                    <?php if (setting('working_hours')): ?>
                    <li><i class="bi bi-clock"></i><span><?= e(setting('working_hours')) ?></span></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <span>&copy; <?= date('Y') ?> <?= e(setting('site_title', 'Baran Stüdyo')) ?>. Tüm hakları saklıdır.</span>
            <span class="text-muted-soft">baranstudyo.net.tr</span>
        </div>
    </div>
</footer>
