<?php
$nav = [
    ['/', 'Ana Sayfa'],
    ['/hakkimizda', 'Hakkımızda'],
    ['/hizmetler', 'Hizmetler'],
    ['/projeler', 'Projeler'],
    ['/siteler', 'Siteler'],
    ['/domain-sorgula', 'Domain Sorgula'],
    ['/iletisim', 'İletişim'],
];
?>
<header class="site-header">
    <nav class="navbar navbar-expand-lg fixed-top" id="mainNav" aria-label="Ana menü">
        <div class="container">
            <a class="navbar-brand brand" href="<?= url() ?>" aria-label="<?= e(setting('site_title', 'Baran Stüdyo')) ?> ana sayfa">
                <span class="brand-mark"><img src="<?= asset('img/logo-mark.webp') ?>" alt="" width="54" height="40"></span>
                <span class="brand-text">Baran<span>Stüdyo</span></span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#mobileMenu" aria-controls="mobileMenu" aria-label="Menüyü aç">
                <span class="toggler-bar"></span><span class="toggler-bar"></span><span class="toggler-bar"></span>
            </button>
            <div class="offcanvas offcanvas-end" tabindex="-1" id="mobileMenu" aria-labelledby="mobileMenuLabel">
                <div class="offcanvas-header">
                    <span class="brand-text" id="mobileMenuLabel">Baran<span>Stüdyo</span></span>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Kapat"></button>
                </div>
                <div class="offcanvas-body">
                    <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-1">
                        <?php foreach ($nav as [$path, $label]): ?>
                        <li class="nav-item">
                            <a class="nav-link <?= is_active($path) ?>" href="<?= url($path) ?>" <?= is_active($path) ? 'aria-current="page"' : '' ?>><?= e($label) ?></a>
                        </li>
                        <?php endforeach; ?>
                        <li class="nav-item ms-lg-3 mt-3 mt-lg-0 d-flex gap-2">
                            <?php if (App\Core\Auth::check()): ?>
                            <a class="btn btn-glass btn-sm px-3" href="<?= url('hesabim') ?>"><i class="bi bi-person-circle"></i> Hesabım</a>
                            <?php else: ?>
                            <a class="btn btn-glass btn-sm px-3" href="<?= url('giris') ?>">Giriş</a>
                            <a class="btn btn-gradient btn-sm px-3" href="<?= url('kayit') ?>">Kayıt Ol</a>
                            <?php endif; ?>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>
</header>
