<?php /** @var string $title @var string $subtitle @var array $crumbs */ ?>
<section class="page-hero">
    <div class="hero-grid" aria-hidden="true"></div>
    <div class="orb orb-1" aria-hidden="true"></div>
    <div class="container position-relative">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= url() ?>">Ana Sayfa</a></li>
                <?php foreach ($crumbs ?? [] as $i => [$label, $path]): ?>
                    <?php if ($i === array_key_last($crumbs)): ?>
                    <li class="breadcrumb-item active" aria-current="page"><?= e($label) ?></li>
                    <?php else: ?>
                    <li class="breadcrumb-item"><a href="<?= url($path) ?>"><?= e($label) ?></a></li>
                    <?php endif; ?>
                <?php endforeach; ?>
            </ol>
        </nav>
        <h1 class="page-title reveal"><?= e($title) ?></h1>
        <?php if (!empty($subtitle)): ?><p class="page-subtitle reveal"><?= e($subtitle) ?></p><?php endif; ?>
    </div>
</section>
