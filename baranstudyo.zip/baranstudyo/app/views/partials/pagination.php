<?php /** @var array $result @var string $base */
if (($result['pages'] ?? 1) <= 1) {
    return;
}
$link = static fn (int $p) => url($base) . ($p > 1 ? '?sayfa=' . $p : '');
?>
<nav class="mt-5" aria-label="Sayfalama">
    <ul class="pagination justify-content-center">
        <li class="page-item <?= $result['page'] <= 1 ? 'disabled' : '' ?>"><a class="page-link" href="<?= e($link(max(1, $result['page'] - 1))) ?>" rel="prev" aria-label="Önceki"><i class="bi bi-chevron-left"></i></a></li>
        <?php for ($i = 1; $i <= $result['pages']; $i++): ?>
        <li class="page-item <?= $i === $result['page'] ? 'active' : '' ?>"><a class="page-link" href="<?= e($link($i)) ?>"><?= $i ?></a></li>
        <?php endfor; ?>
        <li class="page-item <?= $result['page'] >= $result['pages'] ? 'disabled' : '' ?>"><a class="page-link" href="<?= e($link(min($result['pages'], $result['page'] + 1))) ?>" rel="next" aria-label="Sonraki"><i class="bi bi-chevron-right"></i></a></li>
    </ul>
</nav>
