<?php /** @var array $post */ ?>
<article class="post-card h-100">
    <a href="<?= url('blog/' . e($post['slug'])) ?>" class="post-thumb" aria-label="<?= e($post['title']) ?>">
        <?php if ($post['image']): ?>
        <img src="<?= e(upload_url($post['image'])) ?>" alt="<?= e($post['title']) ?>" loading="lazy" width="800" height="450">
        <?php else: ?>
        <div class="project-placeholder" data-seed="<?= ((int) $post['id'] + 1) % 4 ?>"><i class="bi bi-journal-code"></i></div>
        <?php endif; ?>
    </a>
    <div class="post-body">
        <time class="text-muted-soft small" datetime="<?= e(date('Y-m-d', strtotime((string) $post['published_at']))) ?>"><i class="bi bi-calendar3 me-1"></i><?= e(tr_date($post['published_at'])) ?></time>
        <h3 class="post-title"><a href="<?= url('blog/' . e($post['slug'])) ?>"><?= e($post['title']) ?></a></h3>
        <p class="text-muted-soft"><?= e(str_limit($post['excerpt'], 130)) ?></p>
        <a class="link-arrow" href="<?= url('blog/' . e($post['slug'])) ?>">Devamını oku <i class="bi bi-arrow-right"></i></a>
    </div>
</article>
