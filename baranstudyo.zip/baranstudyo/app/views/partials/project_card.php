<?php /** @var array $p */ ?>
<article class="project-card h-100">
    <a href="<?= url('projeler/' . e($p['slug'])) ?>" class="project-thumb" aria-label="<?= e($p['title']) ?>">
        <?php if ($p['image']): ?>
        <img src="<?= e(upload_url($p['image'])) ?>" alt="<?= e($p['title']) ?>" loading="lazy" width="800" height="500">
        <?php else: ?>
        <div class="project-placeholder" data-seed="<?= (int) $p['id'] % 4 ?>"><i class="bi bi-window-stack"></i><span><?= e($p['category'] ?: 'Proje') ?></span></div>
        <?php endif; ?>
        <span class="project-overlay"><i class="bi bi-arrow-up-right"></i></span>
    </a>
    <div class="project-body">
        <div class="project-meta">
            <?php if ($p['category']): ?><span class="badge-soft"><?= e($p['category']) ?></span><?php endif; ?>
            <?php if ($p['project_date']): ?><span class="text-muted-soft small"><?= e(tr_date($p['project_date'])) ?></span><?php endif; ?>
        </div>
        <h3 class="project-title"><a href="<?= url('projeler/' . e($p['slug'])) ?>"><?= e($p['title']) ?></a></h3>
        <p class="text-muted-soft mb-3"><?= e(str_limit($p['summary'], 120)) ?></p>
        <div class="tech-tags">
            <?php foreach (array_slice(tech_list($p['technologies']), 0, 4) as $t): ?><span><?= e($t) ?></span><?php endforeach; ?>
        </div>
    </div>
</article>
