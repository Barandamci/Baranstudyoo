<?php /** @var array $s */ ?>
<a class="site-card" href="<?= e($s['url'] ?: 'https://' . $s['domain']) ?>" target="_blank" rel="noopener">
    <span class="site-logo"><?php if ($s['logo']): ?><img src="<?= e(upload_url($s['logo'])) ?>" alt="<?= e($s['name']) ?> logosu" loading="lazy"><?php else: ?><i class="bi bi-globe2"></i><?php endif; ?></span>
    <span class="site-body"><strong><?= e($s['name']) ?></strong><small><?= e($s['domain']) ?></small>
    <?php if ($s['description']): ?><span class="site-desc"><?= e(str_limit($s['description'], 140)) ?></span><?php endif; ?></span>
    <i class="bi bi-box-arrow-up-right site-go"></i>
</a>
