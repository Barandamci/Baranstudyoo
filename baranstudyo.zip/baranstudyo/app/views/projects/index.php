<?php /** @var array $result @var array $categories */ ?>
<?= App\Core\View::partial('partials/page_hero', ['title' => 'Projelerimiz', 'subtitle' => 'Farklı sektörlerde hayata geçirdiğimiz dijital çözümler', 'crumbs' => [['Projeler', '/projeler']]]) ?>
<section class="section">
    <div class="container">
        <?php if (count($categories) > 1): ?>
        <div class="filter-bar reveal" role="tablist" aria-label="Proje kategorileri">
            <button type="button" class="filter-btn active" data-filter="*">Tümü</button>
            <?php foreach ($categories as $c): ?>
            <button type="button" class="filter-btn" data-filter="<?= e(slugify($c)) ?>"><?= e($c) ?></button>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
        <div class="row g-4" id="projectGrid">
            <?php foreach ($result['items'] as $i => $p): ?>
            <div class="col-md-6 col-lg-4 reveal project-item" data-category="<?= e(slugify((string) $p['category'])) ?>" style="--d: <?= ($i % 3) * 80 ?>ms"><?= App\Core\View::partial('partials/project_card', ['p' => $p]) ?></div>
            <?php endforeach; ?>
            <?php if (!$result['items']): ?><p class="text-muted-soft text-center">Henüz proje eklenmemiş.</p><?php endif; ?>
        </div>
        <?= App\Core\View::partial('partials/pagination', ['result' => $result, 'base' => 'projeler']) ?>
    </div>
</section>
<?= App\Core\View::partial('partials/cta') ?>
