<?php /** @var array $project @var array $related */ ?>
<?= App\Core\View::partial('partials/page_hero', ['title' => $project['title'], 'subtitle' => $project['summary'], 'crumbs' => [['Projeler', '/projeler'], [$project['title'], '/projeler/' . $project['slug']]]]) ?>
<section class="section">
    <div class="container">
        <div class="row g-4 g-lg-5">
            <div class="col-lg-8 reveal">
                <div class="detail-media mb-4">
                    <?php if ($project['image']): ?>
                    <img src="<?= e(upload_url($project['image'])) ?>" alt="<?= e($project['title']) ?>" class="img-fluid" width="1200" height="750">
                    <?php else: ?>
                    <div class="project-placeholder lg" data-seed="<?= (int) $project['id'] % 4 ?>"><i class="bi bi-window-stack"></i><span><?= e($project['category'] ?: 'Proje') ?></span></div>
                    <?php endif; ?>
                </div>
                <div class="content-body"><?= $project['content'] ?: '<p>' . e($project['summary']) . '</p>' ?></div>
            </div>
            <aside class="col-lg-4">
                <div class="side-card sticky-lg-top">
                    <h2 class="h5 mb-3">Proje Bilgileri</h2>
                    <dl class="info-list">
                        <?php if ($project['client']): ?><dt>Müşteri</dt><dd><?= e($project['client']) ?></dd><?php endif; ?>
                        <?php if ($project['category']): ?><dt>Kategori</dt><dd><?= e($project['category']) ?></dd><?php endif; ?>
                        <?php if ($project['project_date']): ?><dt>Tarih</dt><dd><?= e(tr_date($project['project_date'])) ?></dd><?php endif; ?>
                    </dl>
                    <?php if ($techs = tech_list($project['technologies'])): ?>
                    <h3 class="h6 mt-4 mb-2">Kullanılan Teknolojiler</h3>
                    <div class="tech-tags"><?php foreach ($techs as $t): ?><span><?= e($t) ?></span><?php endforeach; ?></div>
                    <?php endif; ?>
                    <?php if ($project['project_url']): ?>
                    <a href="<?= e($project['project_url']) ?>" class="btn btn-gradient w-100 mt-4" target="_blank" rel="noopener noreferrer">Projeyi incele <i class="bi bi-box-arrow-up-right"></i></a>
                    <?php endif; ?>
                    <a href="<?= url('iletisim') ?>" class="btn btn-glass w-100 mt-2">Benzer bir proje istiyorum</a>
                </div>
            </aside>
        </div>
        <?php if ($related): ?>
        <div class="mt-5 pt-4">
            <h2 class="section-title h3 mb-4">Diğer Projeler</h2>
            <div class="row g-4">
                <?php foreach ($related as $p): ?>
                <div class="col-md-6 col-lg-4 reveal"><?= App\Core\View::partial('partials/project_card', ['p' => $p]) ?></div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
</section>
