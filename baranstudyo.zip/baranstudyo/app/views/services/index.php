<?php /** @var array $services */ ?>
<?= App\Core\View::partial('partials/page_hero', ['title' => 'Hizmetlerimiz', 'subtitle' => 'İşinizi büyütecek uçtan uca dijital çözümler', 'crumbs' => [['Hizmetler', '/hizmetler']]]) ?>
<section class="section">
    <div class="container">
        <div class="row g-4">
            <?php foreach ($services as $i => $s): ?>
            <div class="col-md-6 col-lg-4 reveal" style="--d: <?= ($i % 3) * 80 ?>ms">
                <a href="<?= url('hizmetler/' . e($s['slug'])) ?>" class="service-card service-card-lg h-100">
                    <div class="service-icon"><i class="bi <?= e($s['icon']) ?>"></i></div>
                    <h2><?= e($s['title']) ?></h2>
                    <p><?= e($s['short_description']) ?></p>
                    <span class="service-link">Detaylı bilgi <i class="bi bi-arrow-right"></i></span>
                </a>
            </div>
            <?php endforeach; ?>
            <?php if (!$services): ?><p class="text-muted-soft text-center">Henüz hizmet eklenmemiş.</p><?php endif; ?>
        </div>
    </div>
</section>
<?= App\Core\View::partial('partials/cta') ?>
