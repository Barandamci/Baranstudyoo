<?php /** @var array $service @var array $others */ ?>
<?= App\Core\View::partial('partials/page_hero', ['title' => $service['title'], 'subtitle' => $service['short_description'], 'crumbs' => [['Hizmetler', '/hizmetler'], [$service['title'], '/hizmetler/' . $service['slug']]]]) ?>
<section class="section">
    <div class="container">
        <div class="row g-4 g-lg-5">
            <div class="col-lg-8 reveal">
                <?php if ($service['image']): ?>
                <img src="<?= e(upload_url($service['image'])) ?>" alt="<?= e($service['title']) ?>" class="img-fluid rounded-4 mb-4 detail-image" loading="lazy">
                <?php endif; ?>
                <div class="content-body"><?= $service['content'] /* Kayıt sırasında Sanitizer ile temizlenir */ ?></div>
                <a href="<?= url('iletisim') ?>?konu=<?= rawurlencode($service['title']) ?>" class="btn btn-gradient mt-4">Bu hizmet için teklif alın <i class="bi bi-arrow-right"></i></a>
            </div>
            <aside class="col-lg-4">
                <div class="side-card sticky-lg-top">
                    <h2 class="h5 mb-3">Diğer Hizmetler</h2>
                    <ul class="side-list">
                        <?php foreach ($others as $o): ?>
                        <li><a href="<?= url('hizmetler/' . e($o['slug'])) ?>"><i class="bi <?= e($o['icon']) ?>"></i> <?= e($o['title']) ?></a></li>
                        <?php endforeach; ?>
                    </ul>
                    <hr class="border-secondary-subtle">
                    <p class="small text-muted-soft mb-2">Hemen bilgi almak ister misiniz?</p>
                    <?php if ($wa = whatsapp_link()): ?>
                    <a href="<?= e($wa) ?>" class="btn btn-success w-100" target="_blank" rel="noopener noreferrer"><i class="bi bi-whatsapp"></i> WhatsApp ile yazın</a>
                    <?php endif; ?>
                </div>
            </aside>
        </div>
    </div>
</section>
