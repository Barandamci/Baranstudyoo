<?= App\Core\View::partial('partials/page_hero', ['title' => "Baran Stüdyo'ya Ait Siteler", 'subtitle' => 'Geliştirdiğimiz ve yayında olan web sitelerimiz', 'crumbs' => [['Siteler', '/siteler']]]) ?>
<section class="section pt-5">
    <div class="container">
        <?php if ($sites): ?>
        <div class="row g-4"><?php foreach ($sites as $i => $s): ?><div class="col-md-6 col-lg-4 reveal" style="--d: <?= ($i % 3) * 80 ?>ms"><?= App\Core\View::partial('partials/site_card', ['s' => $s]) ?></div><?php endforeach; ?></div>
        <?php else: ?><?= App\Core\View::partial('partials/empty_state', ['icon' => 'bi-globe2', 'text' => 'Henüz site eklenmedi.']) ?><?php endif; ?>
    </div>
</section>
