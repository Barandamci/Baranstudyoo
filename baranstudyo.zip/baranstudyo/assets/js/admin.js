/* Baran Stüdyo - Yönetim paneli JS */
(function () {
    'use strict';
    var sidebar = document.getElementById('sidebar');
    document.querySelectorAll('[data-toggle-sidebar]').forEach(function (el) {
        el.addEventListener('click', function () { if (sidebar) sidebar.classList.toggle('open'); });
    });

    // Silme onayı
    document.querySelectorAll('form[data-confirm]').forEach(function (f) {
        f.addEventListener('submit', function (e) { if (!window.confirm(f.getAttribute('data-confirm'))) e.preventDefault(); });
    });

    // Otomatik gönderim
    document.querySelectorAll('[data-autosubmit]').forEach(function (s) {
        s.addEventListener('change', function () { s.form.submit(); });
    });

    // Görsel önizleme
    document.querySelectorAll('input[type=file][data-preview]').forEach(function (input) {
        input.addEventListener('change', function () {
            var img = input.parentElement.querySelector('img.preview');
            if (!img || !input.files || !input.files[0]) return;
            img.src = URL.createObjectURL(input.files[0]);
            img.classList.remove('d-none');
        });
    });

    // Slug otomatik üretme
    var trMap = { 'ç': 'c', 'ğ': 'g', 'ı': 'i', 'İ': 'i', 'ö': 'o', 'ş': 's', 'ü': 'u', 'Ç': 'c', 'Ğ': 'g', 'Ö': 'o', 'Ş': 's', 'Ü': 'u' };
    var slugify = function (s) {
        return s.replace(/[çğıİöşüÇĞÖŞÜ]/g, function (c) { return trMap[c]; }).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
    };
    var src = document.querySelector('[data-slug-source]'), dst = document.querySelector('[data-slug-target]');
    if (src && dst) {
        var touched = dst.value !== '';
        dst.addEventListener('input', function () { touched = dst.value !== ''; });
        src.addEventListener('input', function () { if (!touched) dst.value = slugify(src.value); });
    }

    // İkon önizleme
    var iconInput = document.querySelector('[data-icon-input]'), iconPrev = document.querySelector('[data-icon-preview]');
    if (iconInput && iconPrev) iconInput.addEventListener('input', function () { iconPrev.className = 'bi ' + iconInput.value; });

    // Basit HTML editör araç çubuğu
    document.querySelectorAll('.editor-toolbar').forEach(function (bar) {
        var ta = document.getElementById(bar.getAttribute('data-target'));
        bar.querySelectorAll('button[data-tag]').forEach(function (b) {
            b.addEventListener('click', function () {
                var tag = b.getAttribute('data-tag'), s = ta.selectionStart, e = ta.selectionEnd, sel = ta.value.substring(s, e) || 'metin', out;
                if (tag === 'ul') out = '<ul>\n  <li>' + sel.split('\n').join('</li>\n  <li>') + '</li>\n</ul>';
                else if (tag === 'a') { var href = window.prompt('Bağlantı adresi (https://...)', 'https://'); if (!href) return; out = '<a href="' + href.replace(/"/g, '') + '" target="_blank">' + sel + '</a>'; }
                else out = '<' + tag + '>' + sel + '</' + tag + '>';
                ta.setRangeText(out, s, e, 'end');
                ta.focus();
            });
        });
    });

    // Ayarlar sekmesini hatırla
    var tabInput = document.getElementById('activeTab');
    document.querySelectorAll('[data-tab]').forEach(function (t) {
        t.addEventListener('shown.bs.tab', function () { if (tabInput) tabInput.value = t.getAttribute('data-tab'); history.replaceState(null, '', '#' + t.getAttribute('data-tab')); });
    });
    if (location.hash && window.bootstrap) {
        var btn = document.querySelector('[data-tab="' + location.hash.substring(1) + '"]');
        if (btn) new bootstrap.Tab(btn).show();
    } else if (location.hash) {
        window.addEventListener('load', function () { var b = document.querySelector('[data-tab="' + location.hash.substring(1) + '"]'); if (b && window.bootstrap) new bootstrap.Tab(b).show(); });
    }
})();
