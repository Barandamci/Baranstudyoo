/* Baran Stüdyo - Ana JavaScript (bağımlılıksız, derleme gerektirmez) */
(function () {
    'use strict';
    document.documentElement.classList.remove('no-js');

    // Navbar scroll efekti & yukarı çık butonu
    var nav = document.getElementById('mainNav');
    var toTop = document.querySelector('.back-to-top');
    var onScroll = function () {
        var y = window.scrollY;
        if (nav) nav.classList.toggle('scrolled', y > 30);
        if (toTop) toTop.classList.toggle('show', y > 600);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    if (toTop) toTop.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: 'smooth' }); });

    // Mobil menüde link tıklanınca kapat
    document.querySelectorAll('#mobileMenu .nav-link').forEach(function (link) {
        link.addEventListener('click', function () {
            var oc = window.bootstrap && window.bootstrap.Offcanvas.getInstance(document.getElementById('mobileMenu'));
            if (oc) oc.hide();
        });
    });

    // Scroll ile görünme animasyonları
    var reveals = document.querySelectorAll('.reveal');
    if ('IntersectionObserver' in window) {
        var io = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                    io.unobserve(entry.target);
                }
            });
        }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
        reveals.forEach(function (el) { io.observe(el); });
    } else {
        reveals.forEach(function (el) { el.classList.add('visible'); });
    }

    // Sayaç animasyonu
    var counters = document.querySelectorAll('.counter');
    var animateCounter = function (el) {
        var target = parseInt(el.getAttribute('data-target'), 10) || 0;
        var duration = 1600, start = null;
        var step = function (ts) {
            if (!start) start = ts;
            var p = Math.min((ts - start) / duration, 1);
            el.textContent = Math.floor(target * (1 - Math.pow(1 - p, 3))).toLocaleString('tr-TR');
            if (p < 1) requestAnimationFrame(step);
        };
        requestAnimationFrame(step);
    };
    if ('IntersectionObserver' in window) {
        var cio = new IntersectionObserver(function (entries) {
            entries.forEach(function (e) {
                if (e.isIntersecting) { animateCounter(e.target); cio.unobserve(e.target); }
            });
        }, { threshold: 0.5 });
        counters.forEach(function (c) { cio.observe(c); });
    } else {
        counters.forEach(function (c) { c.textContent = c.getAttribute('data-target'); });
    }

    // Yazı efekti
    var typing = document.querySelector('.typing');
    if (typing) {
        var words = (typing.getAttribute('data-words') || '').split('|').filter(Boolean);
        var wi = 0, ci = 0, deleting = false;
        var tick = function () {
            var word = words[wi] || '';
            typing.textContent = word.substring(0, ci);
            if (!deleting && ci < word.length) { ci++; setTimeout(tick, 70); }
            else if (!deleting) { deleting = true; setTimeout(tick, 1600); }
            else if (ci > 0) { ci--; setTimeout(tick, 35); }
            else { deleting = false; wi = (wi + 1) % words.length; setTimeout(tick, 300); }
        };
        if (words.length) tick();
    }

    // Proje filtreleme
    document.querySelectorAll('.filter-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var f = btn.getAttribute('data-filter');
            document.querySelectorAll('.filter-btn').forEach(function (b) { b.classList.toggle('active', b === btn); });
            document.querySelectorAll('.project-item').forEach(function (item) {
                item.classList.toggle('is-hidden', f !== '*' && item.getAttribute('data-category') !== f);
            });
        });
    });

    // AJAX form gönderimi (iletişim formu)
    document.querySelectorAll('form.ajax-form').forEach(function (form) {
        var alertBox = form.parentElement.querySelector('.form-alert');
        var btn = form.querySelector('[type="submit"]');

        var showAlert = function (type, msg) {
            if (!alertBox) return;
            alertBox.innerHTML = '';
            var div = document.createElement('div');
            div.className = 'alert alert-' + type;
            div.textContent = msg;
            alertBox.appendChild(div);
        };
        var setLoading = function (on) {
            if (!btn) return;
            btn.disabled = on;
            var t = btn.querySelector('.btn-text'), l = btn.querySelector('.btn-loading');
            if (t) t.classList.toggle('d-none', on);
            if (l) l.classList.toggle('d-none', !on);
        };
        var clearErrors = function () {
            form.querySelectorAll('.is-invalid').forEach(function (el) { el.classList.remove('is-invalid'); });
        };
        var setError = function (name, msg) {
            var input = form.querySelector('[name="' + name + '"]');
            if (!input) return;
            input.classList.add('is-invalid');
            var fb = input.parentElement.querySelector('.invalid-feedback');
            if (fb) fb.textContent = msg;
        };

        form.addEventListener('submit', function (e) {
            e.preventDefault();
            clearErrors();
            var valid = true;
            form.querySelectorAll('[required]').forEach(function (input) {
                if (!input.checkValidity()) {
                    valid = false;
                    setError(input.name, input.validationMessage || 'Bu alan zorunludur.');
                }
            });
            if (!valid) { showAlert('danger', 'Lütfen işaretli alanları kontrol edin.'); return; }

            setLoading(true);
            fetch(form.action, {
                method: 'POST',
                body: new FormData(form),
                headers: { 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json' },
                credentials: 'same-origin'
            }).then(function (r) {
                return r.json().catch(function () { return { success: false, message: 'Sunucudan geçersiz yanıt alındı.' }; });
            }).then(function (data) {
                if (data.success) {
                    showAlert('success', data.message);
                    form.reset();
                    var ts = form.querySelector('[name="_ts"]');
                    if (ts) ts.value = Math.floor(Date.now() / 1000) - 5;
                } else {
                    showAlert('danger', data.message || 'Bir hata oluştu.');
                    if (data.errors) Object.keys(data.errors).forEach(function (k) { setError(k, data.errors[k]); });
                }
            }).catch(function () {
                showAlert('danger', 'Bağlantı hatası. Lütfen tekrar deneyin.');
            }).finally(function () { setLoading(false); });
        });
    });
})();

/* Domain sorgulama (AJAX, JS kapalıysa normal GET formu çalışır) */
(function () {
    'use strict';
    var esc = function (s) { var d = document.createElement('div'); d.textContent = s == null ? '' : String(s); return d.innerHTML; };
    var months = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
    var fmt = function (d) { if (!d) return 'Kayıt kaynağında yok'; var p = d.split(/[- :]/); return parseInt(p[2], 10) + ' ' + months[parseInt(p[1], 10) - 1] + ' ' + p[0]; };
    document.querySelectorAll('form[data-domain-form]').forEach(function (form) {
        var box = form.querySelector('.domain-result');
        form.addEventListener('submit', function (e) {
            e.preventDefault();
            var stat = document.querySelector('.domain-result-static'); if (stat) stat.remove();
            var params = new URLSearchParams(new FormData(form));
            form.classList.add('loading');
            box.innerHTML = '<div class="dr"><span class="spinner-border spinner-border-sm"></span> Resmi kayıtlar sorgulanıyor...</div>';
            fetch(form.getAttribute('data-api') + '?' + params.toString(), { headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' } })
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    if (!data.ok) { box.innerHTML = '<div class="dr dr-error"><i class="bi bi-exclamation-circle"></i> ' + esc(data.message) + '</div>'; return; }
                    var r = data.result, ok = r.status === 'available', html = '<div class="dr ' + (ok ? 'dr-ok' : 'dr-taken') + '"><div class="dr-head"><i class="bi ' + (ok ? 'bi-check-circle-fill' : 'bi-x-circle-fill') + '"></i><div><strong>' + esc(r.domain) + '</strong> <span>' + (ok ? 'müsait — kayıt edilebilir' : 'kayıtlı — alınmış') + '</span></div></div>';
                    if (!ok) {
                        html += '<dl class="dr-info"><div><dt>Kayıt tarihi</dt><dd>' + esc(fmt(r.created)) + '</dd></div><div><dt>Bitiş tarihi</dt><dd>' + esc(fmt(r.expires)) + '</dd></div>';
                        if (r.registrar) html += '<div><dt>Kayıt firması</dt><dd>' + esc(r.registrar) + '</dd></div>';
                        if (r.nameservers && r.nameservers.length) html += '<div><dt>DNS</dt><dd>' + esc(r.nameservers.join(', ')) + '</dd></div>';
                        html += '</dl>';
                    }
                    box.innerHTML = html + '<small class="dr-src">Kaynak: ' + esc(r.source) + '</small></div>';
                })
                .catch(function () { box.innerHTML = '<div class="dr dr-error">Bağlantı hatası. Lütfen tekrar deneyin.</div>'; })
                .finally(function () { form.classList.remove('loading'); });
        });
    });
})();
