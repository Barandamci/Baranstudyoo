<?php
/**
 * Baran Stüdyo - Ana yapılandırma dosyası
 * Kurulumda yalnızca bu dosyadaki "db", "app.url" ve "mail" bölümlerini düzenlemeniz yeterlidir.
 */
return [
    'app' => [
        'name'     => 'Baran Stüdyo',
        // Sitenin tam adresi (sonunda / olmadan). Alt klasörde ise: https://alanadi.com/klasor
        'url'      => 'https://baranstudyo.net.tr',
        // Canlı ortamda MUTLAKA false olmalı (hata detayları gizlenir, log dosyasına yazılır)
        'debug'    => false,
        'timezone' => 'Europe/Istanbul',
        'locale'   => 'tr_TR',
        // Tüm HTTP isteklerini HTTPS'e yönlendir (SSL kurulu ise true yapın)
        'force_https' => false,
    ],

    'db' => [
        'host'    => 'localhost',
        'port'    => 3306,
        'name'    => 'cpaneluser_baranstudyo',
        'user'    => 'cpaneluser_dbuser',
        'pass'    => 'VERITABANI_SIFRESI',
        'charset' => 'utf8mb4',
    ],

    'session' => [
        'name'     => 'BSSESSID',
        'lifetime' => 7200, // saniye cinsinden boşta kalma süresi
    ],

    'security' => [
        // Cloudflare arkasında gerçek ziyaretçi IP'sini CF-Connecting-IP başlığından al
        'trust_cloudflare' => true,
        // Başka bir reverse proxy arkasındaysanız X-Forwarded-For başlığına güven
        'trust_proxy'      => false,
        // Brute force koruması
        'login_max_attempts' => 5,    // aynı IP + e-posta için
        'login_max_ip_attempts' => 20, // aynı IP için toplam
        'login_decay_minutes' => 15,
        // İletişim formu limiti (IP başına)
        'contact_max_per_window' => 5,
        'contact_window_minutes' => 10,
        // Content-Security-Policy başlığı (Cloudflare Rocket Loader kullanıyorsanız false yapın)
        'csp' => true,
    ],

    'upload' => [
        'max_size'  => 5 * 1024 * 1024, // 5 MB
        'max_width' => 1600,            // daha büyük görseller otomatik küçültülür
        'quality'   => 82,              // WebP/JPEG kalite
        'webp'      => true,            // destekleniyorsa WebP'ye dönüştür
    ],

    'cache' => [
        'enabled'  => true,
        // Ziyaretçi sayfaları için tam sayfa önbellek süresi (saniye). 0 = kapalı
        'page_ttl' => 600,
        // Veri önbelleği (ayarlar, hizmet listesi vb.)
        'data_ttl' => 3600,
    ],

    'mail' => [
        // 'mail' => PHP mail() fonksiyonu (cPanel'de ek ayar gerektirmez)
        // 'smtp' => SMTP sunucusu üzerinden gönderim
        'driver'     => 'mail',
        'from_email' => 'noreply@baranstudyo.net.tr',
        'from_name'  => 'Baran Stüdyo',
        'smtp' => [
            'host'       => 'mail.baranstudyo.net.tr',
            'port'       => 465,
            'encryption' => 'ssl', // ssl | tls | none
            'username'   => 'noreply@baranstudyo.net.tr',
            'password'   => '',
            'timeout'    => 15,
        ],
    ],

    // Rol bazlı yetkilendirme
    // Bu e-posta ile kayıt olan ilk kullanıcı otomatik olarak Owner (en yüksek yetki) olur
    'owner_email' => 'baran@baranstudyo.net.tr',

    'roles' => [
        'owner'  => ['*'],
        'admin'  => ['dashboard', 'services', 'projects', 'sites', 'posts', 'testimonials', 'messages', 'profile'],
        'editor' => ['dashboard', 'projects', 'sites', 'posts', 'messages', 'profile'],
        'user'   => [],
    ],
];
