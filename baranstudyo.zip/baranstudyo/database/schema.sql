-- =====================================================================
-- Baran Stüdyo - Veritabanı Kurulum Dosyası
-- MySQL 8.x / MariaDB 10.4+  |  Karakter seti: utf8mb4
-- cPanel > phpMyAdmin > veritabanınızı seçin > İçe Aktar (Import) ile yükleyin.
-- DİKKAT: Mevcut aynı isimli tabloları siler. Yalnızca ilk kurulumda kullanın.
-- =====================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
SET time_zone = '+03:00';

DROP TABLE IF EXISTS `activity_logs`, `login_attempts`, `messages`, `sites`, `testimonials`, `posts`, `projects`, `services`, `settings`, `users`;

CREATE TABLE `users` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(190) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `role` ENUM('owner','admin','editor','user') NOT NULL DEFAULT 'user',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `last_login_at` DATETIME NULL DEFAULT NULL,
  `last_login_ip` VARCHAR(45) NULL DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `services` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(150) NOT NULL,
  `slug` VARCHAR(190) NOT NULL,
  `icon` VARCHAR(60) NOT NULL DEFAULT 'bi-code-slash',
  `short_description` VARCHAR(300) NOT NULL DEFAULT '',
  `content` MEDIUMTEXT NULL,
  `image` VARCHAR(255) NULL DEFAULT NULL,
  `sort_order` INT NOT NULL DEFAULT 0,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `meta_title` VARCHAR(190) NULL DEFAULT NULL,
  `meta_description` VARCHAR(300) NULL DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_services_slug` (`slug`),
  KEY `idx_services_active` (`is_active`, `sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `projects` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(150) NOT NULL,
  `slug` VARCHAR(190) NOT NULL,
  `client` VARCHAR(150) NULL DEFAULT NULL,
  `category` VARCHAR(100) NULL DEFAULT NULL,
  `summary` VARCHAR(400) NOT NULL DEFAULT '',
  `content` MEDIUMTEXT NULL,
  `image` VARCHAR(255) NULL DEFAULT NULL,
  `technologies` VARCHAR(400) NULL DEFAULT NULL,
  `project_date` DATE NULL DEFAULT NULL,
  `project_url` VARCHAR(255) NULL DEFAULT NULL,
  `is_featured` TINYINT(1) NOT NULL DEFAULT 0,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `sort_order` INT NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_projects_slug` (`slug`),
  KEY `idx_projects_active` (`is_active`, `is_featured`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `posts` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NULL DEFAULT NULL,
  `title` VARCHAR(200) NOT NULL,
  `slug` VARCHAR(190) NOT NULL,
  `excerpt` VARCHAR(400) NOT NULL DEFAULT '',
  `content` MEDIUMTEXT NULL,
  `image` VARCHAR(255) NULL DEFAULT NULL,
  `meta_title` VARCHAR(190) NULL DEFAULT NULL,
  `meta_description` VARCHAR(300) NULL DEFAULT NULL,
  `status` ENUM('draft','published') NOT NULL DEFAULT 'draft',
  `published_at` DATETIME NULL DEFAULT NULL,
  `views` INT UNSIGNED NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_posts_slug` (`slug`),
  KEY `idx_posts_status` (`status`, `published_at`),
  KEY `fk_posts_user` (`user_id`),
  CONSTRAINT `fk_posts_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `testimonials` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `client_name` VARCHAR(120) NOT NULL,
  `company` VARCHAR(150) NULL DEFAULT NULL,
  `position` VARCHAR(120) NULL DEFAULT NULL,
  `comment` TEXT NOT NULL,
  `rating` TINYINT UNSIGNED NOT NULL DEFAULT 5,
  `logo` VARCHAR(255) NULL DEFAULT NULL,
  `sort_order` INT NOT NULL DEFAULT 0,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `sites` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(150) NOT NULL,
  `domain` VARCHAR(190) NOT NULL,
  `logo` VARCHAR(255) DEFAULT NULL,
  `description` TEXT,
  `url` VARCHAR(255) DEFAULT NULL,
  `sort_order` INT NOT NULL DEFAULT 0,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_sites_active` (`is_active`, `sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `messages` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(120) NOT NULL,
  `email` VARCHAR(190) NOT NULL,
  `phone` VARCHAR(30) NULL DEFAULT NULL,
  `subject` VARCHAR(200) NOT NULL,
  `message` TEXT NOT NULL,
  `ip` VARCHAR(45) NOT NULL,
  `user_agent` VARCHAR(255) NULL DEFAULT NULL,
  `is_read` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_messages_read` (`is_read`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `settings` (
  `key` VARCHAR(100) NOT NULL,
  `value` TEXT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `login_attempts` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `ip` VARCHAR(45) NOT NULL,
  `email` VARCHAR(190) NOT NULL DEFAULT '',
  `success` TINYINT(1) NOT NULL DEFAULT 0,
  `cleared` TINYINT(1) NOT NULL DEFAULT 0,
  `user_agent` VARCHAR(255) NULL DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_la_ip` (`ip`, `created_at`),
  KEY `idx_la_email` (`email`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `activity_logs` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NULL DEFAULT NULL,
  `action` VARCHAR(50) NOT NULL,
  `description` VARCHAR(255) NOT NULL DEFAULT '',
  `ip` VARCHAR(45) NOT NULL,
  `user_agent` VARCHAR(255) NULL DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_logs_action` (`action`, `created_at`),
  KEY `idx_logs_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;


-- ---------------------------------------------------------------------
-- Site ayarları
-- ---------------------------------------------------------------------
INSERT INTO `settings` (`key`, `value`) VALUES
('site_title', 'Baran Stüdyo'),
('site_tagline', 'Dijital Dünyada Güçlü Çözümler'),
('site_description', 'Baran Stüdyo; web yazılım, özel yazılım geliştirme, yapay zekâ çözümleri, mobil uygulama ve kurumsal web tasarım alanlarında uçtan uca dijital sistemler geliştiren teknoloji firmasıdır.'),
('site_keywords', 'web tasarım, özel yazılım, php yazılım, e-ticaret, mobil uygulama, yapay zeka, api entegrasyonu, otomasyon, sunucu yönetimi'),
('hero_badge', 'Yazılım & Dijital Çözümler'),
('hero_title', 'Dijital Dünyada Güçlü Çözümler'),
('hero_subtitle', 'Web yazılımdan yapay zekâya, mobil uygulamadan kurumsal sistemlere kadar işinizi büyüten, hızlı, güvenli ve ölçeklenebilir dijital ürünler geliştiriyoruz.'),
('about_title', 'Teknolojiyi işinizin gücüne dönüştürüyoruz'),
('about_text', 'Baran Stüdyo; web yazılım, özel yazılım geliştirme, yapay zekâ çözümleri, mobil uygulama, kurumsal web tasarım ve dijital sistemler geliştiren bir teknoloji firmasıdır.\n\nFikir aşamasından canlıya alıma ve sonrasındaki bakım sürecine kadar her adımda iş ortaklarımızın yanında oluyoruz. Modern teknolojiler, temiz kod prensipleri ve güvenlik odaklı yaklaşımımızla markaların dijital dönüşümüne yön veriyoruz.'),
('mission', 'İşletmelerin dijital dünyada güçlü, güvenli ve sürdürülebilir bir yer edinmesi için; ihtiyaca özel, performanslı ve kullanıcı odaklı yazılım çözümleri üretmek.'),
('vision', 'Türkiye’den dünyaya açılan, yapay zekâ ve yazılım alanında yenilikçi ürünleriyle tercih edilen, güvenilir bir teknoloji markası olmak.'),
('values', 'Şeffaflık|Her aşamada açık iletişim ve net raporlama.\nKalite|Temiz kod, test edilmiş ve sürdürülebilir yazılım.\nGüvenlik|Güvenlik odaklı mimari ve en iyi uygulamalar.\nYenilikçilik|Yapay zekâ ve modern teknolojileri yakından takip.\nHız|Optimize edilmiş, hızlı açılan sistemler.\nİş Ortaklığı|Projeyi teslim etmekle bitmeyen uzun soluklu destek.'),
('contact_email', ''),
('contact_phone', ''),
('contact_address', ''),
('working_hours', ''),
('notification_email', ''),
('whatsapp_number', ''),
('whatsapp_message', 'Merhaba, Baran Stüdyo hakkında bilgi almak istiyorum.'),
('google_analytics_id', ''),
('google_site_verification', ''),
('social_instagram', ''),
('social_linkedin', ''),
('social_github', ''),
('social_x', ''),
('social_youtube', ''),
('og_image', ''),
('domain_enabled', '1'),
('domain_tlds', 'com,net,org,com.tr,net.tr,org.tr,io,dev,app,info,xyz,online,store'),
('domain_rate_limit', '30'),
('domain_cache_minutes', '10'),
('registration_enabled', '1'),
('footer_text', 'Web yazılım, yapay zekâ ve dijital sistemlerde güvenilir teknoloji ortağınız.');

-- ---------------------------------------------------------------------
-- Hizmetler
-- ---------------------------------------------------------------------
INSERT INTO `services` (`title`, `slug`, `icon`, `short_description`, `content`, `sort_order`, `is_active`) VALUES
('Web Tasarım', 'web-tasarim', 'bi-palette2', 'Markanızı yansıtan, mobil uyumlu, hızlı ve SEO dostu kurumsal web siteleri tasarlıyoruz.', '<p>Kurumsal kimliğinizi dijital dünyaya en doğru şekilde taşıyan, modern ve dönüşüm odaklı web siteleri tasarlıyoruz.</p><h3>Neler sunuyoruz?</h3><ul><li>Kullanıcı deneyimi (UX) odaklı arayüz tasarımı</li><li>Tüm cihazlarda kusursuz responsive yapı</li><li>Teknik SEO ve yüksek PageSpeed skorları</li><li>Kolay yönetilebilir içerik paneli</li></ul>', 1, 1),
('Özel PHP Yazılım', 'ozel-php-yazilim', 'bi-filetype-php', 'İş süreçlerinize birebir uyan, ölçeklenebilir ve güvenli özel PHP yazılımlar geliştiriyoruz.', '<p>Hazır paketlerin yetersiz kaldığı noktada, iş akışlarınıza özel PHP 8.x tabanlı yazılımlar geliştiriyoruz.</p><ul><li>MVC mimarisi ve temiz kod</li><li>CRM, ERP, B2B portalları ve yönetim panelleri</li><li>Güvenlik odaklı geliştirme (OWASP)</li><li>Uzun vadeli bakım ve destek</li></ul>', 2, 1),
('E-Ticaret Sistemleri', 'e-ticaret-sistemleri', 'bi-cart3', 'Sanal POS, kargo ve pazaryeri entegrasyonlu, yüksek dönüşümlü e-ticaret altyapıları kuruyoruz.', '<p>Satışlarınızı artıracak, hızlı ve güvenli e-ticaret sistemleri geliştiriyoruz.</p><ul><li>Sanal POS ve ödeme sistemleri entegrasyonu</li><li>Kargo, e-fatura ve pazaryeri entegrasyonları</li><li>Stok, sipariş ve kampanya yönetimi</li><li>Mobil öncelikli alışveriş deneyimi</li></ul>', 3, 1),
('Mobil Uygulama', 'mobil-uygulama', 'bi-phone', 'iOS ve Android için performanslı, kullanıcı dostu native ve cross-platform mobil uygulamalar.', '<p>Fikrinizi App Store ve Google Play’de yayında olan bir ürüne dönüştürüyoruz.</p><ul><li>Flutter ve React Native ile cross-platform geliştirme</li><li>API ve yönetim paneli entegrasyonu</li><li>Bildirim, ödeme ve harita servisleri</li><li>Mağaza yayın süreci desteği</li></ul>', 4, 1),
('API Entegrasyonu', 'api-entegrasyonu', 'bi-diagram-3', 'Sistemlerinizi birbirine bağlayan güvenli REST API geliştirme ve üçüncü parti entegrasyonları.', '<p>Farklı sistemlerin sorunsuz konuşmasını sağlayan API’ler geliştiriyor ve entegre ediyoruz.</p><ul><li>REST / JSON API tasarımı ve dokümantasyonu</li><li>Ödeme, kargo, muhasebe, CRM entegrasyonları</li><li>Webhook ve gerçek zamanlı veri senkronizasyonu</li></ul>', 5, 1),
('Yapay Zekâ Sistemleri', 'yapay-zeka-sistemleri', 'bi-cpu', 'Yapay zekâ destekli sohbet botları, içerik üretimi, veri analizi ve akıllı karar sistemleri.', '<p>Yapay zekâyı iş süreçlerinize entegre ederek verimliliğinizi katlıyoruz.</p><ul><li>LLM tabanlı müşteri destek asistanları</li><li>Doküman analizi ve akıllı arama</li><li>Tahminleme ve veri analitiği</li><li>Görüntü işleme çözümleri</li></ul>', 6, 1),
('Otomasyon Yazılımları', 'otomasyon-yazilimlari', 'bi-gear-wide-connected', 'Tekrarlayan iş süreçlerinizi otomatikleştiren, zaman ve maliyet kazandıran yazılımlar.', '<p>Manuel iş yükünü azaltan, hataları minimize eden otomasyon sistemleri kuruyoruz.</p><ul><li>İş akışı ve onay süreçleri otomasyonu</li><li>Raporlama ve bildirim otomasyonları</li><li>Veri toplama ve işleme botları</li></ul>', 7, 1),
('Sunucu Yönetimi', 'sunucu-yonetimi', 'bi-hdd-network', 'Linux sunucu kurulumu, güvenlik sıkılaştırma, yedekleme, izleme ve performans optimizasyonu.', '<p>Sistemlerinizin 7/24 hızlı, güvenli ve kesintisiz çalışmasını sağlıyoruz.</p><ul><li>cPanel, Plesk ve Linux sunucu yönetimi</li><li>SSL, güvenlik duvarı ve Cloudflare yapılandırması</li><li>Otomatik yedekleme ve felaket kurtarma</li><li>Performans izleme ve optimizasyon</li></ul>', 8, 1);



