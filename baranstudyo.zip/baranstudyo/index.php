<?php
// Sunucunuz .htaccess yönlendirmesini desteklemiyorsa bu dosya ön denetleyiciyi yükler.
require __DIR__ . '/public/index.php';
