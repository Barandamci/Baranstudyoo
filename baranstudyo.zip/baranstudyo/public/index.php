<?php
/**
 * Baran Stüdyo - Ön denetleyici (front controller)
 * Tüm ziyaretçi istekleri .htaccess ile bu dosyaya yönlendirilir.
 */
declare(strict_types=1);

require dirname(__DIR__) . '/app/bootstrap.php';

use App\Core\PageCache;
use App\Core\Router;

$router = new Router();
require APP_PATH . '/routes.php';

$path = $router->resolvePath($_SERVER['REQUEST_URI'] ?? '/');
$cacheable = PageCache::eligible($path);

if ($cacheable && PageCache::serve()) {
    exit;
}

ob_start();
$router->dispatch($_SERVER['REQUEST_METHOD'] ?? 'GET', $_SERVER['REQUEST_URI'] ?? '/', static function (): void {
    (new App\Controllers\ErrorController())->notFoundPage();
});
$html = (string) ob_get_clean();

if ($cacheable) {
    PageCache::store($html);
}
echo $html;
